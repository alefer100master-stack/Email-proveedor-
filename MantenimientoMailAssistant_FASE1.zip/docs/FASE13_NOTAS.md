# FASE 13 — Notas técnicas (Configuración)

## Qué se construyó

Pantalla de Configuración real (antes era un aviso): datos de firma
(nombre, cargo, empresa, teléfono, ciudad, correo de firma), formato de
fecha/hora, tamaño máximo de adjuntos, modo de confirmación de envío
(manual / cuenta regresiva, con su duración), acceso directo a Importar
Excel, y una lista de plantillas con interruptor para activar/desactivar
cada una (por ejemplo, ya puedes encender "Solicitud de cotización", que
llegó desactivada desde la FASE 2).

Todo se guarda de verdad en `AppSettings` (Room) — nada de esto es
decorativo.

## Cuenta Outlook: honesta, no un botón que no hace nada

En vez de un botón "Conectar cuenta Outlook" que no tendría ningún efecto
real todavía, se muestra el estado actual (siempre "No conectada" por ahora)
con una nota explicando que se activa en la FASE 9. Evita un botón
tocable que aparente hacer algo sin hacerlo.

## Qué NO se construyó todavía (a propósito)

- **Firma HTML enriquecida** (la sección 22 menciona "Firma HTML" además de
  la firma de texto plano) — se dejó fuera para no sumar un editor de texto
  enriquecido en esta misma tanda; el campo `signatureHtml` ya existe en
  `AppSettings` para cuando se construya.
- **Pantalla de Reglas** (Configuración > Reglas, sección 9): administrar
  las palabras clave una por una (agregar/editar/duplicar/desactivar) sigue
  sin pantalla propia — hoy las reglas solo existen porque se sembraron en
  la FASE 2. Activar/desactivar plantillas completas sí se construyó aquí;
  editar las palabras clave de cada regla individualmente, no.

## Para actualizar tu repo

Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre). El
workflow no cambió.
