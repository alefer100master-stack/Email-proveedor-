# FASE 9 (preparación) — Notas técnicas

## Por qué se generó un keystore de debug fijo

MSAL necesita que registres, en Microsoft Entra ID, una "URI de
redirección" que depende del hash de la firma con la que se compila la app.

Hasta ahora, cada build en GitHub Actions corría en una máquina nueva, y sin
un keystore de debug explícito, Gradle generaba uno distinto en cada
corrida — eso habría roto la conexión con Outlook con cada compilación
nueva. Se generó un keystore de debug fijo (`app/debug.keystore`, con las
credenciales estándar de Android para debug — no es un secreto real, por
eso sí se sube al repo, a diferencia de un keystore de release) y se
configuró `app/build.gradle.kts` para usarlo siempre, en vez del que Gradle
generaría por su cuenta.

## La URI de redirección exacta para pegar en Entra ID

```
msauth://com.h2ocolombia.mailassistant/Qop7Q%2BCGhFvuGtUiND1ug668MME%3D
```

Esta URI ya no va a cambiar mientras seguamos usando este mismo
`debug.keystore` (que ya quedó fijo en el repo).

## Paso a paso para crear el App Registration

1. Entra a **https://entra.microsoft.com** con tu cuenta de Microsoft 365
   (la contraseña se usa ahí, en la página de Microsoft — nunca se la das a
   esta app ni a mí).
2. Menú lateral → **Identity → Applications → App registrations → New
   registration**.
3. **Name:** `Mantenimiento Mail Assistant` (o el que prefieras).
4. **Supported account types:** "Accounts in this organizational directory
   only (H2O Colombia SAS only — Single tenant)" — así solo cuentas de tu
   empresa pueden usarla.
5. **Redirect URI:** selecciona la plataforma **"Public client/native
   (mobile & desktop)"** y pega exactamente la URI de arriba.
6. **Register**.
7. En la pantalla de **Overview** que aparece, copia estos dos valores (los
   vas a necesitar dármelos):
   - **Application (client) ID**
   - **Directory (tenant) ID**
8. Ve a **API permissions → Add a permission → Microsoft Graph → Delegated
   permissions** → busca y marca **`Mail.Send`** → **Add permissions**.
9. Si tu organización lo exige, toca **"Grant admin consent for H2O
   Colombia"** (si no tienes permisos de administrador ahí, pídeselo a
   quien administre Microsoft 365 en tu empresa — es un clic de su parte).

## Qué me tienes que devolver

Solo estos dos valores (ninguno es una contraseña, se pueden compartir sin
problema):
- **Application (client) ID**
- **Directory (tenant) ID**

Con esos dos, construyo FASE 9 (MSAL), FASE 10 (Microsoft Graph) y FASE 11
(conectar el envío real con la cuenta regresiva ya construida desde FASE 1)
completas.

## Para actualizar tu repo

Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre) — ya
incluye el keystore de debug fijo y la configuración de Gradle actualizada.
El `main.yml` no cambia.
