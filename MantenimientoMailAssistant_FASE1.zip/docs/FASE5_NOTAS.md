# FASE 5 — Notas técnicas (Chat e historial)

## Qué se construyó

- **Chat real por proveedor**: al tocar un proveedor en Home ya no se abre
  la pantalla de detalle (eso ahora es secundario) — se abre el chat de la
  sección 6 del requerimiento original: encabezado con nombre y correo
  principal, historial de mensajes persistido en Room, y una barra inferior
  para escribir y enviar.
- **Historial real, no simulado**: cada mensaje que escribes queda guardado
  en `ChatMessage` (Room) y se recupera automáticamente al volver a abrir el
  chat de ese proveedor — no se pierde al cerrar la app.
- **Detalle del proveedor como pantalla secundaria**: se accede con el ícono
  de información en la barra superior del chat. Ahí sigue viviendo
  ver/editar los datos (FASE 3).

## Decisión importante: la respuesta automática es honesta, no simulada

Cuando envías un mensaje, la app lo guarda y responde con una nota clara:
*"Guardado en el historial. El reconocimiento automático de la instrucción
(...) se activa en la FASE 7/8."* En vez de fingir que ya identifica
proveedor/plantilla/destinatario (lo que exigiría inventar una respuesta
falsa a una funcionalidad crítica, prohibido en la sección 35 del
requerimiento original), se deja explícito qué es real hoy y qué llega
después.

## Otras decisiones

- **Un ChatThread por proveedor, creado sobre la marcha.** Los proveedores
  sembrados en FASE 2 ya traían su hilo de chat, pero los creados a mano
  (FASE 3) o importados desde Excel (FASE 4) no. En vez de acordarse de
  crear el hilo en cada uno de esos caminos, `ChatRepository.getOrCreateThreadForSupplier`
  lo crea la primera vez que se abre el chat de ese proveedor — un solo
  lugar cubre los tres orígenes posibles.
- **Adjuntar ya tiene su botón, pero avisa que aún no funciona** (un
  mensaje breve en pantalla) en vez de estar oculto o fingir que adjunta
  algo — coherente con el mockup original, que siempre muestra el botón de
  adjuntar en la barra del chat, y con no simular una funcionalidad que
  todavía no existe (FASE 6).
- **"Historial" de esta fase ≠ el "Historial" auditable de FASE 12.** El
  nombre de la FASE 5 en el requerimiento original ("Chat e historial") se
  refiere al historial de conversación de CADA proveedor, ya construido
  aquí. El historial global con filtros por proveedor/fecha/estado
  (sección 15) sigue siendo la FASE 12 y todavía muestra su aviso.

## Para actualizar tu repo

Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre). El
workflow no cambió.
