# FASE 12 — Notas técnicas (Auditoría / historial global)

## Qué se construyó

La pantalla de Historial (accesible desde el ícono en Home) ya muestra de
verdad las filas de `EmailLog` que se han ido creando desde la FASE 8 —
cada vez que el motor de reglas reconoce una plantilla y se prepara un
correo, esa fila aparece aquí con su estado real (Preparado / Confirmado /
Cancelado por ahora; Enviando/Enviado/Error se activan cuando exista el
envío real en la FASE 9 en adelante).

## Filtros implementados

- **Búsqueda de texto** contra proveedor, correo destinatario y asunto en
  un solo campo (cubre las columnas "Proveedor" y "Correo" de la sección
  15 del requerimiento original con un solo control, en vez de dos campos
  separados).
- **Estado**, con chips (Todos + cada estado).

## Qué NO se construyó todavía (a propósito)

- **Filtro por rango de fechas**: la sección 15 lo pide, pero un selector de
  fechas (Material3 DatePicker) es una pieza de UI completa aparte; se dejó
  fuera de esta pasada para no sumar más riesgo de compilación a una tanda
  ya grande de fases. Se puede agregar después sin tocar el resto.
- **Filtro por tipo de comunicación** (plantilla específica): técnicamente
  fácil de sumar (ya se guarda `templateId` en cada `EmailLog`), se dejó
  fuera por la misma razón de alcance, no por dificultad.

## Para actualizar tu repo

Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre). El
workflow no cambió.
