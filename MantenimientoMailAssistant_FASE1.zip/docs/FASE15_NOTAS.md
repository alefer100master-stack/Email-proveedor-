# FASE 15 — Notas técnicas (Build release)

## Qué se construyó

- **Firma de release lista, sin secretos en el repo**: `app/build.gradle.kts`
  ahora define un `signingConfig` de release que lee de variables de entorno
  (`RELEASE_KEYSTORE_PATH`, `RELEASE_KEYSTORE_PASSWORD`, `RELEASE_KEY_ALIAS`,
  `RELEASE_KEY_PASSWORD`) en vez de un archivo `.jks` committeado — una
  llave de firma nunca debe subirse a un repositorio, ni siquiera privado.
  Si esas variables no existen (como hoy), el build de release simplemente
  queda sin firmar; **no afecta en nada** el `assembleDebug` que ya venías
  usando.
- `app/proguard-rules.pro`: archivo base, lista para cuando se active la
  minificación.
- Versión bajada a `0.9.0` (versionCode 2) para reflejar que ya están todas
  las fases menos Outlook — ver la convención de versionado abajo.

## Por qué la minificación queda apagada por ahora

Activar R8 (minificación/ofuscación) es buena práctica para un release
público, pero no se puede verificar sin compilar en un dispositivo real —
algo que este flujo (GitHub Actions + tu celular) sí puede hacer, pero
representa un riesgo real de romper algo sutil (Room, Compose, y sobre todo
MSAL/Graph más adelante) sin que ninguno de los dos lo pueda depurar fácil
a ciegas. Se prioriza que el build siga siendo confiable sobre que sea lo
más optimizado posible, siguiendo la prioridad de la sección 38 del
requerimiento original ("CONFIABILIDAD > ... > DISEÑO"). Se puede activar
más adelante, cuando haya manera de probar el APK de release a fondo.

## Cuándo y cómo generar un keystore real (no ahora, solo referencia)

Cuando quieras distribuir un APK firmado de verdad (por ejemplo, para
instalarlo en más celulares de la planta sin pasar por "orígenes
desconocidos" cada vez, o si algún día publicas en una tienda interna):

1. Generar el keystore (esto SÍ necesita un computador con JDK, no se puede
   hacer desde el celular): `keytool -genkeypair -v -keystore release.jks -alias mantenimiento -keyalg RSA -keysize 2048 -validity 10000`
2. En GitHub → tu repo → Settings → Secrets and variables → Actions, crea:
   `RELEASE_KEYSTORE_BASE64` (el archivo .jks codificado en base64),
   `RELEASE_KEYSTORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`.
3. Ese es el momento de agregar un paso al workflow que decodifique el
   secreto a un archivo temporal, exporte `RELEASE_KEYSTORE_PATH` apuntando
   ahí, y corra `gradle assembleRelease` en vez de (o además de)
   `assembleDebug`. No se hizo ahora porque no hay todavía una razón real
   para distribuir un release firmado — el debug funciona bien para instalar
   y probar en tu propio celular.

## Convención de versionado

`MAJOR.MINOR.PATCH` en `versionName`, `versionCode` sube en 1 en cada build
que se instale para probar. Sugerencia: `1.0.0` cuando Outlook/Graph (FASE
9-11) ya envíen correos reales de punta a punta.

## Informe final de auditoría (sección 37 del requerimiento original)

```
BUILD                ✓  (assembleDebug, vía GitHub Actions)
TESTS                ✓  (JUnit, corren antes de compilar — FASE 14)
EXCEL                ✓  (lector .xlsx propio, sin Apache POI — FASE 4)
DATABASE             ✓  (Room, 9 entidades — FASE 2)
AUTHENTICATION       ⏳  pendiente — necesita App Registration en Entra ID (FASE 9)
OUTLOOK              ⏳  pendiente — necesita Microsoft Graph (FASE 10)
ATTACHMENTS          ✓  (selector real, validación, permiso persistente — FASE 6)
AUDIT LOG            ✓  (EmailLog real: PREPARADO/CONFIRMADO/CANCELADO — FASE 8/12)
RELEASE APK          ⏳  firma lista, sin keystore generado todavía (ver arriba)
```

Todo lo marcado ✓ es funcionalidad real, verificada por su propio código y
(donde aplica) por pruebas automatizadas — no hay nada fingido detrás de
esos check. Lo marcado ⏳ depende exclusivamente de una acción tuya fuera de
esta conversación (crear el App Registration) o de una decisión tuya
(cuándo generar el keystore de verdad).

## Para actualizar tu repo

1. Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre).
2. El `main.yml` no necesita cambios adicionales a los de la FASE 14 (el de
   pruebas). Si ya lo actualizaste ahí, no hace falta tocarlo de nuevo.
