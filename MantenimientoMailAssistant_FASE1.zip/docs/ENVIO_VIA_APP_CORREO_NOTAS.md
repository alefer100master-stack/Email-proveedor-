# Envío de correo vía la app de correo del teléfono (reemplaza MSAL/Graph)

## Por qué se cambió de plan

El plan original (FASE 9-11) era conectar la app directo a Microsoft Graph
usando MSAL, lo que exige registrar una aplicación en Microsoft Entra ID.
Después de varios intentos reales (documentados en la conversación), se
confirmó que la cuenta disponible no tiene los permisos administrativos
necesarios en ningún tenant real de Microsoft 365, y las alternativas de
pago (n8n Cloud, Power Automate con disparador HTTP) tienen un costo
mensual recurrente que no se ajusta al objetivo de "100% gratis para
siempre".

Se investigó (con búsquedas verificadas, no solo memoria) todas las
alternativas vigentes a la fecha y se eligió esta por ser la única genuinamente
gratuita para siempre y sin depender de ningún registro ni servicio externo.

## Cómo funciona

1. El motor de reglas (FASE 7) y de plantillas (FASE 8) siguen exactamente
   igual — reconocen la instrucción, arman el asunto y cuerpo reales.
2. Al confirmar el envío (ya sea tocando "Enviar" o dejando correr la cuenta
   regresiva), la app arma un `Intent` estándar de Android
   (`util/EmailIntentLauncher.kt`) con destinatario, asunto, cuerpo y
   adjuntos, y se lo entrega a la aplicación de correo que el usuario tenga
   instalada (Outlook real, Gmail, etc.) — usando `type = "message/rfc822"`,
   la convención de Android para que el selector solo muestre apps de
   correo.
3. El usuario confirma el envío final **dentro de esa otra app** — ahí es
   donde de verdad sale el correo, desde la cuenta que esa app tenga
   iniciada.
4. La app registra el intento como `EmailLogStatus.ENVIANDO` (no
   `ENVIADO`) — es el estado más honesto que se puede afirmar, porque no hay
   forma de confirmar programáticamente que el usuario sí completó el envío
   en la otra app. Desde el Historial, el usuario puede marcarlo
   manualmente como "Enviado" o "Con error" una vez sepa qué pasó.

## La cuenta regresiva cancelable (FASE 1) por fin tiene una acción real

`SendCountdownBar`, construido desde la FASE 1 pero sin nada que contar
hacia atrás, ahora sí dispara la entrega real del correo al terminar la
cuenta — se activa cuando el modo de confirmación en Configuración está en
"Cuenta regresiva cancelable". Si está en "Manual", se muestra el mismo
`EmailPreviewCard` de siempre, con botones Cancelar/Enviar.

## Qué se ganó y qué se perdió, con honestidad

**Se ganó:**
- $0 de costo, para siempre — sin depender de ningún registro en Entra ID,
  ninguna suscripción de terceros (n8n, Power Automate), ni ningún permiso
  de administrador de la organización.
- Funciona con cualquier cuenta de correo que el usuario ya tenga
  configurada en el teléfono — de la empresa o personal, sin distinción de
  código.
- Adjuntos siguen funcionando igual (los mismos URIs con permiso persistente
  de la FASE 6).

**Se perdió (documentado, no oculto):**
- No hay envío 100% automático en segundo plano — el usuario da un toque
  final de "Enviar" en la otra aplicación.
- No hay confirmación programática de que el correo salió — por eso el
  estado final honesto es "Enviando", con confirmación manual disponible
  desde el Historial.
- No queda copia automática en "Elementos enviados" controlada por esta
  app — eso lo maneja la app de correo receptora por su cuenta, como
  cualquier correo normal que se envíe desde ahí.

## Si más adelante sí se logra el acceso a Entra ID

El motor de reglas y plantillas no cambiaría en nada — solo habría que
reemplazar la llamada a `launchEmailIntent(...)` en `ChatViewModel.confirmPreview()`
por una llamada real a Microsoft Graph, y el estado pasaría a `ENVIADO` con
certeza en vez de `ENVIANDO`. El resto de la aplicación queda igual.

## Para actualizar tu repo

Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre). El
workflow (`main.yml`) no cambia.
