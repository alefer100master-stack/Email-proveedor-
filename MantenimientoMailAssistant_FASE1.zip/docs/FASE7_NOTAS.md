# FASE 7 — Notas técnicas (Motor de reglas)

## Qué se construyó

- **`RulesEngine`**: reconoce qué plantilla pide un mensaje comparando su
  texto contra las palabras clave activas (sembradas en la FASE 2),
  tolerando errores de escritura — no exige coincidencia exacta de texto.
- **`SupplierNameMatcher`**: coincidencia aproximada de nombres (distancia
  de Levenshtein + traslape de palabras + detección de "un texto contiene al
  otro"). Es el mecanismo que resuelve el ejemplo que diste: escribir
  "rodamientos skf" debe reconocer a "SKF Colombia".
- **El chat ya responde con reconocimiento real**, no un aviso genérico:
  después de enviar un mensaje, la app dice qué plantilla identificó (o que
  quedó ambiguo, o que no reconoció ninguna) — siendo honesta en que la
  generación real del correo llega en la FASE 8.
- **La búsqueda de Home ahora es difusa**: escribir "rodamientos skf" (o con
  errores de tecleo) encuentra "SKF Colombia" aunque el texto no calce
  exacto — es la aplicación concreta y ya visible de `SupplierNameMatcher`.

## Por qué la coincidencia de proveedor no se usa dentro del chat todavía

La sección 26 del requerimiento original describe resolver a qué proveedor
te refieres cuando el texto lo menciona por nombre. En esta app, cada chat
ya es de un proveedor específico — al escribir dentro del chat de SKF
Colombia, no hace falta adivinar el proveedor a partir del texto, ya se sabe
por el proveedor cuyo chat abriste (sección 26, primer caso: "si estoy
dentro del chat de X, se usa X"). Por eso `SupplierNameMatcher` se aplicó
donde sí hace falta resolver el proveedor a partir de texto libre: la
búsqueda de Home. El segundo caso de la sección 26 ("mencionar otro
proveedor por nombre aunque no esté en su chat") seguirá relevante si más
adelante se agrega una forma de escribir instrucciones fuera de un chat
específico.

## Por qué la confirmación todavía es solo informativa

El motor ya reconoce la plantilla de verdad (no es una simulación), pero
"confirmar" hoy no dispara nada real todavía porque la generación del correo
(FASE 8) y el envío (FASE 9 en adelante) no existen. Se prefirió no
construir botones de "Confirmar/Cancelar" que no tuvieran ningún efecto real
al tocarlos — eso sí sería una interfaz que aparenta más de lo que hace. La
confirmación con consecuencia real (vista previa del correo, cuenta
regresiva) se conecta en la FASE 8 en adelante.

## Para actualizar tu repo

Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre). El
workflow no cambió.
