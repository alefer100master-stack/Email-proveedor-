# Auditoría técnica de cambios — sobre FASE 1

Este documento registra, uno por uno, los puntos del último mensaje: qué se
pidió, qué se decidió técnicamente, qué riesgo tiene esa decisión, y en qué
fase del plan original queda. Es el mismo estilo de auditoría que ya usas en
tus otros proyectos (recap explícito de decisiones, no solo el código).

## 1. Flujo de compilación: GitHub en vez de Android Studio

**Pedido:** subir el proyecto a GitHub para que se compile solo y poder
descargar el APK, sin depender de Android Studio.

**Decisión:** se agregó `.github/workflows/build-apk.yml`. Reutiliza el mismo
patrón que ya funcionó para *OrganizadorSoportes* (Java 17 + `setup-android` +
Gradle instalado directo en el runner), con una mejora: en vez de dejar el APK
solo como *artifact* de Actions (que en el celular obliga a bajar un .zip y
extraerlo), este workflow además publica un **GitHub Release** con el `.apk`
como archivo adjunto — un solo toque para descargar, sin descomprimir nada.

**Riesgo conocido y cómo se evita esta vez:** la vez pasada, el archivo
`build.yml` quedó corrupto (0 bytes) al crearlo pegando texto en el editor
web de GitHub desde el celular. Esta vez el archivo ya viene armado dentro
del ZIP — la idea es que **subas el archivo tal cual (arrastrar/seleccionar
desde tus archivos), no que lo crees pegando texto a mano** en el cuadro de
edición de GitHub. Ver `FASE1_INSTRUCCIONES.md` para el paso a paso exacto.

**Cambio de fondo:** como ya no hay Android Studio de por medio, tuve que
escribir yo mismo los archivos Gradle reales (antes se los dejaba generar al
asistente de "Nuevo proyecto"). Elegí versiones **fijas y documentadas por su
compatibilidad cruzada**, no las más nuevas posibles:

| Componente | Versión | Por qué |
|---|---|---|
| Android Gradle Plugin | 8.5.2 | Mínimo documentado: Gradle ≥ 8.7 |
| Gradle (instalado en el workflow) | 8.9 | Cumple el mínimo de AGP con margen |
| Kotlin | 2.0.0 | Primera versión con el plugin nuevo de Compose (`org.jetbrains.kotlin.plugin.compose`), evita tener que fijar a mano un `kotlinCompilerExtensionVersion` que combine mal con el Kotlin elegido — ese desajuste es la causa más común de builds de Compose rotos |
| compileSdk / targetSdk | 34 | Techo soportado por AGP 8.5.x |
| minSdk | 26 | Cubre prácticamente cualquier celular en uso hoy |
| JDK | 17 | Requerido por AGP 8.5+ |

**Esto no se compiló aquí** (mi entorno de trabajo no tiene SDK de Android ni
internet — lo confirmé antes de escribir nada). Es la combinación más segura
que puedo justificar con documentación oficial, pero el primer build real es
el que corre en GitHub Actions. Si falla, el log de la pestaña **Actions** te
va a decir exactamente en qué paso — pégamelo y lo corrijo contra ese error
real.

## 2. Correo de envío configurable en Ajustes

**Pedido:** poder definir en Configuración desde qué correo se envían los
mensajes.

**Decisión:** con Microsoft Graph, el envío (`/me/sendMail`) siempre sale
desde la cuenta que se autentica con MSAL — no se puede "escribir" un correo
cualquiera como remitente. Lo que Configuración va a mostrar es **qué cuenta
Microsoft está conectada** (botón "Conectar cuenta Outlook", igual que en el
requerimiento original sección 13), y esa es la que actúa como remitente.

Si más adelante necesitas enviar como un buzón compartido distinto al tuyo
(por ejemplo `mantenimiento@h2ocolombia.com` en vez de tu correo personal),
eso es técnicamente posible pero necesita: (a) permiso `Mail.Send.Shared` en
el App Registration, con consentimiento de un administrador de Microsoft 365,
y (b) que ese buzón te delegue acceso de envío. Lo dejo documentado como
opción futura en la FASE 9 — no es algo que se pueda activar solo con un
campo de texto en la app, por eso no lo prometo como si ya funcionara.

## 3. Botón de importar Excel también en Configuración

**Pedido:** que el botón de subir el Excel de proveedores esté también en
Ajustes (no solo en Home).

**Decisión:** confirmado — el placeholder de Configuración ya quedó anotado
con esto. La lógica de importación (FASE 4) es una sola; en FASE 13 solo se
agrega un segundo punto de entrada que llama a la misma pantalla/flujo de
importación.

## 4. Reconocimiento aproximado del nombre del proveedor

**Pedido:** que si escribes "rodamientos skf" (con errores/variaciones) la
app entienda que es "SKF Colombia", sin exigir el nombre exacto — y que
confirme con una pregunta antes de enviar.

**Decisión técnica:** en vez de solo normalizar mayúsculas/acentos (lo que ya
pedía el requerimiento original, sección 8), se agrega un paso de
**coincidencia aproximada** sobre los nombres de proveedor ya importados:

1. Se tokeniza el texto del usuario y el nombre de cada proveedor.
2. Se calcula una similitud (distancia de Levenshtein normalizada + traslape
   de tokens) entre lo escrito y cada proveedor.
3. Si un proveedor supera un umbral alto de confianza y ningún otro se le
   acerca → se usa ese, pero **igual se pide confirmación** ("¿Enviar orden
   de compra a SKF Colombia?").
4. Si dos proveedores quedan cerca en similitud (por ejemplo "SKF Colombia" y
   "SKF Industrial") → no se elige ninguno de entrada: se pregunta "¿Cuál
   proveedor?" con las opciones, tal como ya lo pedía la sección 26 del
   requerimiento original.
5. Si nada supera un umbral mínimo → se pide que aclare el nombre, nunca se
   envía a un proveedor "adivinado".

Esto se implementa en la **FASE 7** (motor de reglas), porque necesita la
lista real de proveedores importados (FASE 2-4) para comparar contra algo —
construirlo ahora sería simular una función crítica con datos falsos, y eso
es justo lo que el requerimiento original prohíbe (sección 35).

## 5. Confirmación antes de enviar

**Pedido:** confirmar con una pregunta antes de enviar.

**Decisión:** esto ya estaba en el requerimiento original (vista previa +
botones CANCELAR/ENVIAR, sección 1 y 14). Con la coincidencia aproximada del
punto 4, ahora hay **dos confirmaciones posibles**: una para el proveedor (si
la coincidencia no fue exacta) y otra para el envío en sí (vista previa del
correo). Quedan como pasos separados para no mezclar "¿es este el
proveedor correcto?" con "¿este correo específico está bien?".

## 6. Chat con historial

**Pedido:** recordatorio de que la interfaz es un chat donde puedes ver qué
enviaste.

**Confirmado, sin cambios de fondo:** esto ya es la sección 6 del
requerimiento original (pantalla de chat por proveedor) más la sección 15
(Historial global con filtros). Se construyen en FASE 5 y FASE 12
respectivamente. En FASE 1 ya existe la navegación hacia ambas (como
pantallas placeholder).

## 7. Cuenta regresiva cancelable antes de enviar

**Pedido:** una alternativa donde, tras confirmar, empiece una cuenta
regresiva; si no cancelas antes de que termine, ahí sí se envía — y que sea
una opción predeterminada configurable en Ajustes.

**Decisión técnica:** se agrega como un **modo de confirmación** dentro de
Configuración, junto al modo manual que ya existía:

- **Manual:** vista previa + esperar a que toques ENVIAR (comportamiento
  original, sección 14).
- **Cuenta regresiva cancelable:** tras confirmar el envío, arranca una
  cuenta regresiva (duración configurable, ej. 5–30 s) con un botón
  **Cancelar** siempre visible. Si no cancelas, se envía automáticamente al
  llegar a cero. Si cancelas, el correo queda en estado `CANCELADO` en el
  historial — igual de auditado que uno enviado.

Ya construí el componente visual de esta cuenta regresiva (`SendCountdownBar`,
incluido en este ZIP) para que puedas ver y sentir cómo se comporta — el
temporizador real que dispare el envío por Microsoft Graph se conecta en
FASE 10/11, cuando exista el envío real al que enganchar el "se acabó el
tiempo, envía ya".

**Riesgo técnico pendiente, documentado para FASE 11:** si cierras la app (o
Android la mata en segundo plano) mientras la cuenta regresiva está corriendo,
una cuenta regresiva basada solo en un temporizador de la pantalla se
cancelaría con la Activity. Hay que decidir en FASE 11 si eso es aceptable
("si sales de la app, se cancela el envío automático, por seguridad") o si se
necesita un mecanismo que sobreviva en segundo plano (WorkManager). Mi
recomendación por ahora: que salir de la pantalla cancele el envío automático
— es la opción más segura y la más simple de auditar, y evita enviar un
correo que el usuario ya no está mirando.

## 8. Plantillas: alcance inicial de 3, no 6

**Pedido:** por ahora, solo enviar orden de compra, soporte de pago y
documentos para creación de proveedor.

**Decisión:** se reduce el alcance de la FASE 8 a estas 3 plantillas activas.
Las otras 3 del requerimiento original (cotización, envío de documentos
genérico, comunicación general) quedan **definidas en el modelo de datos**
pero inactivas — no aparecen como opción hasta que las pidas, para no
construir plantillas que hoy no vas a usar.

## 9. Diseño visual "futurista" con animación, sin sacrificar rendimiento

**Pedido:** una estética menos plana, con algo de futurismo y animación, sin
afectar el desempeño.

**Decisión de diseño:** en vez de un tema oscuro genérico con acentos de
neón, se tomó como referencia real las **pantallas de control industrial
(HMI/SCADA)** — coherente con que esta es una app para mantenimiento de
planta, no un capricho estético desconectado del contexto:

- Fondo grafito oscuro por defecto (el "modo claro" usa acero frío, no blanco
  plano), un único acento cian que funciona como "semáforo de actividad", y
  el cobre ya usado en FASE 1 pasa a tener un rol semántico fijo
  (advertencias), no decorativo.
- Tipografía monoespaciada reservada solo para datos técnicos (IDs de
  operación, fechas, montos) — refuerza la lectura de instrumento sin
  necesitar tipografías descargadas ni archivos de fuente adicionales.
- **Una sola animación protagonista:** el anillo de cuenta regresiva
  cancelable del punto 7 (`SendCountdownBar`). El resto de la interfaz se
  mantiene quieta a propósito — así la animación comunica algo real ("esto
  está a punto de pasar"), en vez de ser movimiento decorativo repartido por
  toda la pantalla, que es lo que suele afectar el rendimiento percibido en
  equipos de gama media.
- Técnicamente: se usa `Animatable` + `tween` (animación nativa de Compose,
  sin librerías externas de animación) y un "glow" simulado con capas de
  transparencia en vez de `blur`/`RenderEffect`, para que se vea igual desde
  Android 8 (minSdk 26) sin ramas de código por versión de API.

## 10. Lecciones del primer build real (GitHub Actions)

**Error:** `AAPT: error: resource mipmap/ic_launcher ... not found` (y lo mismo
para `ic_launcher_round`). El `AndroidManifest.xml` de FASE 1 ya referenciaba
`@mipmap/ic_launcher` y `@mipmap/ic_launcher_round`, pero nunca se crearon
esos recursos — un descuido real de FASE 1, no un problema del entorno de CI.

**Corrección:** se agregó un ícono adaptable (`mipmap-anydpi-v26/ic_launcher.xml`
+ `ic_launcher_round.xml`, más `drawable/ic_launcher_foreground.xml` y
`values/colors.xml`). Como `minSdk = 26` coincide exactamente con la versión
mínima que soporta íconos adaptables, **no hacen falta PNG de respaldo** para
versiones anteriores de Android — este único recurso cubre todos los
dispositivos que la app soporta. El diseño del ícono es un anillo con un
punto central (mismo motivo visual que el anillo de cuenta regresiva de
`SendCountdownBar`), hecho con formas simples (`<shape>` ovaladas), no con
`pathData` de vector escrito a mano, para no arriesgar otro error de sintaxis
en un recurso tan sensible a errores de compilación.

**Para actualizar tu repo:** solo tienes que volver a subir
`MantenimientoMailAssistant_FASE1.zip` (Add file → Upload files, mismo
nombre, sobrescribe el commit anterior) — no hace falta tocar el workflow de
nuevo, no cambió.

## 11. Checklist de fases — actualizado

Ver `docs/ARQUITECTURA.md`, que ya quedó actualizado con:
- FASE 0 (nueva): CI/CD con GitHub Actions — ✅ entregada en este ZIP.
- FASE 7: ahora incluye coincidencia aproximada de nombre + confirmación.
- FASE 8: alcance inicial reducido a 3 plantillas activas.
- FASE 11: incorpora el modo de cuenta regresiva cancelable y el pendiente
  técnico de qué hacer si la app se cierra durante la cuenta regresiva.
- FASE 13: Configuración ahora incluye explícitamente correo de envío
  (cuenta conectada), botón de importar Excel, administrador de plantillas y
  el selector de modo de confirmación (manual / cuenta regresiva + duración).
