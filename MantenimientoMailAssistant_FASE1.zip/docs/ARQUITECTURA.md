# Arquitectura — Mantenimiento Mail Assistant

## 1. Conflictos técnicos identificados y decisión tomada

| # | Conflicto | Decisión |
|---|---|---|
| 1 | El requerimiento pide "compilar y ejecutar pruebas después de cada fase" (sección 34), pero este entorno de generación de código **no tiene SDK de Android, ni Gradle, ni acceso a internet** (verificado). | La compilación/pruebas reales ocurren en tu Android Studio local. Cada fase se entrega completa y lista para compilar; si falla, pega el error y se corrige contra ese error real, no contra suposiciones. |
| 2 | MSAL + Microsoft Graph requieren un **App Registration en Microsoft Entra ID** (Client ID, Redirect URI, permisos `Mail.Send`, consentimiento). Esto es 100% externo y no se puede inventar. | Se documentará paso a paso en la FASE 9, pero **tú** debes crear el registro en https://entra.microsoft.com. Hasta entonces no hay forma de probar el envío real. |
| 3 | Apache POI (lectura de `.xlsx`) es pesado y da problemas de *split package* / tamaño de APK en Android. | Para la FASE 4 se evaluará una librería más ligera orientada a Android (o POI con exclusiones específicas), decidiendo con pruebas reales de importación, no de memoria. |
| 4 | La sección 16 pide "no guardar tokens manualmente", pero también "no usar SharedPreferences en texto plano". MSAL para Android ya trae su propio caché cifrado de tokens. | No se reimplementa almacenamiento de tokens: se usa el *token cache* nativo de MSAL tal cual, sin tocarlo. |
| 5 | Adjuntar archivos vía SAF "sin copiar innecesariamente" (sección 7) requiere permisos persistentes sobre la URI, que Android revoca si no se solicitan explícitamente. | En FASE 6 se llamará `takePersistableUriPermission` al adjuntar, y se validará al abrir el archivo que el permiso siga vivo (si no, se le pide al usuario volver a adjuntar). |
| 6 | MODO AUTOMÁTICO (sección 17) envía sin confirmación humana. | Se implementa, pero solo puede activarse regla por regla desde Configuración > Reglas, nunca de forma global, y cada envío automático queda igual de auditado que uno manual. |

## 2. Estructura de paquetes (destino final, se va llenando fase a fase)

```
com.h2ocolombia.mailassistant
├── navigation/        UI base ✅ (FASE 1)
├── ui/
│   ├── theme/          ✅ (FASE 1)
│   └── screens/
│       ├── home/       ✅ (FASE 1)
│       ├── placeholder/✅ (FASE 1, temporal)
│       ├── supplierchat/   (FASE 5)
│       ├── importexcel/    (FASE 4)
│       ├── settings/       (FASE 13)
│       ├── history/        (FASE 12)
│       └── rules/          (FASE 7/9)
├── data/
│   ├── local/ (Room: entidades, DAOs, Database)   (FASE 2)
│   └── excel/ (importador .xlsx)                  (FASE 4)
├── domain/
│   ├── model/                                     (FASE 2)
│   ├── rules/ (RulesEngine, IntentParser)          (FASE 7)
│   └── templates/ (EmailTemplateEngine)            (FASE 8)
├── auth/ (wrapper sobre MSAL)                      (FASE 9)
├── email/ (cliente Microsoft Graph)                (FASE 10/11)
├── files/ (gestor de adjuntos vía SAF)              (FASE 6)
└── audit/ (EmailLog, historial)                    (FASE 12)
```

## 3. Stack de referencia

> El proyecto ya NO depende del asistente de Android Studio para fijar
> versiones (el build corre en GitHub Actions, sin Android Studio de por
> medio) — por eso estas versiones quedan **fijas** en los archivos Gradle
> reales del proyecto, elegidas por su compatibilidad cruzada documentada
> (detalle en `docs/AUDITORIA_CAMBIOS.md`, sección 1).

- Kotlin 2.0.0, Android Gradle Plugin 8.5.2, Gradle 8.9, JDK 17.
- Jetpack Compose (BOM `2024.09.02`) + Material 3, con el plugin
  `org.jetbrains.kotlin.plugin.compose` (sin fijar a mano un
  `kotlinCompilerExtensionVersion`).
- Navigation Compose, Lifecycle ViewModel Compose.
- Room (FASE 2) para base de datos local.
- MSAL Android `com.microsoft.identity.client:msal` (≈8.4.x) (FASE 9).
- Llamadas a Microsoft Graph vía REST directo (`/me/sendMail`) con
  OkHttp/Retrofit y el *access token* de MSAL como Bearer — se evita traer el
  SDK completo de Graph (mucho más pesado de lo que esta app necesita).
- DI: contenedor manual sencillo (una clase `AppContainer`), no Hilt, para
  minimizar dependencias — se puede migrar a Hilt más adelante si el proyecto
  crece.
- Coincidencia aproximada de nombres de proveedor (FASE 7): distancia de
  Levenshtein normalizada + traslape de tokens, implementado en Kotlin puro
  (sin librería externa) para no sumar dependencias por una función acotada.

## 4. Checklist de fases

> Detalle completo de los cambios de alcance y su justificación en
> `docs/AUDITORIA_CAMBIOS.md`.

- [x] FASE 0 — CI/CD con GitHub Actions (build + Release descargable) ✅
- [~] FASE 1 — Proyecto Android + UI base + identidad visual (en progreso)
- [ ] FASE 2 — Base de datos Room
- [ ] FASE 3 — CRUD de proveedores
- [ ] FASE 4 — Importación Excel
- [ ] FASE 5 — Chat e historial
- [ ] FASE 6 — Archivos adjuntos
- [ ] FASE 7 — Motor de reglas: normalización + **coincidencia aproximada del
      nombre del proveedor** (tolera errores de escritura) con confirmación
      obligatoria si la coincidencia no es exacta o es ambigua
- [ ] FASE 8 — Plantillas: **alcance inicial = 3 activas** (orden de compra,
      soporte de pago, creación de proveedor); cotización / envío genérico /
      comunicación general quedan modeladas pero inactivas
- [ ] FASE 9 — MSAL
- [ ] FASE 10 — Microsoft Graph
- [ ] FASE 11 — Envío con adjuntos + **modo de cuenta regresiva cancelable**
      (alternativa al envío manual; pendiente de decidir comportamiento si la
      app se cierra durante la cuenta regresiva — ver auditoría)
- [ ] FASE 12 — Auditoría
- [ ] FASE 13 — Configuración: cuenta Outlook conectada (correo de envío),
      botón de importar/reimportar Excel, administrador de plantillas, modo
      de confirmación de envío (manual / cuenta regresiva) y su duración
- [ ] FASE 14 — Tests
- [ ] FASE 15 — Build release
