# FASE 4 — Notas técnicas (Importación Excel)

## Qué se construyó

Pantalla de importación con el flujo de la sección 20 del requerimiento
original: seleccionar archivo → detectar columnas → previsualizar filas
clasificadas (Nuevo / Actualizar / Duplicado / Error) con resumen de
conteos → confirmar → resultado final.

## Decisión más importante: lector de Excel propio, sin Apache POI

Apache POI es la librería más común para leer .xlsx en Java, pero tiene
incompatibilidades documentadas en Android: partes de POI referencian
`java.awt.*`, que **no existe** en el runtime de Android (no es una versión
recortada de Java, es un runtime distinto), lo que puede producir
`NoClassDefFoundError` en tiempo de ejecución dependiendo de qué rutas de
código se toquen — un riesgo difícil de descartar sin poder compilar y
probar en un dispositivo real desde este entorno.

En cambio, un archivo `.xlsx` es técnicamente un `.zip` con XML adentro.
`XlsxReader.kt` lo lee usando únicamente:
- `java.util.zip.ZipInputStream` (Java estándar)
- `android.util.Xml.newPullParser()` (parte del SDK de Android desde
  siempre, no requiere ninguna dependencia de Gradle)

Esto cubre exactamente lo que la app necesita (texto de celdas de la
primera hoja) sin traer una librería pesada de hojas de cálculo completa.
Soporta celdas de texto compartido, texto en línea, números/fechas como
texto, y resuelve fórmulas usando su valor ya calculado.

## Cambio de esquema: se agregó `contactName` a `Supplier`

La sección 3 del requerimiento original lista "CONTACTO" como una de las
columnas **mínimas** del Excel — y la entidad `Supplier` de la FASE 2 no
tenía ese campo. Se agregó ahora (`contactName: String?`), y se propagó al
formulario de la FASE 3 y a la pantalla de detalle. Como el esquema todavía
está en `version = 1` y la app nunca se ha publicado con datos reales, este
es un cambio aditivo seguro — no hizo falta escribir una `Migration`. A
partir de la FASE 15 (build release), cualquier cambio de esquema similar sí
la necesitaría.

## Reconocimiento de columnas

Automático, por una lista de alias normalizados (sin tildes, minúsculas,
espacios/guiones bajos colapsados): PROVEEDOR/NOMBRE, CONTACTO, EMPRESA,
NIT, TELEFONO, WHATSAPP, CORREO/CORREO_2/CORREO_3, CATEGORIA, CIUDAD,
DIRECCION, OBSERVACIONES, ACTIVO. `ID_PROVEEDOR` se ignora a propósito (Room
genera sus propios ids).

**Lo que NO se construyó todavía:** el remapeo manual completo (elegir cada
columna a mano con un desplegable) que pide la sección 20 para cuando los
encabezados no coincidan con ningún alias conocido. Si tu Excel real usa
encabezados muy distintos, hoy el importador se detiene con un mensaje claro
en vez de adivinar — el remapeo manual queda pendiente para cuando tengamos
un archivo real que lo necesite.

## Reglas de importación

- **Sin nombre → Error** (no se crea nada).
- **Nombre repetido dentro del mismo archivo → Duplicado** (solo se importa
  la primera aparición).
- **Ya existe un proveedor con ese nombre normalizado → Actualizar**, sin
  borrar datos existentes con campos en blanco del Excel (sección 3: "NO
  sobrescribir silenciosamente información existente"). Los correos que el
  proveedor ya tenía no se tocan; solo se agregan los correos nuevos del
  archivo que no existían antes.
- **Sin correo → se importa igual, pero con una advertencia visible** en la
  vista previa (sección 3 pide "detectar", no necesariamente rechazar).
- Todos los correos importados quedan con tipo "General" — se pueden
  reclasificar después desde Editar proveedor (FASE 3).

## Para actualizar tu repo

Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre). El
workflow no cambió.
