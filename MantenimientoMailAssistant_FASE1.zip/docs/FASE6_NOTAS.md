# FASE 6 — Notas técnicas (Archivos adjuntos)

## Qué se construyó

El botón de adjuntar del chat (FASE 5, hasta ahora solo mostraba un aviso)
ya abre el selector de archivos del sistema (SAF) y permite elegir uno o
varios archivos. Antes de enviarlos quedan como chips removibles arriba del
cuadro de texto; al tocar "Enviar" se guardan junto con el mensaje.

## Validaciones (sección 7 del requerimiento original)

- **Tipo permitido**: PDF, JPG, JPEG, PNG, WEBP, DOCX, XLSX — se valida por
  tipo MIME primero, con la extensión del archivo como respaldo si el
  proveedor de archivos no da un MIME reconocible.
- **Tamaño máximo**: se compara contra `maxAttachmentSizeMb` de
  `AppSettings` (25 MB por defecto — configurable en la FASE 13). Si un
  archivo no pasa alguna validación, se avisa con un mensaje claro (Snackbar)
  y no se agrega a los pendientes.
- **Permiso persistente sobre la URI** (`takePersistableUriPermission`): así
  no hace falta copiar el archivo — se guarda la URI, tal como pide la
  sección 7 ("No copiar archivos innecesariamente"). Si el proveedor de
  archivos no soporta permisos persistentes (pasa con algunos gestores),
  igual se puede adjuntar; solo no sobrevive si el proceso de la app muere
  antes de enviarlo.

## Qué se guarda por adjunto

Nombre original, tipo MIME, tamaño y la URI — exactamente los campos que ya
tenía la entidad `Attachment` desde la FASE 2. Se muestra "📎 nombre.pdf ·
240 KB" tanto en el chip pendiente como ya dentro del mensaje enviado.

## Qué NO se construyó todavía (a propósito)

- Abrir o previsualizar el archivo adjunto dentro de la app (hoy solo se ve
  su nombre y tamaño). No lo pedía explícitamente esta fase, y evita sumar
  otro punto de riesgo de compilación (intents de vista externa, FileProvider,
  etc.) sin necesidad real todavía.
- Adjuntar documentos para creación de proveedor (sección 27, "varios
  documentos con una sola instrucción") — ya es técnicamente posible porque
  el selector permite elegir varios archivos a la vez, pero la lógica que
  interpreta "enviar documentos para creación de proveedor" como una sola
  acción llega con el motor de reglas (FASE 7).

## Para actualizar tu repo

Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre). El
workflow no cambió.
