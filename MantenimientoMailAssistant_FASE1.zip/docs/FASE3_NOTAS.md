# FASE 3 — Notas técnicas (CRUD de proveedores)

## Qué se construyó

- **Crear proveedor**: pantalla nueva (`supplier_new`), accesible desde el
  botón "Nuevo proveedor" de Home. Formulario con nombre, razón social, NIT,
  teléfono, WhatsApp, categoría, ciudad, dirección, observaciones, y una
  lista dinámica de correos (cada uno con tipo — Compras/Facturación/etc. —
  y descripción).
- **Editar proveedor**: misma pantalla de formulario, reutilizada en modo
  edición (`supplier_edit/{id}`), con un interruptor adicional para
  activar/desactivar el proveedor.
- **Ver proveedor**: al tocar una tarjeta en Home, en vez del aviso de
  "próximamente" ahora se ve una pantalla real con todos los datos y sus
  correos, con un botón de editar en la barra superior.

## Decisiones y su porqué

**La ruta `supplier_chat/{id}/{nombre}` ahora muestra el detalle real, no un
placeholder.** El chat de verdad todavía no existe (llega en FASE 5), pero
mostrar los datos del proveedor ahí mismo es más útil hoy que un aviso vacío
— no es una implementación falsa del chat, es la pantalla de detalle que de
todas formas hacía falta. Cuando la FASE 5 construya el chat, esta pantalla
gana una sección/pestaña de mensajes; no se descarta.

**Validaciones antes de guardar:**
- Nombre obligatorio.
- Cada correo con contenido debe tener formato válido (regex simple).
- Nombre duplicado: se compara contra `normalizedName` (de la FASE 2) contra
  todos los proveedores existentes, excluyendo al mismo proveedor si se está
  editando. Si hay coincidencia, se avisa antes de guardar — no se bloquea
  con un error genérico de base de datos.

**Reconciliación de correos al editar.** En vez de borrar todos los correos
y volver a crearlos (lo que perdería sus ids y podría romper referencias
futuras desde EmailLog), se comparan los correos que llegan del formulario
contra los que ya existen: los que ya no están se borran, los que traen id
se actualizan, los nuevos (`id == null`) se insertan.

**Proveedor "desactivado", no borrado.** No hay botón de eliminar
definitivo — coincide con la sección 5 del requerimiento original
("proveedores activos/inactivos") y con el criterio de auditabilidad de la
sección 38.

## Qué NO se construyó todavía (a propósito)

- El chat funcional (adjuntos, mensajes, envío) — FASE 5 en adelante.
- Importación desde Excel — FASE 4 (el botón ya existe en Home y en el
  aviso de Configuración, pero todavía no hace nada).

## Para actualizar tu repo

Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre). El
workflow no cambió.
