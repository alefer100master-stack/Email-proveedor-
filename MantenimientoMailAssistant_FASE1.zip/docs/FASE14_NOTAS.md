# FASE 14 — Notas técnicas (Tests)

## Qué se construyó

Pruebas unitarias JVM (JUnit 4, sin necesitar emulador ni dispositivo) para
toda la lógica de dominio que no depende del framework de Android:

- `LevenshteinDistanceTest`
- `SupplierNameMatcherTest` (incluye la prueba de regresión del hallazgo de
  abajo)
- `RulesEngineTest`
- `TemplateEngineTest`
- `ExcelColumnMapperTest`
- `AttachmentPolicyTest`
- `TextNormalizationTest`, `ValidationTest`, `FileSizeTest`

Corren con `gradle testDebugUnitTest`, ya agregado como paso del workflow de
GitHub Actions **antes** de compilar el APK — si una prueba falla, el build
se detiene ahí y no llega a generar un APK con un error conocido adentro.

**Para que esto tome efecto, esta vez sí hay que actualizar el `main.yml`**
en GitHub (ver `FASE1_INSTRUCCIONES.md` para dónde está) — es la primera vez
desde que se creó que el workflow mismo cambia, porque se le agregó el paso
de pruebas.

## Un bug real, encontrado por las pruebas, no solo por inspección

Al escribir la prueba de `SupplierNameMatcher` con tu ejemplo real
("rodamientos skf"), usando los mismos 4 proveedores de ejemplo de la app,
se encontró que el algoritmo **casi empataba** entre "SKF Colombia" y "ABC
Rodamientos" — porque "rodamientos" (una palabra de categoría) pesaba igual
que "skf" (el identificador distintivo) en la fórmula de traslape de
palabras. Se verificó con números reales (no solo revisando el código) y se
corrigió bajándole peso a un conjunto acotado de palabras genéricas de
nombres de empresa (`rodamientos`, `servicios`, `distribuidora`, `sas`,
`colombia`, etc. — ver `SupplierNameMatcher.kt`).

La prueba `partial lowercase name with a generic word resolves to the
distinctive brand` queda como guarda de regresión: si alguien vuelve a tocar
esa función y rompe la corrección, esta prueba lo va a detectar.

**Limitación que quedó documentada, no oculta:** esta corrección funciona
bien para consultas cortas tipo buscador (como el cuadro de Home). Para
frases completas largas con palabras de relleno ("enviar orden de compra a
rodamientos skf") todavía no resuelve bien — pero eso no afecta ningún flujo
real de la app hoy, porque `SupplierNameMatcher` solo se usa en el buscador
de Home (ver FASE 7), no para interpretar mensajes completos del chat.

## Qué NO se probó (y por qué)

- **`XlsxReader`** usa `android.util.Xml`, una clase del framework de
  Android que no existe en una prueba JVM normal — necesitaría pruebas
  instrumentadas (con emulador) o Robolectric, ninguno disponible en este
  flujo de compilación en la nube. Se probó indirectamente a través de
  `ExcelColumnMapper`, que sí es JVM puro.
- **ViewModels** (`ChatViewModel`, `SupplierFormViewModel`, etc.): dependen
  de Room/Context/corrutinas de Android — probarlos bien requiere
  `kotlinx-coroutines-test` y, para algunos, Robolectric. Se dejó fuera de
  esta tanda para no sumar más dependencias/riesgo de compilación a una
  entrega ya grande; la lógica de negocio que sí importa (motor de reglas,
  plantillas, coincidencia de nombres, importador) ya quedó cubierta donde
  vive de verdad: en los objetos de dominio puros que los ViewModels solo
  invocan.

## Para actualizar tu repo

1. Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre).
2. **Esta vez además**: entra a tu `main.yml` en GitHub y reemplázalo por el
   contenido de `.github/workflows/build-apk.yml` de este zip (o pégame el
   contenido de tu `main.yml` actual y te digo exactamente qué línea
   agregar).
