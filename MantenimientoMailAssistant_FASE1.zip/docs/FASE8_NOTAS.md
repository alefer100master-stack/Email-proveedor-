# FASE 8 — Notas técnicas (Plantillas)

## Qué se construyó

- **`TemplateEngine`**: reemplazo literal de `{{VARIABLE}}` en asunto y
  cuerpo — exactamente la sintaxis de la sección 10 del requerimiento
  original.
- **`TemplateVariableBuilder`**: arma el mapa de variables disponibles hoy:
  `{{PROVEEDOR}}`, `{{CONTACTO}}`, `{{EMPRESA}}`, `{{FECHA}}`, `{{USUARIO}}`,
  `{{NOMBRE_ARCHIVO}}`. `{{NUMERO_OC}}`, `{{ASUNTO}}` y `{{DESCRIPCION}}`
  quedan reconocidas pero vacías — no hay todavía ningún lugar en la app
  donde el usuario indique esos datos.
- **Vista previa real del correo** dentro del chat: cuando el motor de
  reglas (FASE 7) reconoce una plantilla, ahora se genera el correo de
  verdad (asunto y cuerpo con las variables ya reemplazadas) y se muestra
  con los botones **Cancelar/Enviar** de la sección 1 del requerimiento
  original — ya no es solo un aviso de texto.
- **Auditoría real desde ahora**: al mostrarse la vista previa, ya se crea
  una fila en `EmailLog` con estado `PREPARADO`. Al tocar Cancelar o Enviar,
  esa misma fila pasa a `CANCELADO` o `CONFIRMADO` — el estado que pedía la
  sección 15 del requerimiento original, ya funcionando de verdad (la FASE
  12 le pondrá una pantalla encima para verlo).

## La validación de "correo de tipo X" ya es real (sección 11)

Antes de preparar cualquier correo, se verifica que el proveedor tenga un
correo del tipo que la plantilla necesita (Compras para orden de compra,
Facturación para soporte de pago, etc.). Si no existe, no se prepara nada —
se avisa exactamente qué falta, tal como pide la sección 11: *"Si el correo
requerido no existe: NO enviar."*

## Por qué "Enviar" no envía un correo de verdad todavía

Confirmar hoy marca el `EmailLog` como `CONFIRMADO`, pero no dispara ningún
envío real — eso necesita Microsoft Graph (FASE 10), que a su vez necesita
la cuenta de Outlook conectada (FASE 9), que a su vez necesita que tú crees
el App Registration en Entra ID. El mensaje que ve el usuario al confirmar
lo dice de forma explícita, para no aparentar que el correo ya salió cuando
no fue así.

## Qué NO se construyó todavía (a propósito)

- La cuenta regresiva cancelable (`SendCountdownBar`, ya construida desde la
  FASE 1) no se conectó aquí — está pensada para el momento en que exista un
  envío real que contar hacia atrás (FASE 11). Conectarla ahora, sin nada
  real al final de la cuenta, sería una animación sin función.
- Administrar plantillas desde una pantalla (editar asunto/cuerpo a mano) —
  eso es parte de la FASE 13 (Configuración).

## Para actualizar tu repo

Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre). El
workflow no cambió.
