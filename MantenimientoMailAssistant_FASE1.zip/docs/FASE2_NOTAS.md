# FASE 2 — Notas técnicas (Base de datos Room)

## Qué se construyó

Las 9 entidades mínimas que pide la sección 4 del requerimiento original
(Supplier, SupplierEmail, ChatThread, ChatMessage, Attachment, EmailTemplate,
KeywordRule, EmailLog, AppSettings), sus DAOs, el `AppDatabase`, y un
`DatabaseSeeder` que carga datos de referencia reales la primera vez que la
app arranca. `HomeScreen` ya no usa datos de ejemplo hardcodeados — lee de
Room a través de `HomeViewModel`.

(El "Chat" del requerimiento original se llama `ChatThread` en el código,
para no confundirlo con el paquete de UI del chat.)

## Decisiones y su porqué

**Procesador de anotaciones: KSP, no KAPT.** Se usó
`com.google.devtools.ksp` versión `2.0.0-1.0.21` — verificada como
compatible con Kotlin 2.0.0 (confirmado por reportes de otros proyectos
usando esa combinación exacta en Android). KSP es más rápido que KAPT y es
lo que Google recomienda para proyectos nuevos con Room.

**`normalizedName` precalculado en `Supplier`.** Se guarda el nombre sin
tildes/minúsculas/espacios colapsados junto al nombre original (nunca se
muestra al usuario, solo sirve para comparar). Esto es exactamente lo que
pide la sección 20 del requerimiento original para detectar duplicados en la
FASE 4, y es la misma normalización que la FASE 7 va a necesitar para la
coincidencia aproximada — se implementó una sola vez en
`util/TextNormalization.kt` para no duplicar esa lógica después.

**`@Relation` para evitar N+1.** `SupplierWithEmails` combina un proveedor
con sus correos en una sola consulta reactiva (`SupplierDao.observeActiveWithEmails`),
en vez de que `HomeViewModel` dispare una consulta aparte por cada proveedor
de la lista.

**Datos de referencia precargados, no solo esquema vacío.** El
`DatabaseSeeder` inserta, en el primer arranque: la configuración por
defecto, las 6 plantillas de la sección 10 del requerimiento original (con
las 3 del alcance inicial marcadas `active = true` y las otras 3
`active = false`, según se acordó en `docs/AUDITORIA_CAMBIOS.md`), las
palabras clave de la sección 8, y los mismos 4 proveedores de ejemplo que
FASE 1 mostraba como datos estáticos — ahora son filas reales. Esto no es una
implementación falsa de la FASE 7/8: es la carga de la información de
referencia que esas fases van a necesitar, tal como está descrita en el
requerimiento original.

**Sin `fallbackToDestructiveMigration()`.** `version = 1` por ahora. El día
que el esquema cambie, hace falta escribir una `Migration` explícita — se
prefirió no dejar una salida fácil que borre datos reales del usuario en
silencio, siguiendo la prioridad "confiabilidad primero" de la sección 38.

**Sin Hilt.** Se agregó `AppContainer` (contenedor manual) y
`MailAssistantApp`, tal como ya estaba decidido en `docs/ARQUITECTURA.md`.

## Qué NO se construyó todavía (a propósito)

- Pantallas para crear/editar proveedores a mano — eso es la FASE 3 (CRUD de
  proveedores). FASE 2 solo prueba que los datos ya son reales conectando la
  lista de Home (lectura), no agrega formularios de escritura.
- El motor de coincidencia aproximada (FASE 7) y el uso real de las
  plantillas (FASE 8) — hoy son solo filas en la base de datos, no hay
  código todavía que las lea para decidir qué enviar.

## Para actualizar tu repo

Vuelve a subir `MantenimientoMailAssistant_FASE1.zip` (mismo nombre —
sobrescribe el commit anterior). El workflow no cambió.
