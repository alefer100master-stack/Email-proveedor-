Uso interno — H2O Colombia SAS

Este software fue desarrollado para uso interno del área de mantenimiento de
H2O Colombia SAS. Todos los derechos reservados. No está licenciado para
distribución pública ni uso por terceros fuera de la organización, salvo
autorización expresa.

(Ajusta este archivo si el proyecto va a manejarse bajo otros términos.)
