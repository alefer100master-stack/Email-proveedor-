# Mantenimiento Mail Assistant

App Android nativa (Kotlin + Jetpack Compose) para gestionar comunicaciones
formales con proveedores mediante una interfaz tipo chat, con envío de correo
a través de **Microsoft Graph / Outlook** (MSAL). No usa WhatsApp, no accede a
los contactos del teléfono, y su base de proveedores es propia (importable
desde Excel).

Prioridades del proyecto, en este orden:

**CONFIABILIDAD > SEGURIDAD > AUDITABILIDAD > USABILIDAD > DISEÑO**

## Estado del proyecto

Ver [`docs/ARQUITECTURA.md`](docs/ARQUITECTURA.md) para el análisis de
conflictos técnicos, la arquitectura completa y el checklist de las 15 fases.

**Fase actual: FASE 1 — Proyecto Android + UI base (en progreso).**

## Requisitos

- Una cuenta de GitHub (gratuita). No hace falta Android Studio ni PC — el
  build corre en la nube vía GitHub Actions.
- Cuenta de Microsoft 365 / Entra ID con permisos para crear un **App
  Registration** — necesaria a partir de la FASE 9. No se puede improvisar:
  hay que crearla en https://entra.microsoft.com antes de esa fase.

## Cómo compilar y obtener el APK

Ver [`FASE1_INSTRUCCIONES.md`](FASE1_INSTRUCCIONES.md) — resumen: subes esta
carpeta a un repositorio de GitHub, `.github/workflows/build-apk.yml` la
compila sola, y el APK queda como una Release descargable.

## Auditoría de cambios sobre el requerimiento original

Ver [`docs/AUDITORIA_CAMBIOS.md`](docs/AUDITORIA_CAMBIOS.md): registra, punto
por punto, las decisiones tomadas sobre correo de envío, coincidencia
aproximada de proveedor, cuenta regresiva cancelable, alcance de plantillas,
identidad visual, y el paso de Android Studio a GitHub Actions.

## Aviso importante sobre compilación

Los archivos de este entregable se escribieron en un entorno sin SDK de
Android ni acceso a internet, así que **no se compilaron aquí**. El primer
build real ocurre en GitHub Actions; si falla, se corrige con base en el
error real que reportes — no se avanza a la siguiente fase hasta que la
actual compile y pase sus pruebas, como pide el requerimiento original.
