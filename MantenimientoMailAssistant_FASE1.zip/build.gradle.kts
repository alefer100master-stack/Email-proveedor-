// Versiones fijadas deliberadamente (no "+", no "latest") para que el build en
// GitHub Actions sea reproducible. Ver docs/AUDITORIA_CAMBIOS.md sección 3 para
// el razonamiento de compatibilidad (AGP 8.5.x requiere Gradle >= 8.7; se instala
// Gradle 8.9 en el workflow de CI).
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.0" apply false
}
