# Cómo compilar esto — solo con el celular, vía GitHub

No necesitas Android Studio. El plan es: creas un repositorio en GitHub,
subes estos archivos tal cual (sin escribir ni pegar nada a mano), y GitHub
Actions compila el APK y te lo deja como una Release descargable.

## 1. Crear el repositorio

En GitHub (app o navegador): **New repository** → nómbralo, por ejemplo,
`mantenimiento-mail-assistant` → **Private** (es una app interna de la
empresa) → **Create repository**. Déjalo vacío, sin README ni .gitignore
automáticos (para no chocar con los que ya vienen en este ZIP).

## 2. Subir el proyecto — sin necesitar subir carpetas

Si tu selector de archivos del celular solo te deja elegir archivos sueltos
(sin conservar carpetas), no subas los archivos extraídos uno por uno — en
vez de eso, sube **el .zip completo tal cual, sin extraerlo**. Es un solo
archivo, así que cualquier selector "solo archivos individuales" lo soporta.
El workflow ya viene preparado para descomprimirlo él solo dentro de GitHub
Actions (ver paso 3).

**2.1 Sube el .zip:**
En la página del repo: **Add file → Upload files** → selecciona
`MantenimientoMailAssistant_FASE1.zip` (el archivo que te compartí, sin
extraer) → Commit directo a `main`.

**2.2 Crea el archivo del workflow (la única carpeta que sí hace falta):**
GitHub Actions solo reconoce el workflow si vive exactamente en
`.github/workflows/build-apk.yml`. Para no tener que crear esas carpetas a
mano en tu explorador de archivos, usa la propia interfaz de GitHub:

1. Entra a la pestaña **Actions** del repo.
2. Toca **"set up a workflow yourself"** (o "configure this workflow tú
   mismo"). Esto abre un editor con la ruta `.github/workflows/main.yml` ya
   creada por GitHub — solo cambia el nombre del archivo a `build-apk.yml` si
   quieres, no es obligatorio.
3. Borra el contenido de ejemplo y pega el bloque de abajo completo.
4. Baja hasta el final y toca **Commit changes**.

```yaml
name: Build y publicar APK

on:
  push:
    branches: [ main ]
  workflow_dispatch: {}

permissions:
  contents: write

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Descargar el repositorio
        uses: actions/checkout@v4

      - name: Descomprimir el proyecto
        run: unzip -o MantenimientoMailAssistant_FASE1.zip -d .

      - name: Configurar Java 17
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'

      - name: Configurar Android SDK
        uses: android-actions/setup-android@v3

      - name: Instalar Gradle 8.9
        run: |
          wget -q https://services.gradle.org/distributions/gradle-8.9-bin.zip
          unzip -q gradle-8.9-bin.zip -d "$HOME"
          echo "$HOME/gradle-8.9/bin" >> "$GITHUB_PATH"

      - name: Compilar APK de depuración
        run: gradle assembleDebug --no-daemon --stacktrace

      - name: Preparar el APK para publicar
        run: |
          mkdir -p artefactos
          cp app/build/outputs/apk/debug/app-debug.apk \
             "artefactos/MantenimientoMailAssistant-debug-$(date +'%Y%m%d-%H%M').apk"

      - name: Subir como artefacto de Actions (respaldo)
        uses: actions/upload-artifact@v4
        with:
          name: MantenimientoMailAssistant-apk
          path: artefactos/*.apk

      - name: Publicar como Release descargable
        uses: softprops/action-gh-release@v2
        with:
          tag_name: build-${{ github.run_number }}
          name: "Build automático #${{ github.run_number }}"
          files: artefactos/*.apk
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

**Importante — evitar el problema de la vez pasada:** después de pegar,
antes de tocar "Commit changes", desliza hacia arriba y revisa que el editor
muestre TODO el bloque (varias decenas de líneas), no una sola línea vacía.
Si al pegar se ve raro o incompleto, no hagas commit todavía: activa
"Sitio de escritorio" en tu navegador (⋮ → Desktop site) y vuelve a
intentarlo desde ahí — así se evitó la corrupción del archivo la vez pasada.

Con esos dos elementos en el repo (el .zip + este workflow), cualquier push a
`main` dispara el build solo.

## 3. Verificar que arrancó el build

Ve a la pestaña **Actions** del repo. Debería aparecer solo un run llamado
"Build y publicar APK" (se dispara automáticamente con el push a `main`).
Tócalo para ver el progreso paso a paso.

- Si termina en verde (✓): ve a la pestaña **Releases** (o a la página
  principal del repo, en la barra lateral) — ahí vas a encontrar un release
  como "Build automático #1" con el `.apk` como archivo adjunto. Descárgalo
  directo desde ahí (un solo toque, sin descomprimir nada) e instálalo
  (Android te va a pedir permiso para "instalar apps de fuentes
  desconocidas" la primera vez).
- Si termina en rojo (✗): toca el paso que falló para ver el log completo, y
  pégamelo aquí tal cual (el texto del error, no una descripción). Lo reviso
  contra ese error real — no adivino qué pudo haber sido.

## 4. Qué vas a poder probar en esta FASE 1

La app abre en la pantalla principal (buscador, accesos rápidos, lista de
proveedores de ejemplo). Puedes tocar cualquier proveedor, "Importar Excel",
el ícono de historial o el de configuración: todas navegan a una pantalla que
te dice en qué fase se construye esa función — es lo esperado en FASE 1.
También puedes abrir el archivo `SendCountdownBar.kt` mentalmente (o pedirme
capturas) para ver el diseño de la cuenta regresiva cancelable que se
conectará al envío real más adelante.

## 5. Cada vez que avancemos de fase

El mismo repositorio se reutiliza: te doy los archivos nuevos/modificados de
la fase siguiente, los subes igual (Upload files, sobrescribiendo los que
cambien), y el workflow vuelve a correr solo con cada push — no hay que tocar
`.github/workflows/build-apk.yml` de nuevo salvo que cambiemos algo de la
compilación en sí.
