# Reglas de ProGuard/R8 para el build de release.
#
# Minificación apagada por ahora (isMinifyEnabled = false en
# app/build.gradle.kts) — ver docs/FASE15_NOTAS.md, sección "Por qué la
# minificación queda apagada por ahora". Este archivo queda listo para
# cuando se active.
#
# Room, Jetpack Compose y Kotlin Coroutines ya traen sus propias reglas de
# consumidor empaquetadas dentro de sus .aar — normalmente no hace falta
# nada especial aquí para ellas.
#
# Cuando lleguen MSAL y Microsoft Graph (FASE 9/10), casi seguro van a
# necesitar reglas -keep propias para sus modelos de datos serializados
# (JSON) — agregarlas aquí en ese momento, con base en los errores reales
# que aparezcan al activar la minificación, no de forma preventiva.
