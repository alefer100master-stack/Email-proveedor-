package com.h2ocolombia.mailassistant.domain.templates

import org.junit.Assert.assertEquals
import org.junit.Test

class TemplateEngineTest {

    @Test
    fun `replaces a single variable`() {
        val result = TemplateEngine.render("Hola {{PROVEEDOR}}", mapOf("PROVEEDOR" to "SKF Colombia"))
        assertEquals("Hola SKF Colombia", result)
    }

    @Test
    fun `replaces multiple different variables`() {
        val result = TemplateEngine.render(
            "De: {{USUARIO}} Para: {{PROVEEDOR}}",
            mapOf("USUARIO" to "Alejandro", "PROVEEDOR" to "SKF Colombia")
        )
        assertEquals("De: Alejandro Para: SKF Colombia", result)
    }

    @Test
    fun `replaces the same variable when it repeats`() {
        val result = TemplateEngine.render(
            "{{PROVEEDOR}} - copia para {{PROVEEDOR}}",
            mapOf("PROVEEDOR" to "SKF Colombia")
        )
        assertEquals("SKF Colombia - copia para SKF Colombia", result)
    }

    @Test
    fun `unrecognized variables are left as-is instead of crashing`() {
        val result = TemplateEngine.render("Asunto: {{ASUNTO}}", emptyMap())
        assertEquals("Asunto: {{ASUNTO}}", result)
    }

    @Test
    fun `template with no variables is returned unchanged`() {
        val result = TemplateEngine.render("Cordialmente,\nÁrea de Mantenimiento", mapOf("PROVEEDOR" to "X"))
        assertEquals("Cordialmente,\nÁrea de Mantenimiento", result)
    }
}
