package com.h2ocolombia.mailassistant.domain.rules

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private data class FakeSupplier(val name: String)

class SupplierNameMatcherTest {

    // Los mismos 4 proveedores de ejemplo que siembra DatabaseSeeder — así
    // esta prueba usa datos reales de la app, no un caso inventado aparte.
    private val seedSuppliers = listOf(
        FakeSupplier("SKF Colombia"),
        FakeSupplier("ABC Rodamientos"),
        FakeSupplier("Automatización XYZ"),
        FakeSupplier("Neumática Industrial")
    )

    @Test
    fun `exact name always resolves to a single match`() {
        val result = SupplierNameMatcher.match("SKF Colombia", seedSuppliers) { it.name }
        assertTrue(result is SupplierMatchResult.SingleMatch)
        assertEquals("SKF Colombia", (result as SupplierMatchResult.SingleMatch).candidate.name)
    }

    /**
     * Guarda de regresión: esta consulta exacta ("rodamientos skf") casi
     * empataba entre "SKF Colombia" y "ABC Rodamientos" antes de bajarle
     * peso a las palabras genéricas de nombres de empresa — ver el
     * comentario en SupplierNameMatcher.kt y docs/FASE14_NOTAS.md. Si esta
     * prueba empieza a fallar, es señal de que esa corrección se rompió.
     */
    @Test
    fun `partial lowercase name with a generic word resolves to the distinctive brand`() {
        val result = SupplierNameMatcher.match("rodamientos skf", seedSuppliers) { it.name }
        assertTrue(
            "se esperaba una sola coincidencia clara, no ambigüedad ni vacío",
            result is SupplierMatchResult.SingleMatch
        )
        assertEquals("SKF Colombia", (result as SupplierMatchResult.SingleMatch).candidate.name)
    }

    @Test
    fun `short brand-only query resolves correctly`() {
        val result = SupplierNameMatcher.match("skf", seedSuppliers) { it.name }
        assertTrue(result is SupplierMatchResult.SingleMatch)
        assertEquals("SKF Colombia", (result as SupplierMatchResult.SingleMatch).candidate.name)
    }

    @Test
    fun `unrelated text does not match anything`() {
        val result = SupplierNameMatcher.match("factura de energia electrica", seedSuppliers) { it.name }
        assertTrue(result is SupplierMatchResult.NoMatch)
    }

    @Test
    fun `two genuinely similar names are reported as ambiguous, never chosen arbitrarily`() {
        val ambiguousSuppliers = listOf(FakeSupplier("SKF Colombia"), FakeSupplier("SKF Industrial"))
        val result = SupplierNameMatcher.match("skf", ambiguousSuppliers) { it.name }
        assertTrue(result is SupplierMatchResult.Ambiguous)
        assertEquals(2, (result as SupplierMatchResult.Ambiguous).candidates.size)
    }

    @Test
    fun `blank query never matches`() {
        val result = SupplierNameMatcher.match("   ", seedSuppliers) { it.name }
        assertTrue(result is SupplierMatchResult.NoMatch)
    }
}
