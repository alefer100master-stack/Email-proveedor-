package com.h2ocolombia.mailassistant.domain.rules

import com.h2ocolombia.mailassistant.data.local.KeywordRule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RulesEngineTest {

    // Las mismas reglas que siembra DatabaseSeeder para los 3 templates
    // activos del alcance inicial.
    private val activeRules = listOf(
        KeywordRule(templateKey = "PURCHASE_ORDER", keyword = "orden de compra"),
        KeywordRule(templateKey = "PURCHASE_ORDER", keyword = "oc"),
        KeywordRule(templateKey = "PURCHASE_ORDER", keyword = "enviar oc"),
        KeywordRule(templateKey = "PURCHASE_ORDER", keyword = "enviar orden de compra"),
        KeywordRule(templateKey = "PAYMENT_SUPPORT", keyword = "soporte de pago"),
        KeywordRule(templateKey = "PAYMENT_SUPPORT", keyword = "soporte pago"),
        KeywordRule(templateKey = "PAYMENT_SUPPORT", keyword = "enviar soporte de pago"),
        KeywordRule(templateKey = "SUPPLIER_CREATION", keyword = "creacion de proveedor"),
        KeywordRule(templateKey = "SUPPLIER_CREATION", keyword = "crear proveedor")
    )

    @Test
    fun `exact keyword phrase is recognized`() {
        val result = RulesEngine.match("Enviar orden de compra", activeRules)
        assertTrue(result is TemplateMatchResult.Recognized)
        assertEquals("PURCHASE_ORDER", (result as TemplateMatchResult.Recognized).templateKey)
    }

    @Test
    fun `simple typo inside a longer sentence is still recognized`() {
        val result = RulesEngine.match("por favor enviar la ordn de compra ya", activeRules)
        assertTrue(
            "se esperaba reconocer la plantilla a pesar del error de tecleo",
            result is TemplateMatchResult.Recognized
        )
        assertEquals("PURCHASE_ORDER", (result as TemplateMatchResult.Recognized).templateKey)
    }

    @Test
    fun `accents and case do not prevent recognition`() {
        val result = RulesEngine.match("ENVIAR SOPORTE DE PAGO", activeRules)
        assertTrue(result is TemplateMatchResult.Recognized)
        assertEquals("PAYMENT_SUPPORT", (result as TemplateMatchResult.Recognized).templateKey)
    }

    @Test
    fun `unrelated text does not match any template`() {
        val result = RulesEngine.match("hola, como estas hoy", activeRules)
        assertEquals(TemplateMatchResult.NoMatch, result)
    }

    @Test
    fun `blank instruction never matches`() {
        val result = RulesEngine.match("   ", activeRules)
        assertEquals(TemplateMatchResult.NoMatch, result)
    }

    @Test
    fun `no active rules means no match`() {
        val result = RulesEngine.match("enviar orden de compra", emptyList())
        assertEquals(TemplateMatchResult.NoMatch, result)
    }
}
