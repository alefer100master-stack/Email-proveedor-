package com.h2ocolombia.mailassistant.domain.rules

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LevenshteinDistanceTest {

    @Test
    fun `identical strings have distance zero`() {
        assertEquals(0, LevenshteinDistance.compute("skf", "skf"))
    }

    @Test
    fun `one substitution has distance one`() {
        assertEquals(1, LevenshteinDistance.compute("skf", "skg"))
    }

    @Test
    fun `distance against an empty string equals the length of the other`() {
        assertEquals(3, LevenshteinDistance.compute("", "skf"))
        assertEquals(3, LevenshteinDistance.compute("skf", ""))
    }

    @Test
    fun `similarity of identical strings is one`() {
        assertEquals(1.0, LevenshteinDistance.similarity("colombia", "colombia"), 0.0001)
    }

    @Test
    fun `similarity of two empty strings is one (nothing to tell apart)`() {
        assertEquals(1.0, LevenshteinDistance.similarity("", ""), 0.0001)
    }

    @Test
    fun `similarity decreases as strings differ more`() {
        val closeMatch = LevenshteinDistance.similarity("rodamientos", "rodamiento")
        val farMatch = LevenshteinDistance.similarity("rodamientos", "xyz")
        assertTrue("un typo de una letra debería parecerse más que un texto sin relación", closeMatch > farMatch)
    }
}
