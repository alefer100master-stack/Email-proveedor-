package com.h2ocolombia.mailassistant.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextNormalizationTest {

    @Test
    fun `removes accents and lowercases`() {
        assertEquals("automatizacion", normalizeSupplierName("Automatización"))
    }

    @Test
    fun `collapses repeated spaces`() {
        assertEquals("skf colombia", normalizeSupplierName("SKF   Colombia"))
    }

    @Test
    fun `different casings normalize to the same value`() {
        assertEquals(normalizeSupplierName("SKF COLOMBIA"), normalizeSupplierName("skf colombia"))
    }
}

class ValidationTest {

    @Test
    fun `accepts a standard email`() {
        assertTrue(isValidEmail("compras@skf.com"))
    }

    @Test
    fun `rejects text with no at sign`() {
        assertFalse(isValidEmail("comprasskf.com"))
    }

    @Test
    fun `rejects text with no domain`() {
        assertFalse(isValidEmail("compras@"))
    }

    @Test
    fun `trims surrounding spaces before validating`() {
        assertTrue(isValidEmail("  compras@skf.com  "))
    }
}

class FileSizeTest {

    @Test
    fun `formats bytes under one kb`() {
        assertEquals("500 B", formatFileSize(500))
    }

    @Test
    fun `formats kilobytes`() {
        assertEquals("2 KB", formatFileSize(2048))
    }

    @Test
    fun `formats megabytes with one decimal`() {
        assertEquals("2.0 MB", formatFileSize(2 * 1024 * 1024))
    }
}
