package com.h2ocolombia.mailassistant.data.excel

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExcelColumnMapperTest {

    @Test
    fun `recognizes standard headers regardless of accents or case`() {
        val headers = listOf("PROVEEDOR", "CONTACTO", "TELEFONO", "CORREO", "CIUDAD", "ACTIVO")
        val mapping = ExcelColumnMapper.mapHeaders(headers)

        assertEquals(0, mapping.nameColumn)
        assertEquals(1, mapping.contactColumn)
        assertEquals(2, mapping.phoneColumn)
        assertEquals(3, mapping.email1Column)
        assertEquals(4, mapping.cityColumn)
        assertEquals(5, mapping.activeColumn)
    }

    @Test
    fun `unknown columns are simply ignored, not an error`() {
        val headers = listOf("ID_PROVEEDOR", "PROVEEDOR", "CORREO", "COLUMNA_RARA")
        val mapping = ExcelColumnMapper.mapHeaders(headers)

        assertEquals(1, mapping.nameColumn)
        assertEquals(2, mapping.email1Column)
    }

    @Test
    fun `missing name column is reported as null so the importer can stop`() {
        val headers = listOf("TELEFONO", "CORREO")
        val mapping = ExcelColumnMapper.mapHeaders(headers)
        assertNull(mapping.nameColumn)
    }

    @Test
    fun `parses a row into a supplier draft with normalized name`() {
        val headers = listOf("PROVEEDOR", "CORREO", "ACTIVO")
        val mapping = ExcelColumnMapper.mapHeaders(headers)
        val row = listOf("SKF Colombia", "compras@skf.com", "SI")

        val parsed = ExcelColumnMapper.parseRow(row, mapping, rowNumber = 2)

        assertEquals("SKF Colombia", parsed.name)
        assertEquals("skf colombia", parsed.normalizedName)
        assertEquals(listOf("compras@skf.com"), parsed.emails)
        assertTrue(parsed.active)
    }

    @Test
    fun `invalid emails in a row are dropped instead of crashing the import`() {
        val headers = listOf("PROVEEDOR", "CORREO")
        val mapping = ExcelColumnMapper.mapHeaders(headers)
        val row = listOf("SKF Colombia", "esto no es un correo")

        val parsed = ExcelColumnMapper.parseRow(row, mapping, rowNumber = 2)

        assertTrue(parsed.emails.isEmpty())
    }

    @Test
    fun `blank name in a row is preserved as blank so the caller can flag it as an error`() {
        val headers = listOf("PROVEEDOR", "CORREO")
        val mapping = ExcelColumnMapper.mapHeaders(headers)
        val row = listOf("", "compras@skf.com")

        val parsed = ExcelColumnMapper.parseRow(row, mapping, rowNumber = 2)

        assertTrue(parsed.name.isBlank())
    }
}
