package com.h2ocolombia.mailassistant.data.attachments

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AttachmentPolicyTest {

    @Test
    fun `pdf mime type is allowed`() {
        assertTrue(AttachmentPolicy.isAllowed("application/pdf", "orden.pdf"))
    }

    @Test
    fun `xlsx mime type is allowed`() {
        assertTrue(
            AttachmentPolicy.isAllowed(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "reporte.xlsx"
            )
        )
    }

    @Test
    fun `unknown mime type falls back to file extension`() {
        // Pasa con algunos gestores de archivos que devuelven un MIME genérico.
        assertTrue(AttachmentPolicy.isAllowed("application/octet-stream", "foto.jpg"))
    }

    @Test
    fun `unsupported type is rejected even with a mime type`() {
        assertFalse(AttachmentPolicy.isAllowed("application/zip", "comprimido.zip"))
    }

    @Test
    fun `unsupported extension with unknown mime type is rejected`() {
        assertFalse(AttachmentPolicy.isAllowed(null, "video.mp4"))
    }

    @Test
    fun `extension check is case-insensitive`() {
        assertTrue(AttachmentPolicy.isAllowed(null, "FOTO.JPG"))
    }
}
