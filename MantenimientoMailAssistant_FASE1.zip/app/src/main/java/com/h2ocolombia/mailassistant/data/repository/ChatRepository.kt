package com.h2ocolombia.mailassistant.data.repository

import com.h2ocolombia.mailassistant.data.local.Attachment
import com.h2ocolombia.mailassistant.data.local.AttachmentDao
import com.h2ocolombia.mailassistant.data.local.ChatMessage
import com.h2ocolombia.mailassistant.data.local.ChatMessageDao
import com.h2ocolombia.mailassistant.data.local.ChatMessageWithAttachments
import com.h2ocolombia.mailassistant.data.local.ChatThread
import com.h2ocolombia.mailassistant.data.local.ChatThreadDao
import com.h2ocolombia.mailassistant.data.local.MessageSender
import kotlinx.coroutines.flow.Flow

class ChatRepository(
    private val chatThreadDao: ChatThreadDao,
    private val chatMessageDao: ChatMessageDao,
    private val attachmentDao: AttachmentDao
) {
    /**
     * Los proveedores creados desde el formulario (FASE 3) o desde el Excel
     * (FASE 4) no traen un ChatThread propio todavía — se crea aquí, la
     * primera vez que se abre el chat, en vez de exigir que cada camino de
     * creación de proveedor se acuerde de crearlo también.
     */
    suspend fun getOrCreateThreadForSupplier(supplierId: Long): Long {
        val existing = chatThreadDao.findForSupplier(supplierId)
        if (existing != null) return existing.id
        return chatThreadDao.insert(
            ChatThread(supplierId = supplierId, createdAt = System.currentTimeMillis())
        )
    }

    fun observeMessages(chatThreadId: Long): Flow<List<ChatMessageWithAttachments>> =
        chatMessageDao.observeForThreadWithAttachments(chatThreadId)

    suspend fun sendUserMessage(chatThreadId: Long, content: String): Long =
        chatMessageDao.insert(
            ChatMessage(
                chatThreadId = chatThreadId,
                sender = MessageSender.USUARIO,
                content = content,
                timestamp = System.currentTimeMillis()
            )
        )

    suspend fun addSystemNote(chatThreadId: Long, content: String): Long =
        chatMessageDao.insert(
            ChatMessage(
                chatThreadId = chatThreadId,
                sender = MessageSender.APP,
                content = content,
                timestamp = System.currentTimeMillis()
            )
        )

    suspend fun addAttachment(
        chatMessageId: Long,
        fileName: String,
        mimeType: String,
        sizeBytes: Long,
        uri: String
    ): Long = attachmentDao.insert(
        Attachment(
            chatMessageId = chatMessageId,
            fileName = fileName,
            mimeType = mimeType,
            sizeBytes = sizeBytes,
            uri = uri,
            createdAt = System.currentTimeMillis()
        )
    )
}
