package com.h2ocolombia.mailassistant.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AttachmentDao {

    @Query("SELECT * FROM attachments WHERE chatMessageId = :chatMessageId")
    fun observeForMessage(chatMessageId: Long): Flow<List<Attachment>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(attachment: Attachment): Long
}
