package com.h2ocolombia.mailassistant.data.attachments

/**
 * Tipos permitidos según la sección 7 del requerimiento original: PDF, JPG,
 * JPEG, PNG, WEBP, DOCX, XLSX. Se valida por tipo MIME primero; si el
 * proveedor de archivos no da un MIME reconocible (pasa con algunos
 * gestores de archivos, que devuelven "application/octet-stream" para
 * todo), se cae de vuelta a la extensión del nombre del archivo.
 */
object AttachmentPolicy {

    private val ALLOWED_EXTENSIONS = setOf("pdf", "jpg", "jpeg", "png", "webp", "docx", "xlsx")

    private val ALLOWED_MIME_TYPES = setOf(
        "application/pdf",
        "image/jpeg",
        "image/png",
        "image/webp",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

    fun isAllowed(mimeType: String?, fileName: String): Boolean {
        if (mimeType != null && mimeType in ALLOWED_MIME_TYPES) return true
        val extension = fileName.substringAfterLast('.', "").lowercase()
        return extension in ALLOWED_EXTENSIONS
    }

    /** Para el selector de archivos del sistema (SAF). */
    fun pickerMimeTypes(): Array<String> = ALLOWED_MIME_TYPES.toTypedArray()
}
