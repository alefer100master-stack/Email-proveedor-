package com.h2ocolombia.mailassistant.util

import java.text.Normalizer

/**
 * Normaliza un nombre de proveedor para comparación: sin tildes, minúsculas,
 * espacios dobles colapsados. El nombre ORIGINAL nunca se modifica ni se
 * muestra normalizado — esto es solo para comparar (sección 20 del
 * requerimiento original: "Normalizar para comparación, pero conservar el
 * nombre original").
 *
 * Ejemplos: "SKF Colombia" y "skf   colombia" → "skf colombia" (iguales).
 */
fun normalizeSupplierName(name: String): String {
    val withoutAccents = Normalizer.normalize(name, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
    return withoutAccents
        .lowercase()
        .trim()
        .replace(Regex("\\s+"), " ")
}
