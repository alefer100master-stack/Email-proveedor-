package com.h2ocolombia.mailassistant.ui.screens.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.h2ocolombia.mailassistant.data.local.EmailLogStatus
import com.h2ocolombia.mailassistant.data.repository.EmailLogRepository
import com.h2ocolombia.mailassistant.data.repository.SupplierRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class HistoryEntryUi(
    val id: Long,
    val supplierName: String,
    val recipient: String,
    val subject: String,
    val status: EmailLogStatus,
    val timestamp: Long
)

data class HistoryUiState(
    val isLoading: Boolean = true,
    val entries: List<HistoryEntryUi> = emptyList(),
    val totalCount: Int = 0,
    val searchQuery: String = "",
    val statusFilter: EmailLogStatus? = null
)

class HistoryViewModel(
    emailLogRepository: EmailLogRepository,
    supplierRepository: SupplierRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _statusFilter = MutableStateFlow<EmailLogStatus?>(null)

    private val entries: StateFlow<List<HistoryEntryUi>> =
        combine(
            emailLogRepository.observeAll(),
            supplierRepository.observeAllSuppliersWithEmails()
        ) { logs, suppliers ->
            val namesById = suppliers.associate { it.supplier.id to it.supplier.name }
            logs.map { log ->
                HistoryEntryUi(
                    id = log.id,
                    supplierName = namesById[log.supplierId] ?: "Proveedor #${log.supplierId}",
                    recipient = log.recipient,
                    subject = log.subject,
                    status = log.status,
                    timestamp = log.timestamp
                )
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val uiState: StateFlow<HistoryUiState> =
        combine(entries, _searchQuery, _statusFilter) { allEntries, query, status ->
            val filtered = allEntries.filter { entry ->
                (status == null || entry.status == status) &&
                    (
                        query.isBlank() ||
                            entry.supplierName.contains(query, ignoreCase = true) ||
                            entry.recipient.contains(query, ignoreCase = true) ||
                            entry.subject.contains(query, ignoreCase = true)
                        )
            }
            HistoryUiState(
                isLoading = false,
                entries = filtered,
                totalCount = allEntries.size,
                searchQuery = query,
                statusFilter = status
            )
        }.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            HistoryUiState(isLoading = true)
        )

    fun onSearchQueryChange(value: String) {
        _searchQuery.value = value
    }

    fun onStatusFilterChange(status: EmailLogStatus?) {
        _statusFilter.value = status
    }

    class Factory(
        private val emailLogRepository: EmailLogRepository,
        private val supplierRepository: SupplierRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HistoryViewModel(emailLogRepository, supplierRepository) as T
        }
    }
}
