package com.h2ocolombia.mailassistant.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatMessageDao {

    @Query("SELECT * FROM chat_messages WHERE chatThreadId = :chatThreadId ORDER BY timestamp ASC")
    fun observeForThread(chatThreadId: Long): Flow<List<ChatMessage>>

    @Transaction
    @Query("SELECT * FROM chat_messages WHERE chatThreadId = :chatThreadId ORDER BY timestamp ASC")
    fun observeForThreadWithAttachments(chatThreadId: Long): Flow<List<ChatMessageWithAttachments>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(message: ChatMessage): Long
}
