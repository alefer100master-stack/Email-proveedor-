package com.h2ocolombia.mailassistant.data.repository

import com.h2ocolombia.mailassistant.data.local.EmailType
import com.h2ocolombia.mailassistant.data.local.Supplier
import com.h2ocolombia.mailassistant.data.local.SupplierDao
import com.h2ocolombia.mailassistant.data.local.SupplierEmail
import com.h2ocolombia.mailassistant.data.local.SupplierEmailDao
import com.h2ocolombia.mailassistant.data.local.SupplierWithEmails
import com.h2ocolombia.mailassistant.util.normalizeSupplierName
import kotlinx.coroutines.flow.Flow

class SupplierRepository(
    private val supplierDao: SupplierDao,
    private val supplierEmailDao: SupplierEmailDao
) {
    fun observeActiveSuppliersWithEmails(): Flow<List<SupplierWithEmails>> =
        supplierDao.observeActiveWithEmails()

    fun observeEmailsForSupplier(supplierId: Long): Flow<List<SupplierEmail>> =
        supplierEmailDao.observeForSupplier(supplierId)

    suspend fun createSupplier(name: String): Long {
        val now = System.currentTimeMillis()
        return supplierDao.insert(
            Supplier(
                name = name,
                normalizedName = normalizeSupplierName(name),
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun findEmailByType(supplierId: Long, emailType: EmailType): SupplierEmail? =
        supplierEmailDao.findByType(supplierId, emailType)
}
