package com.h2ocolombia.mailassistant.data.repository

import com.h2ocolombia.mailassistant.data.excel.ParsedSupplierRow
import com.h2ocolombia.mailassistant.data.local.EmailType
import com.h2ocolombia.mailassistant.data.local.Supplier
import com.h2ocolombia.mailassistant.data.local.SupplierDao
import com.h2ocolombia.mailassistant.data.local.SupplierEmail
import com.h2ocolombia.mailassistant.data.local.SupplierEmailDao
import com.h2ocolombia.mailassistant.data.local.SupplierWithEmails
import com.h2ocolombia.mailassistant.util.normalizeSupplierName
import kotlinx.coroutines.flow.Flow

/** Datos de un correo tal como vienen del formulario, antes de convertirse en fila de Room. */
data class EmailDraft(
    val id: Long?,
    val email: String,
    val description: String?,
    val emailType: EmailType,
    val active: Boolean = true
)

class SupplierRepository(
    private val supplierDao: SupplierDao,
    private val supplierEmailDao: SupplierEmailDao
) {
    fun observeActiveSuppliersWithEmails(): Flow<List<SupplierWithEmails>> =
        supplierDao.observeActiveWithEmails()

    /** Incluye proveedores inactivos — el Historial (FASE 12) necesita poder
     *  mostrar el nombre real aunque el proveedor ya no esté activo. */
    fun observeAllSuppliersWithEmails(): Flow<List<SupplierWithEmails>> =
        supplierDao.observeAllWithEmails()

    fun observeEmailsForSupplier(supplierId: Long): Flow<List<SupplierEmail>> =
        supplierEmailDao.observeForSupplier(supplierId)

    suspend fun getSupplierWithEmails(supplierId: Long): SupplierWithEmails? =
        supplierDao.getByIdWithEmails(supplierId)

    suspend fun findSupplierByNormalizedName(normalizedName: String): Supplier? =
        supplierDao.findByNormalizedName(normalizedName)

    /** true si ya existe OTRO proveedor (id distinto) con el mismo nombre normalizado. */
    suspend fun isDuplicateName(name: String, excludingId: Long?): Boolean {
        val existing = supplierDao.findByNormalizedName(normalizeSupplierName(name))
        return existing != null && existing.id != excludingId
    }

    suspend fun createSupplier(
        name: String,
        contactName: String?,
        companyName: String?,
        nit: String?,
        phone: String?,
        whatsapp: String?,
        category: String?,
        city: String?,
        address: String?,
        notes: String?,
        emails: List<EmailDraft>
    ): Long {
        val now = System.currentTimeMillis()
        val supplierId = supplierDao.insert(
            Supplier(
                name = name,
                normalizedName = normalizeSupplierName(name),
                contactName = contactName,
                companyName = companyName,
                nit = nit,
                phone = phone,
                whatsapp = whatsapp,
                category = category,
                city = city,
                address = address,
                notes = notes,
                createdAt = now,
                updatedAt = now
            )
        )
        emails.forEach { draft -> insertEmail(supplierId, draft) }
        return supplierId
    }

    suspend fun updateSupplier(
        supplierId: Long,
        name: String,
        contactName: String?,
        companyName: String?,
        nit: String?,
        phone: String?,
        whatsapp: String?,
        category: String?,
        city: String?,
        address: String?,
        notes: String?,
        active: Boolean,
        emails: List<EmailDraft>
    ) {
        val existing = supplierDao.getById(supplierId) ?: return
        supplierDao.update(
            existing.copy(
                name = name,
                normalizedName = normalizeSupplierName(name),
                contactName = contactName,
                companyName = companyName,
                nit = nit,
                phone = phone,
                whatsapp = whatsapp,
                category = category,
                city = city,
                address = address,
                notes = notes,
                active = active,
                updatedAt = System.currentTimeMillis()
            )
        )
        reconcileEmails(supplierId, emails)
    }

    suspend fun setActive(supplierId: Long, active: Boolean) {
        val existing = supplierDao.getById(supplierId) ?: return
        supplierDao.update(existing.copy(active = active, updatedAt = System.currentTimeMillis()))
    }

    suspend fun findEmailByType(supplierId: Long, emailType: EmailType): SupplierEmail? =
        supplierEmailDao.findByType(supplierId, emailType)

    /**
     * Crea o actualiza un proveedor a partir de una fila del Excel importado
     * (FASE 4). Nunca borra un dato existente con un valor en blanco del
     * archivo — solo sobrescribe los campos que sí traen valor (sección 3:
     * "NO sobrescribir silenciosamente información existente"). Los correos
     * del archivo que el proveedor ya tenía no se tocan; solo se agregan los
     * que sean nuevos.
     *
     * @return true si fue una actualización de un proveedor existente,
     *         false si fue una creación nueva.
     */
    suspend fun upsertFromExcelRow(row: ParsedSupplierRow): Boolean {
        val existing = supplierDao.findByNormalizedName(row.normalizedName)
        val now = System.currentTimeMillis()

        val supplierId: Long
        val wasUpdate: Boolean

        if (existing == null) {
            supplierId = supplierDao.insert(
                Supplier(
                    name = row.name,
                    normalizedName = row.normalizedName,
                    contactName = row.contactName,
                    companyName = row.companyName,
                    nit = row.nit,
                    phone = row.phone,
                    whatsapp = row.whatsapp,
                    category = row.category,
                    city = row.city,
                    address = row.address,
                    notes = row.notes,
                    active = row.active,
                    createdAt = now,
                    updatedAt = now
                )
            )
            wasUpdate = false
        } else {
            supplierDao.update(
                existing.copy(
                    name = row.name,
                    normalizedName = row.normalizedName,
                    contactName = row.contactName ?: existing.contactName,
                    companyName = row.companyName ?: existing.companyName,
                    nit = row.nit ?: existing.nit,
                    phone = row.phone ?: existing.phone,
                    whatsapp = row.whatsapp ?: existing.whatsapp,
                    category = row.category ?: existing.category,
                    city = row.city ?: existing.city,
                    address = row.address ?: existing.address,
                    notes = row.notes ?: existing.notes,
                    updatedAt = now
                )
            )
            supplierId = existing.id
            wasUpdate = true
        }

        val currentEmails = supplierDao.getByIdWithEmails(supplierId)?.emails.orEmpty()
        val currentEmailSet = currentEmails.map { it.email.lowercase() }.toSet()

        row.emails
            .filter { it.lowercase() !in currentEmailSet }
            .forEach { email ->
                supplierEmailDao.insert(
                    SupplierEmail(
                        supplierId = supplierId,
                        email = email,
                        description = null,
                        emailType = EmailType.GENERAL
                    )
                )
            }

        return wasUpdate
    }

    private suspend fun insertEmail(supplierId: Long, draft: EmailDraft) {
        supplierEmailDao.insert(
            SupplierEmail(
                supplierId = supplierId,
                email = draft.email,
                description = draft.description,
                emailType = draft.emailType,
                active = draft.active
            )
        )
    }

    /**
     * Compara los correos que llegaron del formulario contra los que ya existen
     * en la base de datos para este proveedor: borra los que ya no están,
     * actualiza los que traen id, e inserta los nuevos (id == null).
     */
    private suspend fun reconcileEmails(supplierId: Long, emails: List<EmailDraft>) {
        val currentEmails = supplierDao.getByIdWithEmails(supplierId)?.emails.orEmpty()
        val keepIds = emails.mapNotNull { it.id }.toSet()

        currentEmails
            .filter { it.id !in keepIds }
            .forEach { supplierEmailDao.delete(it) }

        emails.forEach { draft ->
            if (draft.id == null) {
                insertEmail(supplierId, draft)
            } else {
                supplierEmailDao.update(
                    SupplierEmail(
                        id = draft.id,
                        supplierId = supplierId,
                        email = draft.email,
                        description = draft.description,
                        emailType = draft.emailType,
                        active = draft.active
                    )
                )
            }
        }
    }
}
