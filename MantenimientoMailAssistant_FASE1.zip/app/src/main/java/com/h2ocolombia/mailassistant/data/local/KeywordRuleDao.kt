package com.h2ocolombia.mailassistant.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface KeywordRuleDao {

    @Query("SELECT * FROM keyword_rules WHERE active = 1")
    fun observeActive(): Flow<List<KeywordRule>>

    @Query("SELECT * FROM keyword_rules WHERE templateKey = :templateKey AND active = 1")
    suspend fun findForTemplate(templateKey: String): List<KeywordRule>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(rules: List<KeywordRule>)
}
