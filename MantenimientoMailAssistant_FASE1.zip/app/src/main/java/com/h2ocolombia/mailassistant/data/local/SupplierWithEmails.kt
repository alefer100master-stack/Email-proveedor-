package com.h2ocolombia.mailassistant.data.local

import androidx.room.Embedded
import androidx.room.Relation

data class SupplierWithEmails(
    @Embedded val supplier: Supplier,
    @Relation(
        parentColumn = "id",
        entityColumn = "supplierId"
    )
    val emails: List<SupplierEmail>
)
