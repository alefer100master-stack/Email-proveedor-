package com.h2ocolombia.mailassistant.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "supplier_emails",
    foreignKeys = [
        ForeignKey(
            entity = Supplier::class,
            parentColumns = ["id"],
            childColumns = ["supplierId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("supplierId")]
)
data class SupplierEmail(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplierId: Long,
    val email: String,
    val description: String? = null,
    val emailType: EmailType,
    val active: Boolean = true
)
