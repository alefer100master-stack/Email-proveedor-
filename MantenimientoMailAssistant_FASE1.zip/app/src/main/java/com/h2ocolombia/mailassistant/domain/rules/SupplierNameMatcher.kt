package com.h2ocolombia.mailassistant.domain.rules

import com.h2ocolombia.mailassistant.util.normalizeSupplierName

data class SupplierMatchCandidate<T>(
    val item: T,
    val name: String,
    val score: Double
)

sealed interface SupplierMatchResult<T> {
    data class SingleMatch<T>(val candidate: SupplierMatchCandidate<T>) : SupplierMatchResult<T>
    data class Ambiguous<T>(val candidates: List<SupplierMatchCandidate<T>>) : SupplierMatchResult<T>
    class NoMatch<T> : SupplierMatchResult<T>
}

/**
 * Coincidencia aproximada de nombres de proveedor (secciones 20 y 26 del
 * requerimiento original: "rodamientos skf" debe reconocer a "SKF
 * Colombia", sin exigir el nombre exacto).
 *
 * Corrección importante (encontrada probando con datos reales, no solo por
 * inspección): una comparación ingenua por traslape de palabras le da el
 * mismo peso a "rodamientos" (una palabra de categoría, genérica) que a
 * "skf" (un identificador distintivo) — eso hacía que "rodamientos skf"
 * empatara casi exactamente entre "SKF Colombia" y un proveedor llamado
 * "ABC Rodamientos". Se corrige bajándole peso a un conjunto acotado de
 * palabras genéricas comunes en nombres de empresas colombianas (ver
 * [GENERIC_NAME_WORDS]), para que las palabras realmente distintivas
 * decidan la coincidencia.
 *
 * Alcance conocido: esta función está afinada y probada para consultas
 * cortas tipo buscador (como el cuadro de búsqueda de Home), no para
 * frases completas largas con palabras de relleno ("enviar orden de compra
 * a rodamientos skf") — ese caso necesitaría además extraer la frase
 * relevante dentro de la oración, algo que no se usa hoy en ningún flujo
 * real de la app (ver docs/FASE14_NOTAS.md).
 *
 * Expone dos formas de uso:
 * - [score]: una puntuación cruda 0.0–1.0, para que una búsqueda (como la
 *   de Home) ordene resultados con su propio umbral, permisivo.
 * - [match]: una clasificación estricta (una sola coincidencia clara /
 *   ambigua entre varias / ninguna), pensada para cuando hay que decidir a
 *   UN solo proveedor — mejor preguntar que adivinar mal a quién enviar un
 *   correo.
 */
object SupplierNameMatcher {

    private const val MATCH_THRESHOLD = 0.6
    private const val AMBIGUITY_MARGIN = 0.08
    private const val GENERIC_WORD_WEIGHT = 0.3

    /**
     * Palabras muy comunes en nombres de empresas colombianas/de habla
     * hispana — no identifican a un proveedor específico por sí solas.
     * Lista acotada y curada a mano, no un diccionario exhaustivo.
     */
    private val GENERIC_NAME_WORDS = setOf(
        "sas", "ltda", "sa", "cia", "compania", "colombia", "industrial",
        "industriales", "comercial", "comercializadora", "distribuidora",
        "servicios", "repuestos", "rodamientos", "suministros", "insumos",
        "internacional", "nacional", "grupo", "andina"
    )

    fun score(query: String, name: String): Double {
        val normalizedQuery = normalizeSupplierName(query)
        val normalizedName = normalizeSupplierName(name)
        if (normalizedQuery.isBlank() || normalizedName.isBlank()) return 0.0

        val wholeStringSimilarity = LevenshteinDistance.similarity(normalizedQuery, normalizedName)

        val queryTokens = normalizedQuery.split(" ").filter { it.isNotBlank() }
        val nameTokens = normalizedName.split(" ").filter { it.isNotBlank() }
        val tokenOverlap = weightedTokenOverlap(queryTokens, nameTokens)

        val containment = if (
            normalizedName.isNotBlank() &&
            (normalizedQuery.contains(normalizedName) || normalizedName.contains(normalizedQuery))
        ) 0.9 else 0.0

        return maxOf(wholeStringSimilarity, tokenOverlap, containment)
    }

    private fun weightedTokenOverlap(queryTokens: List<String>, nameTokens: List<String>): Double {
        if (queryTokens.isEmpty() || nameTokens.isEmpty()) return 0.0

        var weightedSum = 0.0
        var weightTotal = 0.0
        queryTokens.forEach { queryToken ->
            val bestNameToken = nameTokens.maxByOrNull { nameToken ->
                LevenshteinDistance.similarity(queryToken, nameToken)
            } ?: return@forEach
            val similarity = LevenshteinDistance.similarity(queryToken, bestNameToken)
            // Se pesa por qué tan distintiva es la palabra DEL NOMBRE que
            // resultó ser la mejor coincidencia — así una palabra genérica
            // ("rodamientos") no vale tanto como una distintiva ("skf"),
            // sin importar cuál palabra haya escrito el usuario.
            val weight = if (bestNameToken in GENERIC_NAME_WORDS) GENERIC_WORD_WEIGHT else 1.0
            weightedSum += similarity * weight
            weightTotal += weight
        }
        return if (weightTotal > 0) weightedSum / weightTotal else 0.0
    }

    fun <T> match(query: String, candidates: List<T>, nameOf: (T) -> String): SupplierMatchResult<T> {
        if (query.isBlank() || candidates.isEmpty()) return SupplierMatchResult.NoMatch()

        val scored = candidates
            .map { candidate ->
                val name = nameOf(candidate)
                SupplierMatchCandidate(candidate, name, score(query, name))
            }
            .sortedByDescending { it.score }

        val best = scored.first()
        if (best.score < MATCH_THRESHOLD) return SupplierMatchResult.NoMatch()

        val closeRivals = scored.filter { it.score >= best.score - AMBIGUITY_MARGIN }
        return if (closeRivals.size > 1) {
            SupplierMatchResult.Ambiguous(closeRivals)
        } else {
            SupplierMatchResult.SingleMatch(best)
        }
    }
}
