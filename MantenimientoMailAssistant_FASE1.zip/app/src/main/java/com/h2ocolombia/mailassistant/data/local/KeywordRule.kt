package com.h2ocolombia.mailassistant.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "keyword_rules",
    indices = [Index("templateKey")]
)
data class KeywordRule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Coincide con EmailTemplate.key — no es una ForeignKey estricta porque
     *  las plantillas se administran (activar/desactivar) sin borrar reglas. */
    val templateKey: String,
    val keyword: String,
    val active: Boolean = true,
    val confirmationRequired: Boolean = true
)
