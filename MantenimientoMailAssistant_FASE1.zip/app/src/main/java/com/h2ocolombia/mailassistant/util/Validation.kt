package com.h2ocolombia.mailassistant.util

private val EMAIL_REGEX = Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")

fun isValidEmail(value: String): Boolean = EMAIL_REGEX.matches(value.trim())
