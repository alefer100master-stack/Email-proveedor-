package com.h2ocolombia.mailassistant.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = GlowCyan,
    onPrimary = GraphiteBase,
    primaryContainer = GlowCyanDim,
    onPrimaryContainer = TextHighOnDark,
    secondary = CopperWarn,
    onSecondary = GraphiteBase,
    secondaryContainer = CopperWarnContainer,
    onSecondaryContainer = TextHighOnDark,
    background = GraphiteBase,
    surface = GraphiteElevated,
    onSurface = TextHighOnDark,
    surfaceVariant = GraphiteElevated2,
    onSurfaceVariant = TextMediumOnDark,
    outline = GraphiteBorder,
    error = AlertRed,
    onError = GraphiteBase,
    errorContainer = AlertRedContainer,
    onErrorContainer = TextHighOnDark
)

private val LightColors = lightColorScheme(
    primary = GlowCyanOnLight,
    onPrimary = SteelLightElevated,
    primaryContainer = GlowCyan,
    onPrimaryContainer = TextHighOnLight,
    secondary = CopperWarn,
    onSecondary = SteelLightElevated,
    secondaryContainer = Color(0xFFF6E3D1),
    onSecondaryContainer = TextHighOnLight,
    background = SteelLightBase,
    surface = SteelLightElevated,
    onSurface = TextHighOnLight,
    surfaceVariant = SteelLightBase,
    onSurfaceVariant = TextMediumOnLight,
    outline = SteelLightBorder,
    error = Color(0xFFB3261E),
    onError = SteelLightElevated,
    errorContainer = Color(0xFFF9DEDC),
    onErrorContainer = TextHighOnLight
)

/**
 * Identidad "panel de control industrial": oscuro por defecto (como una
 * pantalla HMI de planta), con un modo claro en acero frío para quien lo
 * prefiera. Sin color dinámico (Material You) — la identidad visual debe ser
 * la misma en cualquier dispositivo.
 */
@Composable
fun MantenimientoMailAssistantTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = MailAssistantTypography,
        shapes = MailAssistantShapes,
        content = content
    )
}
