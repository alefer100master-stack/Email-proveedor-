package com.h2ocolombia.mailassistant.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface EmailLogDao {

    @Query("SELECT * FROM email_logs ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<EmailLog>>

    @Query("SELECT * FROM email_logs WHERE supplierId = :supplierId ORDER BY timestamp DESC")
    fun observeForSupplier(supplierId: Long): Flow<List<EmailLog>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(log: EmailLog): Long

    @Update
    suspend fun update(log: EmailLog)
}
