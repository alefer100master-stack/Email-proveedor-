package com.h2ocolombia.mailassistant.ui.screens.supplierform

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.h2ocolombia.mailassistant.data.local.EmailType
import com.h2ocolombia.mailassistant.data.repository.EmailDraft
import com.h2ocolombia.mailassistant.data.repository.SupplierRepository
import com.h2ocolombia.mailassistant.util.isValidEmail
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Una fila de correo en edición. localId es solo una clave estable para la UI (no es el id de Room). */
data class EmailFieldState(
    val localId: String,
    val id: Long?,
    val email: String = "",
    val description: String = "",
    val emailType: EmailType = EmailType.GENERAL
)

data class SupplierFormUiState(
    val supplierId: Long? = null,
    val name: String = "",
    val contactName: String = "",
    val companyName: String = "",
    val nit: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val category: String = "",
    val city: String = "",
    val address: String = "",
    val notes: String = "",
    val active: Boolean = true,
    val emails: List<EmailFieldState> = emptyList(),
    val isLoading: Boolean = false,
    val nameError: String? = null,
    val emailErrors: Map<String, String> = emptyMap(),
    val saveCompleted: Boolean = false
)

class SupplierFormViewModel(
    private val repository: SupplierRepository,
    supplierId: Long?
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        SupplierFormUiState(supplierId = supplierId, isLoading = supplierId != null)
    )
    val uiState: StateFlow<SupplierFormUiState> = _uiState.asStateFlow()

    private var localIdCounter = 0
    private fun nextLocalId(): String = (localIdCounter++).toString()

    init {
        if (supplierId != null) {
            viewModelScope.launch {
                val data = repository.getSupplierWithEmails(supplierId)
                if (data == null) {
                    _uiState.update { it.copy(isLoading = false) }
                } else {
                    _uiState.update {
                        it.copy(
                            name = data.supplier.name,
                            contactName = data.supplier.contactName.orEmpty(),
                            companyName = data.supplier.companyName.orEmpty(),
                            nit = data.supplier.nit.orEmpty(),
                            phone = data.supplier.phone.orEmpty(),
                            whatsapp = data.supplier.whatsapp.orEmpty(),
                            category = data.supplier.category.orEmpty(),
                            city = data.supplier.city.orEmpty(),
                            address = data.supplier.address.orEmpty(),
                            notes = data.supplier.notes.orEmpty(),
                            active = data.supplier.active,
                            emails = data.emails.map { email ->
                                EmailFieldState(
                                    localId = nextLocalId(),
                                    id = email.id,
                                    email = email.email,
                                    description = email.description.orEmpty(),
                                    emailType = email.emailType
                                )
                            },
                            isLoading = false
                        )
                    }
                }
            }
        } else {
            addEmailField()
        }
    }

    fun onNameChange(value: String) = _uiState.update { it.copy(name = value, nameError = null) }
    fun onContactNameChange(value: String) = _uiState.update { it.copy(contactName = value) }
    fun onCompanyNameChange(value: String) = _uiState.update { it.copy(companyName = value) }
    fun onNitChange(value: String) = _uiState.update { it.copy(nit = value) }
    fun onPhoneChange(value: String) = _uiState.update { it.copy(phone = value) }
    fun onWhatsappChange(value: String) = _uiState.update { it.copy(whatsapp = value) }
    fun onCategoryChange(value: String) = _uiState.update { it.copy(category = value) }
    fun onCityChange(value: String) = _uiState.update { it.copy(city = value) }
    fun onAddressChange(value: String) = _uiState.update { it.copy(address = value) }
    fun onNotesChange(value: String) = _uiState.update { it.copy(notes = value) }
    fun onActiveChange(value: Boolean) = _uiState.update { it.copy(active = value) }

    fun addEmailField() {
        _uiState.update { it.copy(emails = it.emails + EmailFieldState(localId = nextLocalId(), id = null)) }
    }

    fun removeEmailField(localId: String) {
        _uiState.update { state ->
            state.copy(
                emails = state.emails.filterNot { it.localId == localId },
                emailErrors = state.emailErrors - localId
            )
        }
    }

    fun onEmailValueChange(localId: String, value: String) {
        _uiState.update { state ->
            state.copy(
                emails = state.emails.map { if (it.localId == localId) it.copy(email = value) else it },
                emailErrors = state.emailErrors - localId
            )
        }
    }

    fun onEmailDescriptionChange(localId: String, value: String) {
        _uiState.update { state ->
            state.copy(emails = state.emails.map { if (it.localId == localId) it.copy(description = value) else it })
        }
    }

    fun onEmailTypeChange(localId: String, type: EmailType) {
        _uiState.update { state ->
            state.copy(emails = state.emails.map { if (it.localId == localId) it.copy(emailType = type) else it })
        }
    }

    fun save() {
        val state = _uiState.value
        if (state.isLoading) return

        val trimmedName = state.name.trim()
        if (trimmedName.isBlank()) {
            _uiState.update { it.copy(nameError = "El nombre es obligatorio") }
            return
        }

        val filledEmails = state.emails.filter { it.email.isNotBlank() }
        val emailErrors = filledEmails
            .filterNot { isValidEmail(it.email) }
            .associate { it.localId to "Correo no válido" }

        if (emailErrors.isNotEmpty()) {
            _uiState.update { it.copy(emailErrors = emailErrors) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            if (repository.isDuplicateName(trimmedName, excludingId = state.supplierId)) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        nameError = "Ya existe un proveedor con un nombre muy similar"
                    )
                }
                return@launch
            }

            val drafts = filledEmails.map {
                EmailDraft(
                    id = it.id,
                    email = it.email.trim(),
                    description = it.description.trim().ifBlank { null },
                    emailType = it.emailType
                )
            }

            if (state.supplierId == null) {
                repository.createSupplier(
                    name = trimmedName,
                    contactName = state.contactName.trim().ifBlank { null },
                    companyName = state.companyName.trim().ifBlank { null },
                    nit = state.nit.trim().ifBlank { null },
                    phone = state.phone.trim().ifBlank { null },
                    whatsapp = state.whatsapp.trim().ifBlank { null },
                    category = state.category.trim().ifBlank { null },
                    city = state.city.trim().ifBlank { null },
                    address = state.address.trim().ifBlank { null },
                    notes = state.notes.trim().ifBlank { null },
                    emails = drafts
                )
            } else {
                repository.updateSupplier(
                    supplierId = state.supplierId,
                    name = trimmedName,
                    contactName = state.contactName.trim().ifBlank { null },
                    companyName = state.companyName.trim().ifBlank { null },
                    nit = state.nit.trim().ifBlank { null },
                    phone = state.phone.trim().ifBlank { null },
                    whatsapp = state.whatsapp.trim().ifBlank { null },
                    category = state.category.trim().ifBlank { null },
                    city = state.city.trim().ifBlank { null },
                    address = state.address.trim().ifBlank { null },
                    notes = state.notes.trim().ifBlank { null },
                    active = state.active,
                    emails = drafts
                )
            }

            _uiState.update { it.copy(isLoading = false, saveCompleted = true) }
        }
    }

    class Factory(
        private val repository: SupplierRepository,
        private val supplierId: Long?
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SupplierFormViewModel(repository, supplierId) as T
        }
    }
}
