package com.h2ocolombia.mailassistant.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Rule
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.h2ocolombia.mailassistant.data.local.ConfirmationMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit,
    onImportExcel: () -> Unit,
    onOpenRules: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val templates by viewModel.templates.collectAsState()

    LaunchedEffect(state.saveMessage) {
        if (state.saveMessage != null) {
            kotlinx.coroutines.delay(1500)
            viewModel.dismissSaveMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Configuración") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(Modifier.height(4.dp)) }

            item { SectionTitle("Cuenta Outlook") }
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.CloudOff, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(
                                state.connectedMicrosoftAccount ?: "No conectada",
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                "Conectar una cuenta Outlook se activa en la FASE 9. El correo " +
                                    "desde el que se envían los mensajes será el de esa cuenta.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item { SectionTitle("Datos de firma") }
            item {
                OutlinedTextField(
                    value = state.userName,
                    onValueChange = viewModel::onUserNameChange,
                    label = { Text("Nombre") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
            item {
                OutlinedTextField(
                    value = state.jobTitle,
                    onValueChange = viewModel::onJobTitleChange,
                    label = { Text("Cargo") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
            item {
                OutlinedTextField(
                    value = state.companyName,
                    onValueChange = viewModel::onCompanyNameChange,
                    label = { Text("Empresa") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = state.phone,
                        onValueChange = viewModel::onPhoneChange,
                        label = { Text("Teléfono") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = state.city,
                        onValueChange = viewModel::onCityChange,
                        label = { Text("Ciudad") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
            item {
                OutlinedTextField(
                    value = state.signatureEmail,
                    onValueChange = viewModel::onSignatureEmailChange,
                    label = { Text("Correo de firma") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            item { SectionTitle("Formato") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = state.dateFormat,
                        onValueChange = viewModel::onDateFormatChange,
                        label = { Text("Formato de fecha") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = state.timeFormat,
                        onValueChange = viewModel::onTimeFormatChange,
                        label = { Text("Formato de hora") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
            item {
                OutlinedTextField(
                    value = state.maxAttachmentSizeMb,
                    onValueChange = viewModel::onMaxAttachmentSizeChange,
                    label = { Text("Tamaño máximo de adjuntos (MB)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }

            item { SectionTitle("Confirmación de envío") }
            item {
                Column {
                    ConfirmationModeOption(
                        label = "Manual (esperar a que toque Enviar)",
                        selected = state.confirmationMode == ConfirmationMode.MANUAL,
                        onClick = { viewModel.onConfirmationModeChange(ConfirmationMode.MANUAL) }
                    )
                    ConfirmationModeOption(
                        label = "Cuenta regresiva cancelable",
                        selected = state.confirmationMode == ConfirmationMode.CUENTA_REGRESIVA,
                        onClick = { viewModel.onConfirmationModeChange(ConfirmationMode.CUENTA_REGRESIVA) }
                    )
                }
            }
            if (state.confirmationMode == ConfirmationMode.CUENTA_REGRESIVA) {
                item {
                    OutlinedTextField(
                        value = state.countdownSeconds,
                        onValueChange = viewModel::onCountdownSecondsChange,
                        label = { Text("Duración de la cuenta regresiva (segundos)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
            }

            item { SectionTitle("Proveedores") }
            item {
                AssistChip(
                    onClick = onImportExcel,
                    label = { Text("Importar / reimportar Excel de proveedores") },
                    leadingIcon = { Icon(Icons.Filled.UploadFile, contentDescription = null) }
                )
            }

            item { SectionTitle("Reglas") }
            item {
                AssistChip(
                    onClick = onOpenRules,
                    label = { Text("Ver estado del motor de reglas") },
                    leadingIcon = { Icon(Icons.Filled.Rule, contentDescription = null) }
                )
            }

            item { SectionTitle("Plantillas activas") }
            items(templates, key = { it.id }) { template ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(template.displayName)
                        Switch(
                            checked = template.active,
                            onCheckedChange = { viewModel.onToggleTemplateActive(template.id, it) }
                        )
                    }
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = viewModel::save,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !state.isSaving
                ) {
                    Text(
                        when {
                            state.isSaving -> "Guardando…"
                            state.saveMessage != null -> "Guardado ✓"
                            else -> "Guardar"
                        }
                    )
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
private fun ConfirmationModeOption(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}
