package com.h2ocolombia.mailassistant.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * normalizedName se calcula una vez al crear/editar (ver
 * util/TextNormalization.kt) y se guarda junto al nombre original — así la
 * FASE 4 (duplicados) y la FASE 7 (coincidencia aproximada) no tienen que
 * recalcularlo en cada comparación.
 */
@Entity(
    tableName = "suppliers",
    indices = [Index(value = ["normalizedName"])]
)
data class Supplier(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val normalizedName: String,
    val companyName: String? = null,
    val nit: String? = null,
    val phone: String? = null,
    val whatsapp: String? = null,
    val category: String? = null,
    val city: String? = null,
    val address: String? = null,
    val notes: String? = null,
    val active: Boolean = true,
    val createdAt: Long,
    val updatedAt: Long
)
