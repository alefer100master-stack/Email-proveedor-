package com.h2ocolombia.mailassistant.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ChatThreadDao {

    @Query("SELECT * FROM chat_threads WHERE supplierId = :supplierId LIMIT 1")
    suspend fun findForSupplier(supplierId: Long): ChatThread?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(chatThread: ChatThread): Long
}
