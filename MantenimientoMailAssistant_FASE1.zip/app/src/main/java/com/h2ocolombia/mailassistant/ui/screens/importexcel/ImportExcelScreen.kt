package com.h2ocolombia.mailassistant.ui.screens.importexcel

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportExcelScreen(
    viewModel: ExcelImportViewModel,
    onBack: () -> Unit,
    onFinished: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    val pickFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let(viewModel::onFilePicked) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Importar Excel") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            when (state.phase) {
                ImportPhase.PICK_FILE -> PickFileContent(
                    isProcessing = state.isProcessing,
                    errorMessage = state.errorMessage,
                    onPickFile = {
                        pickFileLauncher.launch(
                            arrayOf(
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "application/octet-stream"
                            )
                        )
                    }
                )

                ImportPhase.PREVIEW -> PreviewContent(
                    state = state,
                    onCancel = viewModel::cancel,
                    onConfirm = viewModel::confirmImport
                )

                ImportPhase.DONE -> DoneContent(
                    result = state.result,
                    onFinish = onFinished
                )
            }
        }
    }
}

@Composable
private fun PickFileContent(
    isProcessing: Boolean,
    errorMessage: String?,
    onPickFile: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Selecciona el archivo .xlsx con tus proveedores.",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Columnas reconocidas: PROVEEDOR, CONTACTO, EMPRESA, NIT, TELEFONO, " +
                "WHATSAPP, CORREO, CORREO_2, CORREO_3, CATEGORIA, CIUDAD, DIRECCION, " +
                "OBSERVACIONES, ACTIVO.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))

        if (isProcessing) {
            CircularProgressIndicator()
        } else {
            Button(onClick = onPickFile) {
                Icon(Icons.Filled.UploadFile, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Seleccionar archivo Excel")
            }
        }

        if (errorMessage != null) {
            Spacer(Modifier.height(16.dp))
            Card(
                colors = androidx.compose.material3.CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Text(
                    errorMessage,
                    modifier = Modifier.padding(12.dp),
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }
    }
}

@Composable
private fun PreviewContent(
    state: ImportUiState,
    onCancel: () -> Unit,
    onConfirm: () -> Unit
) {
    val newCount = state.previewRows.count { it.status is ImportRowStatus.New }
    val updateCount = state.previewRows.count { it.status is ImportRowStatus.Update }
    val duplicateCount = state.previewRows.count { it.status is ImportRowStatus.DuplicateInFile }
    val errorCount = state.previewRows.count { it.status is ImportRowStatus.Error }

    Column(Modifier.fillMaxSize()) {
        state.fileName?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text(
                    "Resumen",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Text("Importados: ${newCount + updateCount}")
                Text("Nuevos: $newCount")
                Text("Actualizados: $updateCount")
                Text("Duplicados en el archivo: $duplicateCount")
                Text("Con errores: $errorCount")
            }
        }

        Spacer(Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(state.previewRows, key = { it.rowNumber }) { row ->
                PreviewRowItem(row)
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                Text("Cancelar")
            }
            Button(
                onClick = onConfirm,
                modifier = Modifier.weight(1f),
                enabled = !state.isProcessing && (newCount + updateCount) > 0
            ) {
                Text(if (state.isProcessing) "Importando…" else "Confirmar importación")
            }
        }
    }
}

@Composable
private fun PreviewRowItem(row: ImportPreviewRow) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Fila ${row.rowNumber} · ${row.name}", style = MaterialTheme.typography.bodyMedium)
                if (row.email != null) {
                    Text(
                        row.email,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                row.warning?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            StatusChip(row.status)
        }
    }
}

@Composable
private fun StatusChip(status: ImportRowStatus) {
    val (label, color) = when (status) {
        is ImportRowStatus.New -> "Nuevo" to MaterialTheme.colorScheme.primary
        is ImportRowStatus.Update -> "Actualizar" to MaterialTheme.colorScheme.secondary
        is ImportRowStatus.DuplicateInFile -> "Duplicado" to MaterialTheme.colorScheme.tertiary
        is ImportRowStatus.Error -> (status.reason) to MaterialTheme.colorScheme.error
    }
    AssistChip(
        onClick = {},
        label = { Text(label) },
        colors = AssistChipDefaults.assistChipColors(labelColor = color)
    )
}

@Composable
private fun DoneContent(result: ImportResult?, onFinish: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("✓ Importación completada", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(16.dp))
        if (result != null) {
            Text("Importados: ${result.imported}")
            Text("Nuevos: ${result.created}")
            Text("Actualizados: ${result.updated}")
            Text("Duplicados en el archivo: ${result.duplicatesInFile}")
            Text("Con errores: ${result.withErrors}")
        }
        Spacer(Modifier.height(24.dp))
        Button(onClick = onFinish) {
            Text("Volver a Inicio")
        }
    }
}
