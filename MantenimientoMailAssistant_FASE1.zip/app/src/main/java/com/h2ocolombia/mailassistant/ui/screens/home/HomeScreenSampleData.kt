package com.h2ocolombia.mailassistant.ui.screens.home

/**
 * PLACEHOLDER — solo para poder construir y revisar la UI de la FASE 1 sin
 * depender todavía de Room (que se añade en la FASE 2/3).
 *
 * Este archivo completo se elimina cuando HomeScreen se conecte a un
 * HomeViewModel respaldado por SupplierDao. No es una "implementación falsa"
 * de una funcionalidad crítica: es contenido de vista de una pantalla que
 * en esta fase todavía no tiene fuente de datos real.
 */
data class SupplierPreview(
    val id: String,
    val name: String,
    val primaryEmail: String
)

internal fun sampleRecentSuppliers(): List<SupplierPreview> = listOf(
    SupplierPreview(id = "1", name = "SKF Colombia", primaryEmail = "compras@skf.com"),
    SupplierPreview(id = "2", name = "ABC Rodamientos", primaryEmail = "ventas@abcrodamientos.com"),
    SupplierPreview(id = "3", name = "Automatización XYZ", primaryEmail = "contacto@automatizacionxyz.com"),
    SupplierPreview(id = "4", name = "Neumática Industrial", primaryEmail = "info@neumaticaindustrial.com")
)
