package com.h2ocolombia.mailassistant.ui.theme

import androidx.compose.ui.graphics.Color

// Identidad visual: "panel de control industrial" — inspirada en pantallas HMI
// de planta (SCADA), no en un tema de moda genérico. Fondo oscuro grafito por
// defecto (incluso el "modo claro" usa un acero frío, no blanco puro), un único
// acento cian que actúa como "glow" de estado/actividad, y cobre reservado para
// advertencias — el mismo cobre ya usado en FASE 1, ahora con un rol semántico
// claro en vez de decorativo.

// Superficies (modo oscuro = identidad principal de la app)
val GraphiteBase = Color(0xFF0B1016)
val GraphiteElevated = Color(0xFF121A22)
val GraphiteElevated2 = Color(0xFF1A2530)
val GraphiteBorder = Color(0xFF283542)

// Superficies (modo claro = acero frío, no blanco genérico)
val SteelLightBase = Color(0xFFEEF2F5)
val SteelLightElevated = Color(0xFFFFFFFF)
val SteelLightBorder = Color(0xFFD3DBE1)

// Acento primario — "glow" cian de estado/actividad (envío en curso, conectado)
val GlowCyan = Color(0xFF2FE6C4)
val GlowCyanDim = Color(0xFF1D8F7B)
val GlowCyanOnLight = Color(0xFF0E7A69)

// Acento secundario — cobre, reservado para advertencias/atención (adjuntos
// pendientes, cuenta regresiva por vencer, correo tipo faltante)
val CopperWarn = Color(0xFFC97B3B)
val CopperWarnContainer = Color(0xFF3A2716)

// Cancelar / error
val AlertRed = Color(0xFFFF6B5E)
val AlertRedContainer = Color(0xFF3A1D1A)

// Texto
val TextHighOnDark = Color(0xFFE7ECEF)
val TextMediumOnDark = Color(0xFF9FB0BC)
val TextHighOnLight = Color(0xFF14202B)
val TextMediumOnLight = Color(0xFF4C5B67)
