package com.h2ocolombia.mailassistant.data.excel

import com.h2ocolombia.mailassistant.util.isValidEmail
import com.h2ocolombia.mailassistant.util.normalizeSupplierName
import java.text.Normalizer

data class ColumnMapping(
    val nameColumn: Int?,
    val contactColumn: Int?,
    val companyColumn: Int?,
    val nitColumn: Int?,
    val phoneColumn: Int?,
    val whatsappColumn: Int?,
    val email1Column: Int?,
    val email2Column: Int?,
    val email3Column: Int?,
    val categoryColumn: Int?,
    val cityColumn: Int?,
    val addressColumn: Int?,
    val notesColumn: Int?,
    val activeColumn: Int?
)

data class ParsedSupplierRow(
    val rowNumber: Int,
    val name: String,
    val normalizedName: String,
    val contactName: String?,
    val companyName: String?,
    val nit: String?,
    val phone: String?,
    val whatsapp: String?,
    val emails: List<String>,
    val category: String?,
    val city: String?,
    val address: String?,
    val notes: String?,
    val active: Boolean
) {
    val primaryEmail: String? get() = emails.firstOrNull()
}

/**
 * Reconoce encabezados aunque tengan mayúsculas, tildes o espacios distintos
 * (sección 20 del requerimiento original). Si no encuentra una columna de
 * nombre ("PROVEEDOR"/"NOMBRE"), nameColumn queda en null y el importador
 * debe detenerse ahí — el remapeo manual completo (elegir cada columna a
 * mano) queda pendiente para una iteración futura; ver docs/FASE4_NOTAS.md.
 */
object ExcelColumnMapper {

    private val NAME_ALIASES = setOf("proveedor", "nombre", "nombre proveedor")
    private val CONTACT_ALIASES = setOf("contacto")
    private val COMPANY_ALIASES = setOf("empresa", "razon social")
    private val NIT_ALIASES = setOf("nit")
    private val PHONE_ALIASES = setOf("telefono")
    private val WHATSAPP_ALIASES = setOf("whatsapp")
    private val EMAIL1_ALIASES = setOf("correo", "correo 1", "email")
    private val EMAIL2_ALIASES = setOf("correo 2", "correo2")
    private val EMAIL3_ALIASES = setOf("correo 3", "correo3")
    private val CATEGORY_ALIASES = setOf("categoria")
    private val CITY_ALIASES = setOf("ciudad")
    private val ADDRESS_ALIASES = setOf("direccion")
    private val NOTES_ALIASES = setOf("observaciones", "notas")
    private val ACTIVE_ALIASES = setOf("activo")

    fun mapHeaders(headers: List<String>): ColumnMapping {
        val normalized = headers.map { normalizeText(it) }

        fun findColumn(aliases: Set<String>): Int? =
            normalized.indexOfFirst { it in aliases }.takeIf { it >= 0 }

        return ColumnMapping(
            nameColumn = findColumn(NAME_ALIASES),
            contactColumn = findColumn(CONTACT_ALIASES),
            companyColumn = findColumn(COMPANY_ALIASES),
            nitColumn = findColumn(NIT_ALIASES),
            phoneColumn = findColumn(PHONE_ALIASES),
            whatsappColumn = findColumn(WHATSAPP_ALIASES),
            email1Column = findColumn(EMAIL1_ALIASES),
            email2Column = findColumn(EMAIL2_ALIASES),
            email3Column = findColumn(EMAIL3_ALIASES),
            categoryColumn = findColumn(CATEGORY_ALIASES),
            cityColumn = findColumn(CITY_ALIASES),
            addressColumn = findColumn(ADDRESS_ALIASES),
            notesColumn = findColumn(NOTES_ALIASES),
            activeColumn = findColumn(ACTIVE_ALIASES)
        )
    }

    fun parseRow(row: List<String?>, mapping: ColumnMapping, rowNumber: Int): ParsedSupplierRow {
        fun cell(column: Int?): String? = column?.let { row.getOrNull(it) }?.trim()?.ifBlank { null }

        val name = cell(mapping.nameColumn).orEmpty()
        val emails = listOfNotNull(
            cell(mapping.email1Column),
            cell(mapping.email2Column),
            cell(mapping.email3Column)
        ).filter { isValidEmail(it) }

        val activeCell = cell(mapping.activeColumn)
        val active = activeCell?.let { parseBoolean(it) } ?: true

        return ParsedSupplierRow(
            rowNumber = rowNumber,
            name = name,
            normalizedName = normalizeSupplierName(name),
            contactName = cell(mapping.contactColumn),
            companyName = cell(mapping.companyColumn),
            nit = cell(mapping.nitColumn),
            phone = cell(mapping.phoneColumn),
            whatsapp = cell(mapping.whatsappColumn),
            emails = emails,
            category = cell(mapping.categoryColumn),
            city = cell(mapping.cityColumn),
            address = cell(mapping.addressColumn),
            notes = cell(mapping.notesColumn),
            active = active
        )
    }

    private fun parseBoolean(value: String): Boolean = when (normalizeText(value)) {
        "si", "sí", "true", "1", "activo", "x" -> true
        "no", "false", "0", "inactivo" -> false
        else -> true
    }

    private fun normalizeText(value: String): String {
        val withoutAccents = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return withoutAccents
            .lowercase()
            .trim()
            .replace(Regex("[_\\s]+"), " ")
    }
}
