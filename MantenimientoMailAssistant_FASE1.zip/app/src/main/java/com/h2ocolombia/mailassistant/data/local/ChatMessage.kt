package com.h2ocolombia.mailassistant.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "chat_messages",
    foreignKeys = [
        ForeignKey(
            entity = ChatThread::class,
            parentColumns = ["id"],
            childColumns = ["chatThreadId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("chatThreadId")]
)
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatThreadId: Long,
    val sender: MessageSender,
    val content: String,
    val timestamp: Long,
    /** Si este mensaje representa el estado de un envío, su EmailLog asociado. */
    val relatedEmailLogId: Long? = null
)
