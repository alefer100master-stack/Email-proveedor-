package com.h2ocolombia.mailassistant.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * version = 1: primera versión, sin migraciones todavía. Si el esquema
 * cambia más adelante, hace falta escribir una Migration explícita — a
 * propósito NO se usa fallbackToDestructiveMigration(), para no arriesgar
 * borrar datos reales del usuario en silencio (prioridad: confiabilidad
 * sobre comodidad, según la sección 38 del requerimiento original).
 */
@Database(
    entities = [
        Supplier::class,
        SupplierEmail::class,
        ChatThread::class,
        ChatMessage::class,
        Attachment::class,
        EmailTemplate::class,
        KeywordRule::class,
        EmailLog::class,
        AppSettings::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun supplierDao(): SupplierDao
    abstract fun supplierEmailDao(): SupplierEmailDao
    abstract fun chatThreadDao(): ChatThreadDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun attachmentDao(): AttachmentDao
    abstract fun emailTemplateDao(): EmailTemplateDao
    abstract fun keywordRuleDao(): KeywordRuleDao
    abstract fun emailLogDao(): EmailLogDao
    abstract fun appSettingsDao(): AppSettingsDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: build(context).also { instance = it }
            }

        private fun build(context: Context): AppDatabase {
            lateinit var database: AppDatabase
            database = Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "mantenimiento_mail_assistant.db"
            )
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // onCreate se dispara la primera vez que se toca el
                        // archivo de base de datos, después de que build()
                        // ya devolvió la instancia — por eso es seguro
                        // referenciar `database` aquí (closure), en vez de
                        // volver a llamar getInstance() y arriesgar
                        // reentrancia.
                        CoroutineScope(Dispatchers.IO).launch {
                            DatabaseSeeder.seed(database)
                        }
                    }
                })
                .build()
            return database
        }
    }
}
