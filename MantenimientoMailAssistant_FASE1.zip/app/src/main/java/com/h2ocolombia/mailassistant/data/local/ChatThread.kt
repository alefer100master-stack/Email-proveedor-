package com.h2ocolombia.mailassistant.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "chat_threads",
    foreignKeys = [
        ForeignKey(
            entity = Supplier::class,
            parentColumns = ["id"],
            childColumns = ["supplierId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("supplierId", unique = true)]
)
data class ChatThread(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplierId: Long,
    val createdAt: Long
)
