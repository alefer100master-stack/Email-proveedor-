package com.h2ocolombia.mailassistant.data.local

/** Tipo de correo de un proveedor — ver sección 11 del requerimiento original. */
enum class EmailType {
    COMPRAS, FACTURACION, COMERCIAL, ADMINISTRACION, GERENCIA, GENERAL
}

/** Etiqueta legible en español, usada por las pantallas de proveedor. */
fun EmailType.displayLabel(): String = when (this) {
    EmailType.COMPRAS -> "Compras"
    EmailType.FACTURACION -> "Facturación"
    EmailType.COMERCIAL -> "Comercial"
    EmailType.ADMINISTRACION -> "Administración"
    EmailType.GERENCIA -> "Gerencia"
    EmailType.GENERAL -> "General"
}

/** Quién escribió un mensaje dentro del chat de un proveedor. */
enum class MessageSender {
    USUARIO, APP
}

/** Estados de un envío — ver sección 15 del requerimiento original. */
enum class EmailLogStatus {
    PREPARADO, CONFIRMADO, ENVIANDO, ENVIADO, ERROR, CANCELADO
}

/** Modo de confirmación antes de enviar — ver docs/AUDITORIA_CAMBIOS.md, punto 7. */
enum class ConfirmationMode {
    MANUAL, CUENTA_REGRESIVA
}
