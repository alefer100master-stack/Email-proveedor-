package com.h2ocolombia.mailassistant.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * `active = false` para las plantillas que no forman parte del alcance
 * inicial (ver docs/AUDITORIA_CAMBIOS.md, punto 8): quedan modeladas pero no
 * seleccionables hasta que se activen desde Configuración.
 */
@Entity(
    tableName = "email_templates",
    indices = [Index(value = ["key"], unique = true)]
)
data class EmailTemplate(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val displayName: String,
    val subjectTemplate: String,
    val bodyTemplate: String,
    val requiredEmailType: EmailType,
    val active: Boolean
)
