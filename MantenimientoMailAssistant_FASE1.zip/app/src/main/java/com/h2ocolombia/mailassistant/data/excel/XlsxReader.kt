package com.h2ocolombia.mailassistant.data.excel

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * Lector mínimo de archivos .xlsx usando solo ZipInputStream y XmlPullParser
 * (ambos parte del SDK de Android) — sin Apache POI.
 *
 * POI es pesado y tiene incompatibilidades conocidas en Android (referencias
 * a java.awt.*, que no existe en el runtime de Android; ver
 * docs/FASE4_NOTAS.md para el detalle). Esta app solo necesita leer texto de
 * celdas de la primera hoja, no fórmulas, formatos ni macros — por eso se
 * escribió un lector propio y acotado en vez de traer una librería completa
 * de hojas de cálculo.
 *
 * Soporta: celdas de texto compartido (`t="s"`), texto en línea
 * (`t="inlineStr"`), números y fechas como texto crudo, y resuelve fórmulas
 * usando su valor ya calculado (`<v>`), ignorando la fórmula en sí.
 * No soporta: hojas protegidas/cifradas, ni archivos .xls (formato binario
 * antiguo, no es un .xlsx).
 */
object XlsxReader {

    fun readFirstSheet(input: InputStream): ExcelSheet {
        val entries = readRelevantZipEntries(input)

        val sharedStrings = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) }.orEmpty()
        val firstSheetPath = resolveFirstSheetPath(entries)
        val sheetBytes = entries[firstSheetPath]
            ?: throw ExcelParseException("No se encontró ninguna hoja dentro del archivo .xlsx.")

        val rawRows = parseSheetRows(sheetBytes, sharedStrings)
        if (rawRows.isEmpty()) {
            return ExcelSheet(headers = emptyList(), rows = emptyList())
        }

        val headerRow = rawRows.first()
        val columnCount = headerRow.size
        val dataRows = rawRows.drop(1).map { row -> List(columnCount) { index -> row.getOrNull(index) } }

        return ExcelSheet(headers = headerRow.map { it.orEmpty() }, rows = dataRows)
    }

    private fun readRelevantZipEntries(input: InputStream): Map<String, ByteArray> {
        val result = mutableMapOf<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val name = entry.name
                val isRelevant = name == "xl/sharedStrings.xml" ||
                    name == "xl/workbook.xml" ||
                    name == "xl/_rels/workbook.xml.rels" ||
                    (name.startsWith("xl/worksheets/") && name.endsWith(".xml"))
                if (isRelevant) {
                    result[name] = zip.readBytes()
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        if (result.keys.none { it.startsWith("xl/worksheets/") }) {
            throw ExcelParseException(
                "El archivo seleccionado no parece ser un .xlsx válido (no contiene hojas)."
            )
        }
        return result
    }

    /** Determina qué worksheetN.xml corresponde a la primera hoja del libro. */
    private fun resolveFirstSheetPath(entries: Map<String, ByteArray>): String {
        val fallback = {
            entries.keys.filter { it.startsWith("xl/worksheets/") }.minOrNull()
                ?: error("unreachable: ya se validó que existe al menos una hoja")
        }

        val workbookXml = entries["xl/workbook.xml"] ?: return fallback()
        val relsXml = entries["xl/_rels/workbook.xml.rels"] ?: return fallback()

        val firstSheetRId = parseFirstSheetRelationshipId(workbookXml) ?: return fallback()
        val target = parseRelationshipTarget(relsXml, firstSheetRId) ?: return fallback()

        val resolved = if (target.startsWith("xl/")) target else "xl/$target"
        return if (entries.containsKey(resolved)) resolved else fallback()
    }

    private fun parseFirstSheetRelationshipId(xmlBytes: ByteArray): String? {
        val parser = newParser(xmlBytes)
        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG && parser.name == "sheet") {
                for (i in 0 until parser.attributeCount) {
                    if (parser.getAttributeName(i).endsWith("id")) {
                        return parser.getAttributeValue(i)
                    }
                }
            }
            eventType = parser.next()
        }
        return null
    }

    private fun parseRelationshipTarget(xmlBytes: ByteArray, relationshipId: String): String? {
        val parser = newParser(xmlBytes)
        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG && parser.name == "Relationship") {
                var id: String? = null
                var targetValue: String? = null
                for (i in 0 until parser.attributeCount) {
                    when (parser.getAttributeName(i)) {
                        "Id" -> id = parser.getAttributeValue(i)
                        "Target" -> targetValue = parser.getAttributeValue(i)
                    }
                }
                if (id == relationshipId) return targetValue?.removePrefix("/xl/")
            }
            eventType = parser.next()
        }
        return null
    }

    private fun parseSharedStrings(xmlBytes: ByteArray): List<String> {
        val parser = newParser(xmlBytes)
        val strings = mutableListOf<String>()
        var current = StringBuilder()
        var insideSi = false
        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> if (parser.name == "si") {
                    insideSi = true
                    current = StringBuilder()
                }
                XmlPullParser.TEXT -> if (insideSi) current.append(parser.text)
                XmlPullParser.END_TAG -> if (parser.name == "si") {
                    strings.add(current.toString())
                    insideSi = false
                }
            }
            eventType = parser.next()
        }
        return strings
    }

    /** Cada fila resultante está indexada por columna (A=0, B=1, ...). */
    private fun parseSheetRows(xmlBytes: ByteArray, sharedStrings: List<String>): List<List<String?>> {
        val parser = newParser(xmlBytes)
        val rows = mutableListOf<List<String?>>()

        var currentRowCells: MutableMap<Int, String?>? = null
        var currentMaxColumn = -1
        var currentCellType: String? = null
        var currentCellColumn = -1
        var currentValue = StringBuilder()
        var insideValueTag = false

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> {
                        currentRowCells = mutableMapOf()
                        currentMaxColumn = -1
                    }
                    "c" -> {
                        currentCellType = null
                        currentCellColumn = -1
                        for (i in 0 until parser.attributeCount) {
                            when (parser.getAttributeName(i)) {
                                "t" -> currentCellType = parser.getAttributeValue(i)
                                "r" -> currentCellColumn = columnIndexFromCellRef(parser.getAttributeValue(i))
                            }
                        }
                    }
                    "v", "t" -> {
                        insideValueTag = true
                        currentValue = StringBuilder()
                    }
                }
                XmlPullParser.TEXT -> if (insideValueTag) currentValue.append(parser.text)
                XmlPullParser.END_TAG -> when (parser.name) {
                    "v", "t" -> {
                        insideValueTag = false
                        if (currentCellColumn >= 0) {
                            val rawValue = currentValue.toString()
                            val resolved = if (currentCellType == "s") {
                                rawValue.toIntOrNull()?.let { sharedStrings.getOrNull(it) }.orEmpty()
                            } else {
                                rawValue
                            }
                            currentRowCells?.put(currentCellColumn, resolved)
                            if (currentCellColumn > currentMaxColumn) currentMaxColumn = currentCellColumn
                        }
                    }
                    "row" -> {
                        val cells = currentRowCells
                        if (cells != null && currentMaxColumn >= 0) {
                            val rowList = (0..currentMaxColumn).map { cells[it] }
                            // Se ignoran filas completamente vacías (a veces Excel deja filas fantasma).
                            if (rowList.any { !it.isNullOrBlank() }) {
                                rows.add(rowList)
                            }
                        }
                        currentRowCells = null
                    }
                }
            }
            eventType = parser.next()
        }
        return rows
    }

    private fun columnIndexFromCellRef(cellRef: String): Int {
        var index = 0
        for (char in cellRef) {
            if (char.isLetter()) {
                index = index * 26 + (char.uppercaseChar() - 'A' + 1)
            } else {
                break
            }
        }
        return index - 1
    }

    private fun newParser(xmlBytes: ByteArray): XmlPullParser {
        val parser = Xml.newPullParser()
        parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")
        return parser
    }
}

data class ExcelSheet(
    val headers: List<String>,
    val rows: List<List<String?>>
)

class ExcelParseException(message: String) : Exception(message)
