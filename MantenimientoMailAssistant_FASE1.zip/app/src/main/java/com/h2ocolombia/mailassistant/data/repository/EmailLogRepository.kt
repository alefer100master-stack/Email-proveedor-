package com.h2ocolombia.mailassistant.data.repository

import com.h2ocolombia.mailassistant.data.local.EmailLog
import com.h2ocolombia.mailassistant.data.local.EmailLogDao
import com.h2ocolombia.mailassistant.data.local.EmailLogStatus
import kotlinx.coroutines.flow.Flow

/**
 * Nunca expone un método delete — coincide con la sección 15 del
 * requerimiento original: "Nunca eliminar silenciosamente registros de
 * auditoría".
 */
class EmailLogRepository(private val emailLogDao: EmailLogDao) {

    fun observeAll(): Flow<List<EmailLog>> = emailLogDao.observeAll()

    fun observeForSupplier(supplierId: Long): Flow<List<EmailLog>> =
        emailLogDao.observeForSupplier(supplierId)

    suspend fun createPrepared(
        supplierId: Long,
        templateId: Long?,
        recipient: String,
        subject: String,
        instruction: String?
    ): Long = emailLogDao.insert(
        EmailLog(
            timestamp = System.currentTimeMillis(),
            supplierId = supplierId,
            templateId = templateId,
            recipient = recipient,
            subject = subject,
            instruction = instruction,
            status = EmailLogStatus.PREPARADO
        )
    )

    suspend fun updateStatus(logId: Long, status: EmailLogStatus) {
        val current = emailLogDao.getById(logId) ?: return
        emailLogDao.update(current.copy(status = status))
    }
}
