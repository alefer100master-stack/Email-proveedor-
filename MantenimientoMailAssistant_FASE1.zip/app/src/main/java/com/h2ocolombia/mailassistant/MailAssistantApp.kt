package com.h2ocolombia.mailassistant

import android.app.Application
import com.h2ocolombia.mailassistant.di.AppContainer

class MailAssistantApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
