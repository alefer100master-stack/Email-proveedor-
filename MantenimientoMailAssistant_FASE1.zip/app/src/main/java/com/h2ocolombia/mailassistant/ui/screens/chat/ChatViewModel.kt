package com.h2ocolombia.mailassistant.ui.screens.chat

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.h2ocolombia.mailassistant.data.attachments.AttachmentPolicy
import com.h2ocolombia.mailassistant.data.local.EmailLogStatus
import com.h2ocolombia.mailassistant.data.local.MessageSender
import com.h2ocolombia.mailassistant.data.local.displayLabel
import com.h2ocolombia.mailassistant.data.repository.ChatRepository
import com.h2ocolombia.mailassistant.data.repository.EmailLogRepository
import com.h2ocolombia.mailassistant.data.repository.RulesRepository
import com.h2ocolombia.mailassistant.data.repository.SettingsRepository
import com.h2ocolombia.mailassistant.data.repository.SupplierRepository
import com.h2ocolombia.mailassistant.domain.rules.RulesEngine
import com.h2ocolombia.mailassistant.domain.rules.TemplateMatchResult
import com.h2ocolombia.mailassistant.domain.templates.TemplateEngine
import com.h2ocolombia.mailassistant.domain.templates.TemplateVariableBuilder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AttachmentUi(
    val fileName: String,
    val sizeBytes: Long
)

data class PendingAttachmentUi(
    val uri: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long
)

data class ChatMessageUi(
    val id: Long,
    val isFromUser: Boolean,
    val content: String,
    val timestamp: Long,
    val attachments: List<AttachmentUi> = emptyList()
)

data class EmailPreviewUi(
    val emailLogId: Long,
    val recipient: String,
    val subject: String,
    val body: String
)

data class ChatUiState(
    val supplierId: Long,
    val supplierName: String,
    val primaryEmail: String? = null,
    val isLoading: Boolean = true,
    val messages: List<ChatMessageUi> = emptyList(),
    val draftText: String = "",
    val pendingAttachments: List<PendingAttachmentUi> = emptyList(),
    val attachmentError: String? = null,
    val emailPreview: EmailPreviewUi? = null,
    val isPreviewProcessing: Boolean = false
)

class ChatViewModel(
    private val appContext: Context,
    private val chatRepository: ChatRepository,
    private val supplierRepository: SupplierRepository,
    private val settingsRepository: SettingsRepository,
    private val rulesRepository: RulesRepository,
    private val emailLogRepository: EmailLogRepository,
    private val supplierId: Long,
    supplierNameArg: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        ChatUiState(supplierId = supplierId, supplierName = supplierNameArg)
    )
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var chatThreadId: Long? = null

    init {
        viewModelScope.launch {
            val threadId = chatRepository.getOrCreateThreadForSupplier(supplierId)
            chatThreadId = threadId

            val supplierData = supplierRepository.getSupplierWithEmails(supplierId)
            _uiState.update {
                it.copy(
                    supplierName = supplierData?.supplier?.name ?: it.supplierName,
                    primaryEmail = supplierData?.emails?.firstOrNull { email -> email.active }?.email,
                    isLoading = false
                )
            }

            chatRepository.observeMessages(threadId).collect { entries ->
                _uiState.update { state ->
                    state.copy(
                        messages = entries.map { entry ->
                            ChatMessageUi(
                                id = entry.message.id,
                                isFromUser = entry.message.sender == MessageSender.USUARIO,
                                content = entry.message.content,
                                timestamp = entry.message.timestamp,
                                attachments = entry.attachments.map { attachment ->
                                    AttachmentUi(attachment.fileName, attachment.sizeBytes)
                                }
                            )
                        }
                    )
                }
            }
        }
    }

    fun onDraftChange(value: String) {
        _uiState.update { it.copy(draftText = value) }
    }

    fun onFilesPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val settings = settingsRepository.getSettingsOrDefault()
            val maxSizeBytes = settings.maxAttachmentSizeMb * 1024L * 1024L

            uris.forEach { uri ->
                try {
                    appContext.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: SecurityException) {
                    // Algunos proveedores de archivos no soportan permisos persistentes;
                    // igual se puede adjuntar, solo no sobrevive si el proceso muere.
                }

                val (fileName, sizeBytes) = queryNameAndSize(uri)
                val mimeType = appContext.contentResolver.getType(uri) ?: "application/octet-stream"
                val resolvedSize = sizeBytes ?: 0L

                val error = when {
                    !AttachmentPolicy.isAllowed(mimeType, fileName) ->
                        "Tipo de archivo no permitido: $fileName"
                    resolvedSize > maxSizeBytes ->
                        "\"$fileName\" supera el tamaño máximo permitido " +
                            "(${settings.maxAttachmentSizeMb} MB)."
                    else -> null
                }

                if (error != null) {
                    _uiState.update { it.copy(attachmentError = error) }
                } else {
                    _uiState.update { state ->
                        state.copy(
                            pendingAttachments = state.pendingAttachments + PendingAttachmentUi(
                                uri = uri.toString(),
                                fileName = fileName,
                                mimeType = mimeType,
                                sizeBytes = resolvedSize
                            ),
                            attachmentError = null
                        )
                    }
                }
            }
        }
    }

    fun removePendingAttachment(uriString: String) {
        _uiState.update { state ->
            state.copy(pendingAttachments = state.pendingAttachments.filterNot { it.uri == uriString })
        }
    }

    fun dismissAttachmentError() {
        _uiState.update { it.copy(attachmentError = null) }
    }

    fun sendMessage() {
        val state = _uiState.value
        val threadId = chatThreadId ?: return
        val text = state.draftText.trim()
        if (text.isBlank() && state.pendingAttachments.isEmpty()) return

        viewModelScope.launch {
            val messageId = chatRepository.sendUserMessage(
                threadId,
                text.ifBlank { "(adjunto sin mensaje)" }
            )
            val attachmentFileName = state.pendingAttachments.firstOrNull()?.fileName
            state.pendingAttachments.forEach { pending ->
                chatRepository.addAttachment(
                    chatMessageId = messageId,
                    fileName = pending.fileName,
                    mimeType = pending.mimeType,
                    sizeBytes = pending.sizeBytes,
                    uri = pending.uri
                )
            }
            _uiState.update { it.copy(draftText = "", pendingAttachments = emptyList()) }
            handleInstruction(threadId, text, attachmentFileName)
        }
    }

    /**
     * Reconocimiento real (FASE 7) + generación real del correo (FASE 8).
     * Lo único que todavía no pasa de verdad es el envío por Outlook —
     * eso se dice explícitamente en vez de fingir que ya ocurrió.
     */
    private suspend fun handleInstruction(threadId: Long, instruction: String, attachmentFileName: String?) {
        if (instruction.isBlank()) {
            chatRepository.addSystemNote(threadId, "Adjunto guardado en el historial.")
            return
        }

        val activeRules = rulesRepository.getActiveKeywordRules()
        when (val result = RulesEngine.match(instruction, activeRules)) {
            is TemplateMatchResult.Recognized ->
                handleRecognized(threadId, result, instruction, attachmentFileName)

            is TemplateMatchResult.Ambiguous -> {
                val names = result.templateKeys.mapNotNull { key ->
                    rulesRepository.getTemplateByKey(key)?.displayName
                }
                chatRepository.addSystemNote(
                    threadId,
                    "No quedó claro cuál acción quieres (podría ser: ${names.joinToString(" o ")}). " +
                        "Sé más específico, por ejemplo escribiendo \"enviar orden de compra\"."
                )
            }

            TemplateMatchResult.NoMatch -> {
                chatRepository.addSystemNote(
                    threadId,
                    "Guardado en el historial. No se identificó ninguna plantilla conocida en tu " +
                        "mensaje (las activas hoy son: orden de compra, soporte de pago y creación " +
                        "de proveedor)."
                )
            }
        }
    }

    private suspend fun handleRecognized(
        threadId: Long,
        result: TemplateMatchResult.Recognized,
        instruction: String,
        attachmentFileName: String?
    ) {
        val template = rulesRepository.getTemplateByKey(result.templateKey)
        if (template == null) {
            chatRepository.addSystemNote(threadId, "Se reconoció una plantilla que ya no existe.")
            return
        }

        // Sección 11 del requerimiento original: si no existe un correo del
        // tipo que la plantilla necesita, NO se prepara nada — se avisa qué
        // falta exactamente.
        val recipientEmail = supplierRepository.findEmailByType(supplierId, template.requiredEmailType)
        if (recipientEmail == null) {
            chatRepository.addSystemNote(
                threadId,
                "No existe un correo de tipo ${template.requiredEmailType.displayLabel()} para " +
                    "este proveedor. Agrégalo desde el ícono de información (ⓘ) → Editar antes " +
                    "de continuar."
            )
            return
        }

        val supplierData = supplierRepository.getSupplierWithEmails(supplierId) ?: return
        val settings = settingsRepository.getSettingsOrDefault()
        val variables = TemplateVariableBuilder.build(
            supplier = supplierData.supplier,
            settings = settings,
            attachmentFileName = attachmentFileName
        )

        val subject = TemplateEngine.render(template.subjectTemplate, variables)
        val body = TemplateEngine.render(template.bodyTemplate, variables)

        val logId = emailLogRepository.createPrepared(
            supplierId = supplierId,
            templateId = template.id,
            recipient = recipientEmail.email,
            subject = subject,
            instruction = instruction
        )

        chatRepository.addSystemNote(
            threadId,
            "Reconocido: ${template.displayName} (por la palabra clave \"${result.matchedKeyword}\"). " +
                "Revisa la vista previa antes de confirmar."
        )

        _uiState.update {
            it.copy(
                emailPreview = EmailPreviewUi(
                    emailLogId = logId,
                    recipient = recipientEmail.email,
                    subject = subject,
                    body = body
                )
            )
        }
    }

    fun confirmPreview() {
        val preview = _uiState.value.emailPreview ?: return
        val threadId = chatThreadId ?: return
        if (_uiState.value.isPreviewProcessing) return

        viewModelScope.launch {
            _uiState.update { it.copy(isPreviewProcessing = true) }
            emailLogRepository.updateStatus(preview.emailLogId, EmailLogStatus.CONFIRMADO)
            chatRepository.addSystemNote(
                threadId,
                "✓ Correo preparado y confirmado (para: ${preview.recipient}). El envío real por " +
                    "Outlook se activa en la FASE 9 en adelante — por ahora queda auditado en el " +
                    "historial, no enviado."
            )
            _uiState.update { it.copy(emailPreview = null, isPreviewProcessing = false) }
        }
    }

    fun cancelPreview() {
        val preview = _uiState.value.emailPreview ?: return
        val threadId = chatThreadId ?: return
        if (_uiState.value.isPreviewProcessing) return

        viewModelScope.launch {
            _uiState.update { it.copy(isPreviewProcessing = true) }
            emailLogRepository.updateStatus(preview.emailLogId, EmailLogStatus.CANCELADO)
            chatRepository.addSystemNote(threadId, "Envío cancelado.")
            _uiState.update { it.copy(emailPreview = null, isPreviewProcessing = false) }
        }
    }

    private fun queryNameAndSize(uri: Uri): Pair<String, Long?> {
        var name = uri.lastPathSegment ?: "archivo"
        var size: Long? = null
        appContext.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex >= 0) cursor.getString(nameIndex)?.let { name = it }
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        return name to size
    }

    class Factory(
        private val appContext: Context,
        private val chatRepository: ChatRepository,
        private val supplierRepository: SupplierRepository,
        private val settingsRepository: SettingsRepository,
        private val rulesRepository: RulesRepository,
        private val emailLogRepository: EmailLogRepository,
        private val supplierId: Long,
        private val supplierName: String
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ChatViewModel(
                appContext,
                chatRepository,
                supplierRepository,
                settingsRepository,
                rulesRepository,
                emailLogRepository,
                supplierId,
                supplierName
            ) as T
        }
    }
}
