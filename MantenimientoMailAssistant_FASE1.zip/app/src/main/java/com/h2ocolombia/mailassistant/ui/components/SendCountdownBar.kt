package com.h2ocolombia.mailassistant.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.h2ocolombia.mailassistant.ui.theme.MailAssistantTypography
import com.h2ocolombia.mailassistant.ui.theme.MantenimientoMailAssistantTheme
import com.h2ocolombia.mailassistant.ui.theme.MonoDataStyle
import kotlinx.coroutines.CancellationException
import kotlin.math.ceil

/**
 * Panel de "cuenta regresiva cancelable" que se muestra tras confirmar un
 * envío. Si el usuario no cancela antes de que la barra llegue a cero, se
 * invoca [onCountdownFinished] (que en fases posteriores dispara el envío
 * real por Microsoft Graph). Si cancela, se invoca [onCancel] y no se manda
 * nada — el correo queda en estado CANCELADO en el historial.
 *
 * Es la única animación protagonista de la app (ver docs/AUDITORIA_CAMBIOS.md,
 * sección de diseño visual): todo lo demás se mantiene quieto para que esta
 * sea la que comunique "algo está a punto de pasar, todavía puedes actuar".
 */
@Composable
fun SendCountdownBar(
    supplierName: String,
    actionLabel: String,
    totalDurationSeconds: Int,
    onCountdownFinished: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = remember { Animatable(1f) }
    var secondsLeft by remember { mutableFloatStateOf(totalDurationSeconds.toFloat()) }

    LaunchedEffect(totalDurationSeconds) {
        try {
            progress.animateTo(
                targetValue = 0f,
                animationSpec = tween(
                    durationMillis = totalDurationSeconds * 1000,
                    easing = LinearEasing
                )
            ) {
                secondsLeft = value * totalDurationSeconds
            }
            onCountdownFinished()
        } catch (_: CancellationException) {
            // Se canceló explícitamente: no se dispara el envío.
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CountdownRing(progress = progress.value, secondsLeft = secondsLeft)

            Spacer(Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = actionLabel,
                    style = MailAssistantTypography.titleSmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "Para: $supplierName",
                    style = MailAssistantTypography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.width(8.dp))

            OutlinedButton(onClick = onCancel) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text("Cancelar")
            }
        }
    }
}

@Composable
private fun CountdownRing(progress: Float, secondsLeft: Float) {
    val ringColor = MaterialTheme.colorScheme.primary
    val trackColor = MaterialTheme.colorScheme.outline

    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(48.dp)) {
        // Halo suave detrás del anillo (glow simulado con alfa, sin necesitar
        // RenderEffect/blur para que se vea igual en todas las versiones de
        // Android soportadas, minSdk 26 en adelante).
        Canvas(modifier = Modifier.size(48.dp).alpha(0.35f)) {
            drawArc(
                color = ringColor,
                startAngle = -90f,
                sweepAngle = 360f * progress,
                useCenter = false,
                style = Stroke(width = 10f, cap = StrokeCap.Round),
                size = Size(size.width, size.height)
            )
        }
        Canvas(modifier = Modifier.size(40.dp)) {
            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )
            drawArc(
                color = ringColor,
                startAngle = -90f,
                sweepAngle = 360f * progress,
                useCenter = false,
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )
        }
        Text(
            text = "${ceil(secondsLeft).toInt().coerceAtLeast(0)}",
            style = MonoDataStyle,
            color = ringColor
        )
    }
}

@Preview(showBackground = true, name = "Cuenta regresiva – oscuro")
@Composable
private fun SendCountdownBarDarkPreview() {
    MantenimientoMailAssistantTheme(darkTheme = true) {
        SendCountdownBar(
            supplierName = "SKF Colombia",
            actionLabel = "Enviando orden de compra",
            totalDurationSeconds = 8,
            onCountdownFinished = {},
            onCancel = {},
            modifier = Modifier.padding(16.dp)
        )
    }
}

@Preview(showBackground = true, name = "Cuenta regresiva – claro")
@Composable
private fun SendCountdownBarLightPreview() {
    MantenimientoMailAssistantTheme(darkTheme = false) {
        SendCountdownBar(
            supplierName = "SKF Colombia",
            actionLabel = "Enviando orden de compra",
            totalDurationSeconds = 8,
            onCountdownFinished = {},
            onCancel = {},
            modifier = Modifier.padding(16.dp)
        )
    }
}
