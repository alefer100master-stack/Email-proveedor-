package com.h2ocolombia.mailassistant.domain.rules

import com.h2ocolombia.mailassistant.data.local.KeywordRule
import java.text.Normalizer

sealed interface TemplateMatchResult {
    data class Recognized(val templateKey: String, val matchedKeyword: String) : TemplateMatchResult
    data class Ambiguous(val templateKeys: List<String>) : TemplateMatchResult
    data object NoMatch : TemplateMatchResult
}

/**
 * Motor de palabras clave (secciones 8/9 del requerimiento original).
 * Normaliza el texto (mayúsculas, tildes, espacios) y tolera errores
 * simples de escritura comparando por similitud en vez de exigir una
 * coincidencia exacta de substring.
 */
object RulesEngine {

    private const val KEYWORD_MATCH_THRESHOLD = 0.72

    fun match(instruction: String, activeRules: List<KeywordRule>): TemplateMatchResult {
        val normalizedInstruction = normalize(instruction)
        if (normalizedInstruction.isBlank() || activeRules.isEmpty()) return TemplateMatchResult.NoMatch

        var bestScore = 0.0
        var bestRule: KeywordRule? = null
        val matchedTemplateKeys = mutableSetOf<String>()

        activeRules.forEach { rule ->
            val normalizedKeyword = normalize(rule.keyword)
            val score = scoreKeywordMatch(normalizedInstruction, normalizedKeyword)
            if (score >= KEYWORD_MATCH_THRESHOLD) {
                matchedTemplateKeys.add(rule.templateKey)
            }
            if (score > bestScore) {
                bestScore = score
                bestRule = rule
            }
        }

        val distinctTemplates = matchedTemplateKeys.toList()
        return when {
            distinctTemplates.size > 1 -> TemplateMatchResult.Ambiguous(distinctTemplates)
            distinctTemplates.size == 1 -> TemplateMatchResult.Recognized(
                templateKey = distinctTemplates.first(),
                matchedKeyword = bestRule?.keyword.orEmpty()
            )
            else -> TemplateMatchResult.NoMatch
        }
    }

    private fun scoreKeywordMatch(normalizedInstruction: String, normalizedKeyword: String): Double {
        if (normalizedKeyword.isBlank()) return 0.0
        if (normalizedInstruction.contains(normalizedKeyword)) return 1.0

        // Compara contra cada "ventana" de palabras del tamaño de la
        // keyword, para tolerar errores de escritura dentro de una frase
        // más larga (ej. "enviar la ordn de compra por favor").
        val instructionTokens = normalizedInstruction.split(" ").filter { it.isNotBlank() }
        val keywordTokenCount = normalizedKeyword.split(" ").filter { it.isNotBlank() }.size
        if (instructionTokens.isEmpty() || keywordTokenCount == 0) return 0.0

        var best = 0.0
        val lastStart = (instructionTokens.size - keywordTokenCount).coerceAtLeast(0)
        for (start in 0..lastStart) {
            val end = (start + keywordTokenCount).coerceAtMost(instructionTokens.size)
            val window = instructionTokens.subList(start, end).joinToString(" ")
            val similarity = LevenshteinDistance.similarity(window, normalizedKeyword)
            if (similarity > best) best = similarity
        }
        return best
    }

    private fun normalize(value: String): String {
        val withoutAccents = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return withoutAccents.lowercase().trim().replace(Regex("\\s+"), " ")
    }
}
