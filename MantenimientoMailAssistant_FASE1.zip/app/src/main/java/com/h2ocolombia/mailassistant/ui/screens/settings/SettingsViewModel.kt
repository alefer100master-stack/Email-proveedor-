package com.h2ocolombia.mailassistant.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.h2ocolombia.mailassistant.data.local.ConfirmationMode
import com.h2ocolombia.mailassistant.data.repository.RulesRepository
import com.h2ocolombia.mailassistant.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TemplateUi(
    val id: Long,
    val displayName: String,
    val active: Boolean
)

data class SettingsUiState(
    val isLoading: Boolean = true,
    val userName: String = "",
    val jobTitle: String = "",
    val companyName: String = "",
    val signatureEmail: String = "",
    val phone: String = "",
    val city: String = "",
    val dateFormat: String = "dd/MM/yyyy",
    val timeFormat: String = "HH:mm",
    val confirmationMode: ConfirmationMode = ConfirmationMode.CUENTA_REGRESIVA,
    val countdownSeconds: String = "8",
    val maxAttachmentSizeMb: String = "25",
    val connectedMicrosoftAccount: String? = null,
    val isSaving: Boolean = false,
    val saveMessage: String? = null
)

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val rulesRepository: RulesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    val templates: StateFlow<List<TemplateUi>> =
        rulesRepository.observeAllTemplates()
            .map { list -> list.map { TemplateUi(it.id, it.displayName, it.active) } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch {
            val settings = settingsRepository.getSettingsOrDefault()
            _uiState.update {
                it.copy(
                    isLoading = false,
                    userName = settings.userName.orEmpty(),
                    jobTitle = settings.jobTitle.orEmpty(),
                    companyName = settings.companyName.orEmpty(),
                    signatureEmail = settings.signatureEmail.orEmpty(),
                    phone = settings.phone.orEmpty(),
                    city = settings.city.orEmpty(),
                    dateFormat = settings.dateFormat,
                    timeFormat = settings.timeFormat,
                    confirmationMode = settings.confirmationMode,
                    countdownSeconds = settings.countdownSeconds.toString(),
                    maxAttachmentSizeMb = settings.maxAttachmentSizeMb.toString(),
                    connectedMicrosoftAccount = settings.connectedMicrosoftAccount
                )
            }
        }
    }

    fun onUserNameChange(value: String) = _uiState.update { it.copy(userName = value) }
    fun onJobTitleChange(value: String) = _uiState.update { it.copy(jobTitle = value) }
    fun onCompanyNameChange(value: String) = _uiState.update { it.copy(companyName = value) }
    fun onSignatureEmailChange(value: String) = _uiState.update { it.copy(signatureEmail = value) }
    fun onPhoneChange(value: String) = _uiState.update { it.copy(phone = value) }
    fun onCityChange(value: String) = _uiState.update { it.copy(city = value) }
    fun onDateFormatChange(value: String) = _uiState.update { it.copy(dateFormat = value) }
    fun onTimeFormatChange(value: String) = _uiState.update { it.copy(timeFormat = value) }

    fun onConfirmationModeChange(mode: ConfirmationMode) =
        _uiState.update { it.copy(confirmationMode = mode) }

    fun onCountdownSecondsChange(value: String) =
        _uiState.update { it.copy(countdownSeconds = value.filter { c -> c.isDigit() }) }

    fun onMaxAttachmentSizeChange(value: String) =
        _uiState.update { it.copy(maxAttachmentSizeMb = value.filter { c -> c.isDigit() }) }

    fun onToggleTemplateActive(templateId: Long, active: Boolean) {
        viewModelScope.launch { rulesRepository.setTemplateActive(templateId, active) }
    }

    fun save() {
        val state = _uiState.value
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            val current = settingsRepository.getSettingsOrDefault()
            settingsRepository.updateSettings(
                current.copy(
                    userName = state.userName.trim().ifBlank { null },
                    jobTitle = state.jobTitle.trim().ifBlank { null },
                    companyName = state.companyName.trim().ifBlank { null },
                    signatureEmail = state.signatureEmail.trim().ifBlank { null },
                    phone = state.phone.trim().ifBlank { null },
                    city = state.city.trim().ifBlank { null },
                    dateFormat = state.dateFormat.trim().ifBlank { "dd/MM/yyyy" },
                    timeFormat = state.timeFormat.trim().ifBlank { "HH:mm" },
                    confirmationMode = state.confirmationMode,
                    countdownSeconds = state.countdownSeconds.toIntOrNull()?.coerceIn(3, 60) ?: 8,
                    maxAttachmentSizeMb = state.maxAttachmentSizeMb.toIntOrNull()?.coerceIn(1, 100) ?: 25
                )
            )
            _uiState.update { it.copy(isSaving = false, saveMessage = "Guardado.") }
        }
    }

    fun dismissSaveMessage() {
        _uiState.update { it.copy(saveMessage = null) }
    }

    class Factory(
        private val settingsRepository: SettingsRepository,
        private val rulesRepository: RulesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(settingsRepository, rulesRepository) as T
        }
    }
}
