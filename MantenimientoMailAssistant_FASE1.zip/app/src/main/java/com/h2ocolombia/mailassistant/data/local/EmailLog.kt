package com.h2ocolombia.mailassistant.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Nunca se borra desde la app (sección 15 del requerimiento original: "Nunca
 * eliminar silenciosamente registros de auditoría") — este DAO ni siquiera
 * expone un método delete.
 */
@Entity(
    tableName = "email_logs",
    indices = [Index("supplierId"), Index("status")]
)
data class EmailLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val supplierId: Long,
    val templateId: Long?,
    val recipient: String,
    val cc: String? = null,
    val subject: String,
    /** Nombres de archivo separados por "|" — se revisará si conviene una
     *  tabla aparte cuando la FASE 6 (adjuntos múltiples) esté implementada. */
    val attachmentNames: String? = null,
    val instruction: String? = null,
    val status: EmailLogStatus,
    val errorCode: String? = null,
    val errorMessage: String? = null,
    val outlookMessageId: String? = null,
    val userAccount: String? = null,
    val durationMs: Long? = null
)
