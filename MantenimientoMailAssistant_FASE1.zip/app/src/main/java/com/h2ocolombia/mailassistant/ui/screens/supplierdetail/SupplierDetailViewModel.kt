package com.h2ocolombia.mailassistant.ui.screens.supplierdetail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.h2ocolombia.mailassistant.data.local.displayLabel
import com.h2ocolombia.mailassistant.data.repository.SupplierRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SupplierEmailUi(
    val email: String,
    val description: String?,
    val typeLabel: String
)

data class SupplierDetailUiState(
    val supplierId: Long? = null,
    val isLoading: Boolean = true,
    val found: Boolean = false,
    val name: String = "",
    val contactName: String? = null,
    val companyName: String? = null,
    val nit: String? = null,
    val phone: String? = null,
    val whatsapp: String? = null,
    val category: String? = null,
    val city: String? = null,
    val address: String? = null,
    val notes: String? = null,
    val active: Boolean = true,
    val emails: List<SupplierEmailUi> = emptyList()
)

class SupplierDetailViewModel(
    private val repository: SupplierRepository,
    private val supplierId: Long
) : ViewModel() {

    private val _uiState = MutableStateFlow(SupplierDetailUiState(supplierId = supplierId))
    val uiState: StateFlow<SupplierDetailUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val data = repository.getSupplierWithEmails(supplierId)
            _uiState.value = if (data == null) {
                SupplierDetailUiState(supplierId = supplierId, isLoading = false, found = false)
            } else {
                SupplierDetailUiState(
                    supplierId = supplierId,
                    isLoading = false,
                    found = true,
                    name = data.supplier.name,
                    contactName = data.supplier.contactName,
                    companyName = data.supplier.companyName,
                    nit = data.supplier.nit,
                    phone = data.supplier.phone,
                    whatsapp = data.supplier.whatsapp,
                    category = data.supplier.category,
                    city = data.supplier.city,
                    address = data.supplier.address,
                    notes = data.supplier.notes,
                    active = data.supplier.active,
                    emails = data.emails.map {
                        SupplierEmailUi(
                            email = it.email,
                            description = it.description,
                            typeLabel = it.emailType.displayLabel()
                        )
                    }
                )
            }
        }
    }

    class Factory(
        private val repository: SupplierRepository,
        private val supplierId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SupplierDetailViewModel(repository, supplierId) as T
        }
    }
}
