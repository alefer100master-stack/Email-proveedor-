package com.h2ocolombia.mailassistant.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "attachments",
    foreignKeys = [
        ForeignKey(
            entity = ChatMessage::class,
            parentColumns = ["id"],
            childColumns = ["chatMessageId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("chatMessageId")]
)
data class Attachment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatMessageId: Long,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    /** URI persistente (SAF) — ver FASE 6, requiere takePersistableUriPermission. */
    val uri: String,
    val hash: String? = null,
    val createdAt: Long
)
