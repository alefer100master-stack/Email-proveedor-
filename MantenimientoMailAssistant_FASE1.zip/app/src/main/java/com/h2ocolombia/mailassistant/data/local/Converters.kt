package com.h2ocolombia.mailassistant.data.local

import androidx.room.TypeConverter

/**
 * Room guarda cada enum como texto (su .name), no como un tipo nativo de
 * SQLite. Un valor guardado que ya no exista en el enum (por ejemplo si se
 * elimina un valor en una versión futura) haría fallar el `valueOf` — por
 * eso, si este proyecto llega a cambiar estos enums, hace falta una
 * migración de datos, no solo de esquema.
 */
class Converters {

    @TypeConverter
    fun emailTypeToString(value: EmailType): String = value.name

    @TypeConverter
    fun stringToEmailType(value: String): EmailType = EmailType.valueOf(value)

    @TypeConverter
    fun messageSenderToString(value: MessageSender): String = value.name

    @TypeConverter
    fun stringToMessageSender(value: String): MessageSender = MessageSender.valueOf(value)

    @TypeConverter
    fun emailLogStatusToString(value: EmailLogStatus): String = value.name

    @TypeConverter
    fun stringToEmailLogStatus(value: String): EmailLogStatus = EmailLogStatus.valueOf(value)

    @TypeConverter
    fun confirmationModeToString(value: ConfirmationMode): String = value.name

    @TypeConverter
    fun stringToConfirmationMode(value: String): ConfirmationMode = ConfirmationMode.valueOf(value)
}
