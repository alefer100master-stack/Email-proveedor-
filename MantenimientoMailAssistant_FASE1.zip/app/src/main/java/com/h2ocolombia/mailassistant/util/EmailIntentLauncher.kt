package com.h2ocolombia.mailassistant.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.h2ocolombia.mailassistant.ui.screens.chat.EmailIntentRequest

/**
 * En vez de enviar el correo nosotros mismos por Microsoft Graph (lo que
 * exige registrar una aplicación en Entra ID — bloqueado por permisos de la
 * organización), se arma el correo completo (destinatario, asunto, cuerpo,
 * adjuntos) y se le entrega a la aplicación de correo que el usuario ya
 * tenga instalada y con sesión iniciada (el Outlook real del celular, u
 * otra). El usuario confirma el envío final desde esa app — coincide con el
 * espíritu de "vista previa antes de enviar" del requerimiento original,
 * solo que la confirmación final ocurre en la app de correo, no en esta.
 *
 * `type = "message/rfc822"` es la convención estándar de Android para que
 * el selector solo muestre aplicaciones de correo, no cualquier app que
 * acepte texto compartido.
 *
 * @return true si se pudo entregar a alguna aplicación; false si el
 *         teléfono no tiene ninguna app de correo instalada.
 */
fun launchEmailIntent(context: Context, request: EmailIntentRequest): Boolean {
    val attachmentUris = request.attachmentUris.map { Uri.parse(it) }

    val intent = if (attachmentUris.size > 1) {
        Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(attachmentUris))
        }
    } else {
        Intent(Intent.ACTION_SEND).apply {
            attachmentUris.firstOrNull()?.let { putExtra(Intent.EXTRA_STREAM, it) }
        }
    }

    intent.type = "message/rfc822"
    intent.putExtra(Intent.EXTRA_EMAIL, arrayOf(request.recipient))
    intent.putExtra(Intent.EXTRA_SUBJECT, request.subject)
    intent.putExtra(Intent.EXTRA_TEXT, request.body)
    // Necesario para que la app receptora (Outlook u otra) pueda leer los
    // archivos adjuntos, que son URIs de otra aplicación (SAF), no propias.
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

    return try {
        context.startActivity(Intent.createChooser(intent, "Enviar correo con..."))
        true
    } catch (e: ActivityNotFoundException) {
        false
    }
}
