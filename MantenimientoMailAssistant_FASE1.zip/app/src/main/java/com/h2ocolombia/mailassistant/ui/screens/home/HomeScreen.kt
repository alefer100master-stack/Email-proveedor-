package com.h2ocolombia.mailassistant.ui.screens.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.h2ocolombia.mailassistant.domain.rules.SupplierNameMatcher
import com.h2ocolombia.mailassistant.ui.theme.MantenimientoMailAssistantTheme

/** Por debajo de esto, un resultado de búsqueda ya no es relevante para mostrar. */
private const val SEARCH_SCORE_THRESHOLD = 0.35

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    suppliers: List<HomeSupplierUi>,
    onOpenSupplier: (supplierId: Long, supplierName: String) -> Unit,
    onImportExcel: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenHistory: () -> Unit,
    onNewSupplier: () -> Unit = {}
) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(query, suppliers) {
        if (query.isBlank()) {
            suppliers
        } else {
            // Búsqueda tolerante a errores de escritura y a nombres parciales
            // (sección 20/26 del requerimiento original): "rodamientos skf"
            // encuentra "SKF Colombia" aunque no sea una coincidencia exacta.
            suppliers
                .map { it to SupplierNameMatcher.score(query, it.name) }
                .filter { (_, score) -> score >= SEARCH_SCORE_THRESHOLD }
                .sortedByDescending { (_, score) -> score }
                .map { (supplier, _) -> supplier }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mantenimiento Mail Assistant", fontWeight = FontWeight.SemiBold) },
                actions = {
                    IconButton(onClick = onOpenHistory) {
                        Icon(Icons.Filled.Search, contentDescription = "Historial")
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Configuración")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                text = { Text("Nuevo proveedor") },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                onClick = onNewSupplier
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar proveedor") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
            )
            Spacer(Modifier.height(16.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                AssistChip(
                    onClick = onImportExcel,
                    label = { Text("Importar Excel") },
                    leadingIcon = { Icon(Icons.Filled.UploadFile, contentDescription = null) }
                )
                AssistChip(
                    onClick = onOpenSettings,
                    label = { Text("Configuración") },
                    leadingIcon = { Icon(Icons.Filled.Settings, contentDescription = null) }
                )
            }
            Spacer(Modifier.height(24.dp))
            Text(
                text = "Proveedores recientes",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))

            if (filtered.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (suppliers.isEmpty()) {
                            "Todavía no hay proveedores. Importa un Excel o crea uno nuevo."
                        } else {
                            "No se encontraron proveedores con ese nombre."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered, key = { it.id }) { supplier ->
                        SupplierRow(
                            supplier = supplier,
                            onClick = { onOpenSupplier(supplier.id, supplier.name) }
                        )
                    }
                    item { Spacer(Modifier.height(80.dp)) }
                }
            }
        }
    }
}

@Composable
private fun SupplierRow(supplier: HomeSupplierUi, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                text = supplier.name,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = supplier.primaryEmail.ifBlank { "Sin correo registrado" },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private val previewSuppliers = listOf(
    HomeSupplierUi(1, "SKF Colombia", "compras@skf.com"),
    HomeSupplierUi(2, "ABC Rodamientos", "ventas@abcrodamientos.com"),
    HomeSupplierUi(3, "Automatización XYZ", "contacto@automatizacionxyz.com"),
    HomeSupplierUi(4, "Neumática Industrial", "info@neumaticaindustrial.com")
)

@Preview(showBackground = true, name = "Home – claro")
@Composable
private fun HomeScreenLightPreview() {
    MantenimientoMailAssistantTheme(darkTheme = false) {
        HomeScreen(
            suppliers = previewSuppliers,
            onOpenSupplier = { _, _ -> },
            onImportExcel = {},
            onOpenSettings = {},
            onOpenHistory = {}
        )
    }
}

@Preview(showBackground = true, name = "Home – oscuro")
@Composable
private fun HomeScreenDarkPreview() {
    MantenimientoMailAssistantTheme(darkTheme = true) {
        HomeScreen(
            suppliers = previewSuppliers,
            onOpenSupplier = { _, _ -> },
            onImportExcel = {},
            onOpenSettings = {},
            onOpenHistory = {}
        )
    }
}
