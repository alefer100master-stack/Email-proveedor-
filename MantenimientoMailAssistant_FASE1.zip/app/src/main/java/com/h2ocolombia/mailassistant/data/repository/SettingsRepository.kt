package com.h2ocolombia.mailassistant.data.repository

import com.h2ocolombia.mailassistant.data.local.AppSettings
import com.h2ocolombia.mailassistant.data.local.AppSettingsDao
import kotlinx.coroutines.flow.Flow

class SettingsRepository(private val appSettingsDao: AppSettingsDao) {

    fun observeSettings(): Flow<AppSettings?> = appSettingsDao.observe()

    suspend fun getSettingsOrDefault(): AppSettings =
        appSettingsDao.get() ?: AppSettings().also { appSettingsDao.insertDefault(it) }

    suspend fun updateSettings(settings: AppSettings) = appSettingsDao.update(settings)
}
