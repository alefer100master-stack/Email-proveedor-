package com.h2ocolombia.mailassistant.data.local

import androidx.room.Embedded
import androidx.room.Relation

data class ChatMessageWithAttachments(
    @Embedded val message: ChatMessage,
    @Relation(
        parentColumn = "id",
        entityColumn = "chatMessageId"
    )
    val attachments: List<Attachment>
)
