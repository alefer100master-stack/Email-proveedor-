package com.h2ocolombia.mailassistant.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.h2ocolombia.mailassistant.data.repository.SupplierRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/** Modelo de UI plano para la lista de Home — no expone las entidades de Room a Compose. */
data class HomeSupplierUi(
    val id: Long,
    val name: String,
    val primaryEmail: String
)

class HomeViewModel(repository: SupplierRepository) : ViewModel() {

    val suppliers: StateFlow<List<HomeSupplierUi>> =
        repository.observeActiveSuppliersWithEmails()
            .map { list ->
                list.map { supplierWithEmails ->
                    HomeSupplierUi(
                        id = supplierWithEmails.supplier.id,
                        name = supplierWithEmails.supplier.name,
                        primaryEmail = supplierWithEmails.emails
                            .firstOrNull { it.active }
                            ?.email
                            .orEmpty()
                    )
                }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5_000),
                initialValue = emptyList()
            )

    class Factory(private val repository: SupplierRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(repository) as T
        }
    }
}
