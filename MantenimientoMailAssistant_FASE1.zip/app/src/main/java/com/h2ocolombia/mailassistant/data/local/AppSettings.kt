package com.h2ocolombia.mailassistant.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Fila única (id fijo = 1). Se crea con valores por defecto la primera vez
 * que arranca la app (ver DatabaseSeeder) y de ahí en adelante solo se
 * actualiza, nunca se inserta una segunda fila.
 */
@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey val id: Int = SINGLETON_ID,
    val userName: String? = null,
    val jobTitle: String? = null,
    val companyName: String? = null,
    val signatureEmail: String? = null,
    val phone: String? = null,
    val signatureHtml: String? = null,
    val city: String? = null,
    val dateFormat: String = "dd/MM/yyyy",
    val timeFormat: String = "HH:mm",
    val confirmationMode: ConfirmationMode = ConfirmationMode.CUENTA_REGRESIVA,
    val countdownSeconds: Int = 8,
    val maxAttachmentSizeMb: Int = 25,
    /**
     * Ya no se llena de forma automática: se decidió enviar entregando el
     * correo a la app de correo del teléfono en vez de integrar Microsoft
     * Graph/MSAL directamente (ver docs/ENVIO_VIA_APP_CORREO_NOTAS.md). Se
     * deja el campo por si en el futuro se retoma la integración directa.
     */
    val connectedMicrosoftAccount: String? = null
) {
    companion object {
        const val SINGLETON_ID = 1
    }
}
