package com.h2ocolombia.mailassistant.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Fila única (id fijo = 1). Se crea con valores por defecto la primera vez
 * que arranca la app (ver DatabaseSeeder) y de ahí en adelante solo se
 * actualiza, nunca se inserta una segunda fila.
 */
@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey val id: Int = SINGLETON_ID,
    val userName: String? = null,
    val jobTitle: String? = null,
    val companyName: String? = null,
    val signatureEmail: String? = null,
    val phone: String? = null,
    val signatureHtml: String? = null,
    val city: String? = null,
    val dateFormat: String = "dd/MM/yyyy",
    val timeFormat: String = "HH:mm",
    val confirmationMode: ConfirmationMode = ConfirmationMode.CUENTA_REGRESIVA,
    val countdownSeconds: Int = 8,
    val maxAttachmentSizeMb: Int = 25,
    /** Se llena en la FASE 9 cuando exista MSAL — null hasta entonces. */
    val connectedMicrosoftAccount: String? = null
) {
    companion object {
        const val SINGLETON_ID = 1
    }
}
