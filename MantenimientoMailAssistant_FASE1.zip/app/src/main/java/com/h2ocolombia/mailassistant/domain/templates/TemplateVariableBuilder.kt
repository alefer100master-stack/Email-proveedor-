package com.h2ocolombia.mailassistant.domain.templates

import com.h2ocolombia.mailassistant.data.local.AppSettings
import com.h2ocolombia.mailassistant.data.local.Supplier
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Arma el mapa de variables de la sección 10 del requerimiento original a
 * partir de lo que sí tenemos disponible hoy (proveedor, configuración,
 * archivo adjunto). {{NUMERO_OC}} queda vacío por ahora — no hay todavía un
 * lugar de la app donde el usuario indique un número de orden de compra
 * específico; se deja como variable reconocida para no romper plantillas
 * que la usen, pero se sustituye por texto vacío.
 */
object TemplateVariableBuilder {

    fun build(
        supplier: Supplier,
        settings: AppSettings,
        attachmentFileName: String? = null
    ): Map<String, String> {
        val dateFormatter = runCatching {
            SimpleDateFormat(settings.dateFormat, Locale("es", "CO"))
        }.getOrElse { SimpleDateFormat("dd/MM/yyyy", Locale("es", "CO")) }

        return mapOf(
            "PROVEEDOR" to supplier.name,
            "CONTACTO" to supplier.contactName.orEmpty(),
            "EMPRESA" to (supplier.companyName ?: supplier.name),
            "FECHA" to dateFormatter.format(Date()),
            "NUMERO_OC" to "",
            "USUARIO" to settings.userName.orEmpty(),
            "ASUNTO" to "",
            "DESCRIPCION" to "",
            "NOMBRE_ARCHIVO" to attachmentFileName.orEmpty()
        )
    }
}
