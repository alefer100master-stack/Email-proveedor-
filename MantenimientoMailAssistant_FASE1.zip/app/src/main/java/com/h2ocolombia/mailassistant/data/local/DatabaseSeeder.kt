package com.h2ocolombia.mailassistant.data.local

import com.h2ocolombia.mailassistant.util.normalizeSupplierName

/**
 * Datos de referencia que la app necesita desde el primer arranque:
 * configuración por defecto, las plantillas y reglas de palabras clave
 * definidas en las secciones 8 y 10 del requerimiento original, y los mismos
 * 4 proveedores de ejemplo que FASE 1 mostraba como datos estáticos — ahora
 * son filas reales de la base de datos, no un archivo Kotlin hardcodeado.
 *
 * Solo se ejecuta una vez: RoomDatabase.Callback.onCreate se dispara
 * únicamente cuando el archivo .db se crea por primera vez.
 */
object DatabaseSeeder {

    suspend fun seed(database: AppDatabase) {
        seedAppSettings(database)
        seedTemplatesAndRules(database)
        seedSampleSuppliers(database)
    }

    private suspend fun seedAppSettings(database: AppDatabase) {
        if (database.appSettingsDao().get() == null) {
            database.appSettingsDao().insertDefault(AppSettings())
        }
    }

    private suspend fun seedTemplatesAndRules(database: AppDatabase) {
        val templates = listOf(
            EmailTemplate(
                key = "PURCHASE_ORDER",
                displayName = "Orden de compra",
                subjectTemplate = "Envío de orden de compra – {{PROVEEDOR}}",
                bodyTemplate = """
                    Estimados señores,

                    Por medio del presente nos permitimos enviar la orden de compra correspondiente.

                    Adjuntamos el documento para su respectiva gestión.

                    Agradecemos confirmar la recepción y aceptación de la orden de compra.

                    Cordialmente,
                    {{USUARIO}}
                    Área de Mantenimiento
                """.trimIndent(),
                requiredEmailType = EmailType.COMPRAS,
                active = true
            ),
            EmailTemplate(
                key = "PAYMENT_SUPPORT",
                displayName = "Soporte de pago",
                subjectTemplate = "Soporte de pago – {{PROVEEDOR}}",
                bodyTemplate = """
                    Estimados señores,

                    Adjuntamos el soporte de pago correspondiente para su registro.

                    Quedamos atentos a cualquier observación al respecto.

                    Cordialmente,
                    {{USUARIO}}
                    Área de Mantenimiento
                """.trimIndent(),
                requiredEmailType = EmailType.FACTURACION,
                active = true
            ),
            EmailTemplate(
                key = "SUPPLIER_CREATION",
                displayName = "Creación de proveedor",
                subjectTemplate = "Documentos para creación de proveedor – {{PROVEEDOR}}",
                bodyTemplate = """
                    Estimados señores,

                    Adjuntamos los documentos requeridos para el proceso de creación de proveedor.

                    Agradecemos confirmar si falta algún documento adicional.

                    Cordialmente,
                    {{USUARIO}}
                    Área de Mantenimiento
                """.trimIndent(),
                requiredEmailType = EmailType.ADMINISTRACION,
                active = true
            ),
            EmailTemplate(
                key = "QUOTATION_REQUEST",
                displayName = "Solicitud de cotización",
                subjectTemplate = "Solicitud de cotización – {{PROVEEDOR}}",
                bodyTemplate = """
                    Estimados señores,

                    Agradecemos remitir cotización para lo solicitado a continuación.

                    Cordialmente,
                    {{USUARIO}}
                    Área de Mantenimiento
                """.trimIndent(),
                requiredEmailType = EmailType.COMERCIAL,
                active = false
            ),
            EmailTemplate(
                key = "DOCUMENT_SUBMISSION",
                displayName = "Envío de documentos",
                subjectTemplate = "Envío de documentos – {{PROVEEDOR}}",
                bodyTemplate = """
                    Estimados señores,

                    Adjuntamos los documentos solicitados.

                    Cordialmente,
                    {{USUARIO}}
                    Área de Mantenimiento
                """.trimIndent(),
                requiredEmailType = EmailType.GENERAL,
                active = false
            ),
            EmailTemplate(
                key = "GENERAL_COMMUNICATION",
                displayName = "Comunicación general",
                subjectTemplate = "{{ASUNTO}} – {{PROVEEDOR}}",
                bodyTemplate = """
                    Estimados señores,

                    {{DESCRIPCION}}

                    Cordialmente,
                    {{USUARIO}}
                    Área de Mantenimiento
                """.trimIndent(),
                requiredEmailType = EmailType.GENERAL,
                active = false
            )
        )
        database.emailTemplateDao().insertAll(templates)

        val rules =
            listOf("orden de compra", "oc", "enviar oc", "enviar orden de compra")
                .map { KeywordRule(templateKey = "PURCHASE_ORDER", keyword = it) } +
            listOf("soporte de pago", "soporte pago", "enviar soporte de pago")
                .map { KeywordRule(templateKey = "PAYMENT_SUPPORT", keyword = it) } +
            listOf(
                "creación de proveedor",
                "crear proveedor",
                "documentos proveedor",
                "documentos para creación"
            ).map { KeywordRule(templateKey = "SUPPLIER_CREATION", keyword = it) } +
            listOf("solicitud de cotización", "cotización", "solicitar cotización")
                .map { KeywordRule(templateKey = "QUOTATION_REQUEST", keyword = it, active = false) } +
            listOf("envío de documentos", "enviar documentos")
                .map { KeywordRule(templateKey = "DOCUMENT_SUBMISSION", keyword = it, active = false) }

        database.keywordRuleDao().insertAll(rules)
    }

    private suspend fun seedSampleSuppliers(database: AppDatabase) {
        if (database.supplierDao().count() > 0) return

        val now = System.currentTimeMillis()
        val samples = listOf(
            Triple("SKF Colombia", "compras@skf.com", EmailType.COMPRAS),
            Triple("ABC Rodamientos", "ventas@abcrodamientos.com", EmailType.COMERCIAL),
            Triple("Automatización XYZ", "contacto@automatizacionxyz.com", EmailType.GENERAL),
            Triple("Neumática Industrial", "info@neumaticaindustrial.com", EmailType.GENERAL)
        )

        samples.forEach { (name, email, type) ->
            val supplierId = database.supplierDao().insert(
                Supplier(
                    name = name,
                    normalizedName = normalizeSupplierName(name),
                    active = true,
                    createdAt = now,
                    updatedAt = now
                )
            )
            database.supplierEmailDao().insert(
                SupplierEmail(
                    supplierId = supplierId,
                    email = email,
                    description = type.name,
                    emailType = type
                )
            )
            database.chatThreadDao().insert(
                ChatThread(supplierId = supplierId, createdAt = now)
            )
        }
    }
}
