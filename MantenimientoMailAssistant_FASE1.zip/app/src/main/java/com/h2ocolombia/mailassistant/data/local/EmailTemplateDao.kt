package com.h2ocolombia.mailassistant.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface EmailTemplateDao {

    @Query("SELECT * FROM email_templates ORDER BY displayName ASC")
    fun observeAll(): Flow<List<EmailTemplate>>

    @Query("SELECT * FROM email_templates WHERE active = 1 ORDER BY displayName ASC")
    fun observeActive(): Flow<List<EmailTemplate>>

    @Query("SELECT * FROM email_templates WHERE `key` = :key LIMIT 1")
    suspend fun findByKey(key: String): EmailTemplate?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(templates: List<EmailTemplate>)

    @Update
    suspend fun update(template: EmailTemplate)
}
