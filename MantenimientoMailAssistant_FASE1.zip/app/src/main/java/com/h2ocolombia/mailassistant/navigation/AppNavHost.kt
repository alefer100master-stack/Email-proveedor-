package com.h2ocolombia.mailassistant.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.h2ocolombia.mailassistant.MailAssistantApp
import com.h2ocolombia.mailassistant.data.repository.ChatRepository
import com.h2ocolombia.mailassistant.data.repository.EmailLogRepository
import com.h2ocolombia.mailassistant.data.repository.RulesRepository
import com.h2ocolombia.mailassistant.data.repository.SettingsRepository
import com.h2ocolombia.mailassistant.data.repository.SupplierRepository
import com.h2ocolombia.mailassistant.ui.screens.chat.ChatScreen
import com.h2ocolombia.mailassistant.ui.screens.chat.ChatViewModel
import com.h2ocolombia.mailassistant.ui.screens.home.HomeScreen
import com.h2ocolombia.mailassistant.ui.screens.home.HomeViewModel
import com.h2ocolombia.mailassistant.ui.screens.history.HistoryScreen
import com.h2ocolombia.mailassistant.ui.screens.history.HistoryViewModel
import com.h2ocolombia.mailassistant.ui.screens.importexcel.ExcelImportViewModel
import com.h2ocolombia.mailassistant.ui.screens.importexcel.ImportExcelScreen
import com.h2ocolombia.mailassistant.ui.screens.placeholder.PlaceholderScreen
import com.h2ocolombia.mailassistant.ui.screens.settings.SettingsScreen
import com.h2ocolombia.mailassistant.ui.screens.settings.SettingsViewModel
import com.h2ocolombia.mailassistant.ui.screens.supplierdetail.SupplierDetailScreen
import com.h2ocolombia.mailassistant.ui.screens.supplierdetail.SupplierDetailViewModel
import com.h2ocolombia.mailassistant.ui.screens.supplierform.SupplierFormScreen
import com.h2ocolombia.mailassistant.ui.screens.supplierform.SupplierFormViewModel

@Composable
fun AppNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.Home.route) {

        composable(Routes.Home.route) {
            val repository = rememberSupplierRepository()
            val homeViewModel: HomeViewModel = viewModel(factory = HomeViewModel.Factory(repository))
            val suppliers by homeViewModel.suppliers.collectAsState()

            HomeScreen(
                suppliers = suppliers,
                onOpenSupplier = { supplierId, supplierName ->
                    navController.navigate(
                        Routes.SupplierChat.createRoute(supplierId, Uri.encode(supplierName))
                    )
                },
                onImportExcel = { navController.navigate(Routes.Import.route) },
                onOpenSettings = { navController.navigate(Routes.Settings.route) },
                onOpenHistory = { navController.navigate(Routes.History.route) },
                onNewSupplier = { navController.navigate(Routes.SupplierNew.route) }
            )
        }

        composable(Routes.SupplierNew.route) {
            val repository = rememberSupplierRepository()
            val formViewModel: SupplierFormViewModel = viewModel(
                factory = SupplierFormViewModel.Factory(repository, supplierId = null)
            )
            SupplierFormScreen(
                viewModel = formViewModel,
                onSaved = { navController.popBackStack() },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SupplierEdit.route) { backStackEntry ->
            val supplierId = backStackEntry.arguments?.getString("supplierId")?.toLongOrNull()
            if (supplierId == null) {
                PlaceholderScreen(title = "Proveedor", note = "Identificador de proveedor no válido.")
            } else {
                val repository = rememberSupplierRepository()
                val formViewModel: SupplierFormViewModel = viewModel(
                    factory = SupplierFormViewModel.Factory(repository, supplierId = supplierId)
                )
                SupplierFormScreen(
                    viewModel = formViewModel,
                    onSaved = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }
        }

        composable(Routes.Import.route) {
            val context = LocalContext.current
            val repository = rememberSupplierRepository()
            val importViewModel: ExcelImportViewModel = viewModel(
                factory = ExcelImportViewModel.Factory(context.applicationContext, repository)
            )
            ImportExcelScreen(
                viewModel = importViewModel,
                onBack = { navController.popBackStack() },
                onFinished = { navController.popBackStack() }
            )
        }

        composable(Routes.Settings.route) {
            val settingsRepository = rememberSettingsRepository()
            val rulesRepository = rememberRulesRepository()
            val settingsViewModel: SettingsViewModel = viewModel(
                factory = SettingsViewModel.Factory(settingsRepository, rulesRepository)
            )
            SettingsScreen(
                viewModel = settingsViewModel,
                onBack = { navController.popBackStack() },
                onImportExcel = { navController.navigate(Routes.Import.route) },
                onOpenRules = { navController.navigate(Routes.RulesConfig.route) }
            )
        }

        composable(Routes.History.route) {
            val emailLogRepository = rememberEmailLogRepository()
            val supplierRepository = rememberSupplierRepository()
            val historyViewModel: HistoryViewModel = viewModel(
                factory = HistoryViewModel.Factory(emailLogRepository, supplierRepository)
            )
            HistoryScreen(
                viewModel = historyViewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.RulesConfig.route) {
            PlaceholderScreen(
                title = "Reglas",
                note = "El motor de reconocimiento ya funciona (FASE 7): coincidencia " +
                    "aproximada de nombre de proveedor y de palabras clave, tolerante a " +
                    "errores de escritura. Lo que falta aquí es una pantalla para agregar, " +
                    "editar o desactivar palabras clave una por una a mano — hoy sus reglas " +
                    "solo existen porque se sembraron desde la FASE 2. Activar/desactivar " +
                    "plantillas completas sí puedes hacerlo ya, desde Configuración."
            )
        }

        composable(Routes.SupplierChat.route) { backStackEntry ->
            val supplierId = backStackEntry.arguments?.getString("supplierId")?.toLongOrNull()
            val supplierName = backStackEntry.arguments
                ?.getString("supplierName")
                ?.let { Uri.decode(it) }
                .orEmpty()
            if (supplierId == null) {
                PlaceholderScreen(title = "Proveedor", note = "Identificador de proveedor no válido.")
            } else {
                val supplierRepository = rememberSupplierRepository()
                val chatRepository = rememberChatRepository()
                val settingsRepository = rememberSettingsRepository()
                val rulesRepository = rememberRulesRepository()
                val emailLogRepository = rememberEmailLogRepository()
                val context = LocalContext.current
                val chatViewModel: ChatViewModel = viewModel(
                    factory = ChatViewModel.Factory(
                        context.applicationContext,
                        chatRepository,
                        supplierRepository,
                        settingsRepository,
                        rulesRepository,
                        emailLogRepository,
                        supplierId,
                        supplierName
                    )
                )
                ChatScreen(
                    viewModel = chatViewModel,
                    onBack = { navController.popBackStack() },
                    onOpenSupplierInfo = { id ->
                        navController.navigate(Routes.SupplierDetail.createRoute(id))
                    }
                )
            }
        }

        composable(Routes.SupplierDetail.route) { backStackEntry ->
            val supplierId = backStackEntry.arguments?.getString("supplierId")?.toLongOrNull()
            if (supplierId == null) {
                PlaceholderScreen(title = "Proveedor", note = "Identificador de proveedor no válido.")
            } else {
                val repository = rememberSupplierRepository()
                val detailViewModel: SupplierDetailViewModel = viewModel(
                    factory = SupplierDetailViewModel.Factory(repository, supplierId)
                )
                SupplierDetailScreen(
                    viewModel = detailViewModel,
                    onBack = { navController.popBackStack() },
                    onEdit = { id -> navController.navigate(Routes.SupplierEdit.createRoute(id)) }
                )
            }
        }
    }
}

@Composable
private fun rememberSupplierRepository(): SupplierRepository {
    val context = LocalContext.current
    return remember {
        (context.applicationContext as MailAssistantApp).container.supplierRepository
    }
}

@Composable
private fun rememberChatRepository(): ChatRepository {
    val context = LocalContext.current
    return remember {
        (context.applicationContext as MailAssistantApp).container.chatRepository
    }
}

@Composable
private fun rememberSettingsRepository(): SettingsRepository {
    val context = LocalContext.current
    return remember {
        (context.applicationContext as MailAssistantApp).container.settingsRepository
    }
}

@Composable
private fun rememberRulesRepository(): RulesRepository {
    val context = LocalContext.current
    return remember {
        (context.applicationContext as MailAssistantApp).container.rulesRepository
    }
}

@Composable
private fun rememberEmailLogRepository(): EmailLogRepository {
    val context = LocalContext.current
    return remember {
        (context.applicationContext as MailAssistantApp).container.emailLogRepository
    }
}
