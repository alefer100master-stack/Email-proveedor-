package com.h2ocolombia.mailassistant.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.h2ocolombia.mailassistant.MailAssistantApp
import com.h2ocolombia.mailassistant.ui.screens.home.HomeScreen
import com.h2ocolombia.mailassistant.ui.screens.home.HomeViewModel
import com.h2ocolombia.mailassistant.ui.screens.placeholder.PlaceholderScreen

@Composable
fun AppNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.Home.route) {

        composable(Routes.Home.route) {
            val context = LocalContext.current
            val repository = remember {
                (context.applicationContext as MailAssistantApp).container.supplierRepository
            }
            val homeViewModel: HomeViewModel = viewModel(factory = HomeViewModel.Factory(repository))
            val suppliers by homeViewModel.suppliers.collectAsState()

            HomeScreen(
                suppliers = suppliers,
                onOpenSupplier = { supplierId, supplierName ->
                    navController.navigate(
                        Routes.SupplierChat.createRoute(supplierId, Uri.encode(supplierName))
                    )
                },
                onImportExcel = { navController.navigate(Routes.Import.route) },
                onOpenSettings = { navController.navigate(Routes.Settings.route) },
                onOpenHistory = { navController.navigate(Routes.History.route) }
            )
        }

        composable(Routes.Import.route) {
            PlaceholderScreen(
                title = "Importar Excel",
                note = "La importación real de proveedores desde .xlsx se construye en la FASE 4."
            )
        }

        composable(Routes.Settings.route) {
            PlaceholderScreen(
                title = "Configuración",
                note = "Se construye en la FASE 13: cuenta Outlook conectada (correo de envío), " +
                    "botón para importar/reimportar el Excel de proveedores, firma, " +
                    "administrador de plantillas, y el modo de confirmación de envío " +
                    "(manual o con cuenta regresiva cancelable y su duración)."
            )
        }

        composable(Routes.History.route) {
            PlaceholderScreen(
                title = "Historial",
                note = "El historial auditable (EmailLog) se construye en la FASE 12."
            )
        }

        composable(Routes.RulesConfig.route) {
            PlaceholderScreen(
                title = "Reglas",
                note = "Se construye en la FASE 7: reconocimiento del proveedor por " +
                    "coincidencia aproximada del nombre (tolera errores de escritura, " +
                    "por ejemplo \"rodamientos skf\" reconoce a SKF Colombia), con " +
                    "confirmación obligatoria antes de enviar. Plantillas activas al " +
                    "inicio: orden de compra, soporte de pago y creación de proveedor."
            )
        }

        composable(Routes.SupplierChat.route) { backStackEntry ->
            val supplierName = backStackEntry.arguments
                ?.getString("supplierName")
                ?.let { Uri.decode(it) }
                .orEmpty()
            PlaceholderScreen(
                title = supplierName.ifBlank { "Proveedor" },
                note = "El chat funcional (adjuntos, plantillas, envío) se construye en la FASE 5 en adelante."
            )
        }
    }
}
