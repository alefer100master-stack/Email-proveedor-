package com.h2ocolombia.mailassistant.di

import android.content.Context
import com.h2ocolombia.mailassistant.data.local.AppDatabase
import com.h2ocolombia.mailassistant.data.repository.ChatRepository
import com.h2ocolombia.mailassistant.data.repository.EmailLogRepository
import com.h2ocolombia.mailassistant.data.repository.RulesRepository
import com.h2ocolombia.mailassistant.data.repository.SettingsRepository
import com.h2ocolombia.mailassistant.data.repository.SupplierRepository

/**
 * Contenedor de dependencias manual y sencillo (sin Hilt), tal como se
 * documentó en docs/ARQUITECTURA.md. Se crea una sola vez en
 * MailAssistantApp y las pantallas lo obtienen a través del contexto de la
 * aplicación (ver AppNavHost.kt).
 */
class AppContainer(context: Context) {
    private val database: AppDatabase = AppDatabase.getInstance(context)

    val supplierRepository: SupplierRepository = SupplierRepository(
        supplierDao = database.supplierDao(),
        supplierEmailDao = database.supplierEmailDao()
    )

    val chatRepository: ChatRepository = ChatRepository(
        chatThreadDao = database.chatThreadDao(),
        chatMessageDao = database.chatMessageDao(),
        attachmentDao = database.attachmentDao()
    )

    val settingsRepository: SettingsRepository = SettingsRepository(
        appSettingsDao = database.appSettingsDao()
    )

    val rulesRepository: RulesRepository = RulesRepository(
        keywordRuleDao = database.keywordRuleDao(),
        emailTemplateDao = database.emailTemplateDao()
    )

    val emailLogRepository: EmailLogRepository = EmailLogRepository(
        emailLogDao = database.emailLogDao()
    )
}
