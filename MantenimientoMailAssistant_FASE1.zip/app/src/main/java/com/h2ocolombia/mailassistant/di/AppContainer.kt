package com.h2ocolombia.mailassistant.di

import android.content.Context
import com.h2ocolombia.mailassistant.data.local.AppDatabase
import com.h2ocolombia.mailassistant.data.repository.SupplierRepository

/**
 * Contenedor de dependencias manual y sencillo (sin Hilt), tal como se
 * documentó en docs/ARQUITECTURA.md. Se crea una sola vez en
 * MailAssistantApp y las pantallas lo obtienen a través del contexto de la
 * aplicación (ver AppNavHost.kt).
 */
class AppContainer(context: Context) {
    private val database: AppDatabase = AppDatabase.getInstance(context)

    val supplierRepository: SupplierRepository = SupplierRepository(
        supplierDao = database.supplierDao(),
        supplierEmailDao = database.supplierEmailDao()
    )
}
