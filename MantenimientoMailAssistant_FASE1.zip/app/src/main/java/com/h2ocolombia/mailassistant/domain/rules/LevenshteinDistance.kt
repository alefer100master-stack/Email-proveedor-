package com.h2ocolombia.mailassistant.domain.rules

/**
 * Distancia de Levenshtein clásica (mínimo número de inserciones, borrados
 * o sustituciones para convertir `a` en `b`). Implementación propia en
 * Kotlin — es una función acotada y bien conocida, no vale la pena sumar
 * una dependencia externa solo para esto.
 */
object LevenshteinDistance {

    fun compute(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length

        var previousRow = IntArray(b.length + 1) { it }
        var currentRow = IntArray(b.length + 1)

        for (i in 1..a.length) {
            currentRow[0] = i
            for (j in 1..b.length) {
                val substitutionCost = if (a[i - 1] == b[j - 1]) 0 else 1
                currentRow[j] = minOf(
                    currentRow[j - 1] + 1, // inserción
                    previousRow[j] + 1, // borrado
                    previousRow[j - 1] + substitutionCost // sustitución
                )
            }
            val swap = previousRow
            previousRow = currentRow
            currentRow = swap
        }
        return previousRow[b.length]
    }

    /** 1.0 = idénticas, 0.0 = completamente distintas. */
    fun similarity(a: String, b: String): Double {
        val maxLength = maxOf(a.length, b.length)
        if (maxLength == 0) return 1.0
        return 1.0 - (compute(a, b).toDouble() / maxLength)
    }
}
