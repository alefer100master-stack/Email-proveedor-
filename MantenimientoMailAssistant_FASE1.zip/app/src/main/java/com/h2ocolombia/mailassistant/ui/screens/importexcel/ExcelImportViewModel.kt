package com.h2ocolombia.mailassistant.ui.screens.importexcel

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.h2ocolombia.mailassistant.data.excel.ExcelColumnMapper
import com.h2ocolombia.mailassistant.data.excel.ExcelParseException
import com.h2ocolombia.mailassistant.data.excel.ParsedSupplierRow
import com.h2ocolombia.mailassistant.data.excel.XlsxReader
import com.h2ocolombia.mailassistant.data.repository.SupplierRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ImportPhase { PICK_FILE, PREVIEW, DONE }

sealed interface ImportRowStatus {
    data object New : ImportRowStatus
    data object Update : ImportRowStatus
    data object DuplicateInFile : ImportRowStatus
    data class Error(val reason: String) : ImportRowStatus
}

data class ImportPreviewRow(
    val rowNumber: Int,
    val name: String,
    val email: String?,
    val status: ImportRowStatus,
    val warning: String? = null
)

data class ImportResult(
    val created: Int,
    val updated: Int,
    val duplicatesInFile: Int,
    val withErrors: Int
) {
    val imported: Int get() = created + updated
}

data class ImportUiState(
    val phase: ImportPhase = ImportPhase.PICK_FILE,
    val fileName: String? = null,
    val previewRows: List<ImportPreviewRow> = emptyList(),
    val isProcessing: Boolean = false,
    val errorMessage: String? = null,
    val result: ImportResult? = null
)

class ExcelImportViewModel(
    private val appContext: Context,
    private val repository: SupplierRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ImportUiState())
    val uiState: StateFlow<ImportUiState> = _uiState.asStateFlow()

    private var parsedRows: List<ParsedSupplierRow> = emptyList()

    fun onFilePicked(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true, errorMessage = null) }
            try {
                val sheet = withContext(Dispatchers.IO) {
                    appContext.contentResolver.openInputStream(uri)?.use { stream ->
                        XlsxReader.readFirstSheet(stream)
                    } ?: throw ExcelParseException("No se pudo abrir el archivo seleccionado.")
                }

                val mapping = ExcelColumnMapper.mapHeaders(sheet.headers)
                if (mapping.nameColumn == null) {
                    _uiState.update {
                        it.copy(
                            isProcessing = false,
                            errorMessage = "No se encontró una columna de nombre de proveedor " +
                                "(se esperaba \"PROVEEDOR\" o \"NOMBRE\"). Revisa los encabezados " +
                                "de la primera fila de tu archivo."
                        )
                    }
                    return@launch
                }

                val parsed = sheet.rows.mapIndexed { index, row ->
                    // La fila 1 es el encabezado; los datos empiezan en la fila 2.
                    ExcelColumnMapper.parseRow(row, mapping, rowNumber = index + 2)
                }
                parsedRows = parsed

                _uiState.update {
                    it.copy(
                        phase = ImportPhase.PREVIEW,
                        isProcessing = false,
                        previewRows = buildPreview(parsed),
                        fileName = queryFileName(uri)
                    )
                }
            } catch (e: ExcelParseException) {
                _uiState.update { it.copy(isProcessing = false, errorMessage = e.message) }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        errorMessage = "No se pudo leer el archivo: ${e.message ?: "error desconocido"}."
                    )
                }
            }
        }
    }

    private suspend fun buildPreview(parsed: List<ParsedSupplierRow>): List<ImportPreviewRow> {
        val seenNormalizedNames = mutableSetOf<String>()
        return parsed.map { row ->
            when {
                row.name.isBlank() -> ImportPreviewRow(
                    rowNumber = row.rowNumber,
                    name = "(sin nombre)",
                    email = row.primaryEmail,
                    status = ImportRowStatus.Error("Falta el nombre del proveedor")
                )
                !seenNormalizedNames.add(row.normalizedName) -> ImportPreviewRow(
                    rowNumber = row.rowNumber,
                    name = row.name,
                    email = row.primaryEmail,
                    status = ImportRowStatus.DuplicateInFile
                )
                else -> {
                    val existing = repository.findSupplierByNormalizedName(row.normalizedName)
                    ImportPreviewRow(
                        rowNumber = row.rowNumber,
                        name = row.name,
                        email = row.primaryEmail,
                        status = if (existing != null) ImportRowStatus.Update else ImportRowStatus.New,
                        warning = if (row.emails.isEmpty()) "Sin correo" else null
                    )
                }
            }
        }
    }

    fun confirmImport() {
        val state = _uiState.value
        if (state.phase != ImportPhase.PREVIEW || state.isProcessing) return

        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true) }

            var created = 0
            var updated = 0
            var duplicates = 0
            var errors = 0
            val seenNormalizedNames = mutableSetOf<String>()

            parsedRows.forEach { row ->
                when {
                    row.name.isBlank() -> errors++
                    !seenNormalizedNames.add(row.normalizedName) -> duplicates++
                    else -> {
                        val wasUpdate = repository.upsertFromExcelRow(row)
                        if (wasUpdate) updated++ else created++
                    }
                }
            }

            _uiState.update {
                it.copy(
                    isProcessing = false,
                    phase = ImportPhase.DONE,
                    result = ImportResult(
                        created = created,
                        updated = updated,
                        duplicatesInFile = duplicates,
                        withErrors = errors
                    )
                )
            }
        }
    }

    fun cancel() {
        parsedRows = emptyList()
        _uiState.value = ImportUiState()
    }

    private fun queryFileName(uri: Uri): String? = runCatching {
        appContext.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIndex >= 0 && cursor.moveToFirst()) cursor.getString(nameIndex) else null
        }
    }.getOrNull()

    class Factory(
        private val appContext: Context,
        private val repository: SupplierRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ExcelImportViewModel(appContext, repository) as T
        }
    }
}
