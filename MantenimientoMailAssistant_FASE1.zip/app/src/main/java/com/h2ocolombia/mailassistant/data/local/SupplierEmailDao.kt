package com.h2ocolombia.mailassistant.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SupplierEmailDao {

    @Query("SELECT * FROM supplier_emails WHERE supplierId = :supplierId ORDER BY emailType ASC")
    fun observeForSupplier(supplierId: Long): Flow<List<SupplierEmail>>

    @Query(
        "SELECT * FROM supplier_emails " +
            "WHERE supplierId = :supplierId AND emailType = :emailType AND active = 1 LIMIT 1"
    )
    suspend fun findByType(supplierId: Long, emailType: EmailType): SupplierEmail?

    @Query("SELECT * FROM supplier_emails WHERE supplierId = :supplierId AND active = 1 LIMIT 1")
    suspend fun findAnyActive(supplierId: Long): SupplierEmail?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(email: SupplierEmail): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(emails: List<SupplierEmail>): List<Long>

    @Update
    suspend fun update(email: SupplierEmail)

    @Delete
    suspend fun delete(email: SupplierEmail)
}
