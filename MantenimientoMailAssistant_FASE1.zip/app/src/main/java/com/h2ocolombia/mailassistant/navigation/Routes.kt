package com.h2ocolombia.mailassistant.navigation

/**
 * Rutas de navegación de la app. Cada pantalla nueva que se agregue en fases
 * futuras (Import → FASE 4, Chat → FASE 5, Reglas → FASE 7/9, etc.) debe
 * declarar aquí su ruta en vez de usar strings sueltos en el código de UI.
 */
sealed class Routes(val route: String) {
    data object Home : Routes("home")
    data object Import : Routes("import")
    data object Settings : Routes("settings")
    data object History : Routes("history")
    data object RulesConfig : Routes("rules_config")

    data object SupplierChat : Routes("supplier_chat/{supplierId}/{supplierName}") {
        fun createRoute(supplierId: Long, encodedSupplierName: String) =
            "supplier_chat/$supplierId/$encodedSupplierName"
    }
}
