package com.h2ocolombia.mailassistant.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

// Radios pequeños y deliberadamente distintos entre tamaños (no "el mismo
// radio en todo"), para que los paneles se sientan como placas de un HMI en
// vez de tarjetas de SaaS genéricas.
val MailAssistantShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(14.dp),
    extraLarge = RoundedCornerShape(28.dp)
)
