package com.h2ocolombia.mailassistant.domain.templates

/**
 * Reemplazo de variables {{VARIABLE}} en asunto/cuerpo de una plantilla
 * (sección 10 del requerimiento original). Deliberadamente simple —
 * reemplazo de texto literal, sin lógica condicional ni bucles — porque eso
 * es exactamente lo que las plantillas de la sección 10 necesitan.
 */
object TemplateEngine {
    fun render(template: String, variables: Map<String, String>): String {
        var result = template
        variables.forEach { (key, value) ->
            result = result.replace("{{$key}}", value)
        }
        return result
    }
}
