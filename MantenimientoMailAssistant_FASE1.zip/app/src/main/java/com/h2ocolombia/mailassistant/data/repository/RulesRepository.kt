package com.h2ocolombia.mailassistant.data.repository

import com.h2ocolombia.mailassistant.data.local.EmailTemplate
import com.h2ocolombia.mailassistant.data.local.EmailTemplateDao
import com.h2ocolombia.mailassistant.data.local.KeywordRule
import com.h2ocolombia.mailassistant.data.local.KeywordRuleDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class RulesRepository(
    private val keywordRuleDao: KeywordRuleDao,
    private val emailTemplateDao: EmailTemplateDao
) {
    /** Lectura puntual (no observación continua) — el DAO solo expone un Flow. */
    suspend fun getActiveKeywordRules(): List<KeywordRule> = keywordRuleDao.observeActive().first()

    suspend fun getTemplateByKey(key: String): EmailTemplate? = emailTemplateDao.findByKey(key)

    fun observeAllTemplates(): Flow<List<EmailTemplate>> = emailTemplateDao.observeAll()

    suspend fun setTemplateActive(templateId: Long, active: Boolean) {
        val current = emailTemplateDao.getById(templateId) ?: return
        emailTemplateDao.update(current.copy(active = active))
    }
}
