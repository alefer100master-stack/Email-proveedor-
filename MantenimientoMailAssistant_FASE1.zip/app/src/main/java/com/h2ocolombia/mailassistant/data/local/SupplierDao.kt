package com.h2ocolombia.mailassistant.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SupplierDao {

    @Transaction
    @Query("SELECT * FROM suppliers ORDER BY name ASC")
    fun observeAllWithEmails(): Flow<List<SupplierWithEmails>>

    @Transaction
    @Query("SELECT * FROM suppliers WHERE active = 1 ORDER BY name ASC")
    fun observeActiveWithEmails(): Flow<List<SupplierWithEmails>>

    @Query("SELECT * FROM suppliers WHERE id = :id")
    suspend fun getById(id: Long): Supplier?

    @Transaction
    @Query("SELECT * FROM suppliers WHERE id = :id")
    suspend fun getByIdWithEmails(id: Long): SupplierWithEmails?

    @Query("SELECT * FROM suppliers WHERE normalizedName = :normalizedName LIMIT 1")
    suspend fun findByNormalizedName(normalizedName: String): Supplier?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(supplier: Supplier): Long

    @Update
    suspend fun update(supplier: Supplier)

    @Delete
    suspend fun delete(supplier: Supplier)

    @Query("SELECT COUNT(*) FROM suppliers")
    suspend fun count(): Int
}
