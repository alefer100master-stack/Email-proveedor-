plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.h2ocolombia.mailassistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.h2ocolombia.mailassistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.9.0"
    }

    buildFeatures {
        compose = true
    }

    signingConfigs {
        // Keystore de DEBUG fijo, committeado a propósito (a diferencia de un
        // keystore de release, uno de debug con las credenciales estándar de
        // Android no es secreto — su único propósito es que la firma de la
        // app sea la MISMA en cada build). Esto es necesario para MSAL: la
        // URI de redirección que se configura en Entra ID depende del hash
        // de esta firma. Sin este archivo, GitHub Actions generaría un
        // keystore de debug distinto en cada build (porque cada corrida es
        // una máquina nueva), y la conexión con Outlook se rompería cada vez.
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }

        // La firma de release lee de variables de entorno (GitHub Secrets), no
        // de un archivo committeado — un .jks de RELEASE nunca debe subirse al
        // repo (ver .gitignore). Si esas variables no están configuradas, el
        // build de release simplemente queda sin firmar. Ver
        // docs/FASE15_NOTAS.md para el paso a paso de cuándo y cómo generar
        // un keystore real.
        val releaseKeystorePath = System.getenv("RELEASE_KEYSTORE_PATH")
        if (!releaseKeystorePath.isNullOrBlank()) {
            create("release") {
                storeFile = file(releaseKeystorePath)
                storePassword = System.getenv("RELEASE_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("RELEASE_KEY_ALIAS")
                keyPassword = System.getenv("RELEASE_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            // Se deja apagado a propósito por ahora — ver docs/FASE15_NOTAS.md,
            // sección "Por qué la minificación queda apagada por ahora".
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (!System.getenv("RELEASE_KEYSTORE_PATH").isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

// Sin esto, un test que falla solo muestra "BUILD FAILED" en el log de
// GitHub Actions, sin decir cuál prueba ni por qué — obliga a bajar el
// reporte HTML para verlo. Con esto, el mensaje de error real queda
// impreso directo en el log que ya ves en el navegador.
tasks.withType<Test> {
    testLogging {
        events("failed", "skipped")
        showExceptions = true
        showCauses = true
        showStackTraces = true
        exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.navigation:navigation-compose:2.8.0")

    implementation(platform("androidx.compose:compose-bom:2024.09.02"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // FASE 2 — Room (base de datos local)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    debugImplementation("androidx.compose.ui:ui-tooling")

    testImplementation("junit:junit:4.13.2")
}
